import { AuthScreen } from "@/components/screens";
export default function Page() {
  return <AuthScreen kind="login" />;
}
