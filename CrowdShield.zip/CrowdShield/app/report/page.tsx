import { ReportScreen } from "@/components/screens";
export default function Page() {
  return <ReportScreen />;
}
