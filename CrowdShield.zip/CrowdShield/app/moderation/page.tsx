import { ModerationScreen } from "@/components/screens";
export default function Page() {
  return <ModerationScreen />;
}
