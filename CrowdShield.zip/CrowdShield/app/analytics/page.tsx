import { AnalyticsScreen } from "@/components/screens";
export default function Page() {
  return <AnalyticsScreen />;
}
