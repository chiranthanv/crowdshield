import type { Metadata } from "next";
import Shell from "@/components/shell";
import "./globals.css";
export const metadata: Metadata = {
  title: "CrowdShield | Community URL Intelligence",
  description:
    "A DBMS project for crowdsourced phishing reports, reviewed evidence and semantic search.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
