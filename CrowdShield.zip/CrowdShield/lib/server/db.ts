import pg from "pg";
import { MongoClient, type Document } from "mongodb";
import { config, AppError } from "./config";
export type Sql = Pick<pg.PoolClient, "query">;
const globalDb = globalThis as unknown as {
  crowdPool?: pg.Pool;
  crowdMongo?: MongoClient;
};
export function pool() {
  if (!config.database)
    throw new AppError(
      503,
      "PostgreSQL is not configured. Follow README setup.",
      "database_unavailable",
    );
  if (!globalDb.crowdPool) {
    const p = new pg.Pool({
      connectionString: config.database,
      max: Number(process.env.PG_POOL_MAX || 10),
      connectionTimeoutMillis: 3000,
      statement_timeout: 15000,
    });
    p.on("error", () =>
      console.error(
        "An idle database connection was lost; new requests will reconnect.",
      ),
    );
    globalDb.crowdPool = p;
  }
  return globalDb.crowdPool;
}
export async function query<T extends pg.QueryResultRow = any>(
  sql: string,
  params: unknown[] = [],
) {
  return (await pool().query<T>(sql, params)).rows;
}
export async function tx<T>(
  fn: (db: Sql) => Promise<T>,
  isolation = "READ COMMITTED",
): Promise<T> {
  for (let attempt = 0; ; attempt++) {
    const c = await pool().connect();
    try {
      await c.query(`BEGIN ISOLATION LEVEL ${isolation}`);
      const result = await fn(c);
      await c.query("COMMIT");
      return result;
    } catch (e) {
      await c.query("ROLLBACK");
      if (
        ["40001", "40P01"].includes((e as { code: string }).code) &&
        attempt < 2
      )
        continue;
      throw e;
    } finally {
      c.release();
    }
  }
}
export async function mongo() {
  if (!config.mongo)
    throw new AppError(
      503,
      "MongoDB is not configured.",
      "document_store_unavailable",
    );
  const c = (globalDb.crowdMongo ||= new MongoClient(config.mongo, {
    serverSelectionTimeoutMS: 2500,
    connectTimeoutMS: 2500,
  }));
  await c.connect();
  return c.db(config.mongoDb);
}
export interface ReportDoc extends Document {
  _id: string;
  url_id: string;
  reporter_id: string;
  report_type: string;
  workflow_status: string;
  content_version: number;
  message_text: string;
  narrative: string;
  channel: string;
  created_at: Date;
  updated_at: Date;
}
export async function reportCollection() {
  return (await mongo()).collection<ReportDoc>("scam_reports");
}
export async function closeDb() {
  await globalDb.crowdPool?.end();
  await globalDb.crowdMongo?.close();
  delete globalDb.crowdPool;
  delete globalDb.crowdMongo;
}
