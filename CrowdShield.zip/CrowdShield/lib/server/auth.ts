import { randomBytes, timingSafeEqual } from "node:crypto";
import { mkdir, writeFile, unlink } from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import bcrypt from "bcryptjs";
import { NextRequest, NextResponse } from "next/server";
import { query, tx, type Sql } from "./db";
import { config, AppError } from "./config";
import { sha } from "./validation";
export type Actor = {
  user_id: string;
  email: string;
  display_name: string;
  email_verified_at: string | null;
  roles: string[];
};
export const cookieName = "crowdshield_session";
export async function actor(
  req: NextRequest,
  required = true,
): Promise<Actor | null> {
  const token = req.cookies.get(cookieName)?.value;
  if (!token) {
    if (required) throw new AppError(401, "Please log in.");
    return null;
  }
  const [u] = await query<Actor>(
    `SELECT u.user_id,u.email,u.display_name,u.email_verified_at,array_agg(r.name) roles
 FROM refresh_sessions s JOIN users u USING(user_id) JOIN user_roles ur USING(user_id) JOIN roles r USING(role_id)
 WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>now() AND u.status='active'
 GROUP BY u.user_id`,
    [sha(token)],
  );
  if (!u && required)
    throw new AppError(401, "Your session has expired. Please log in.");
  return u || null;
}
export function requireRole(u: Actor | null, ...roles: string[]) {
  if (!u || !roles.some((r) => u.roles.includes(r)))
    throw new AppError(403, "You do not have permission for this action.");
}
export function verified(u: Actor) {
  if (!u.email_verified_at)
    throw new AppError(
      403,
      "Activate your demo account before contributing. Use the verification instructions.",
      "verification_required",
    );
}
export const isReviewer = (u: Actor | null) =>
  !!u?.roles.some((r) => ["admin", "moderator"].includes(r));
export function originCheck(req: NextRequest) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return;
  if (req.headers.get("origin") !== config.origin)
    throw new AppError(403, "Request origin was rejected.");
  if (req.headers.get("sec-fetch-site") === "cross-site")
    throw new AppError(403, "Cross-site request rejected.");
}
const limits = new Map<string, { n: number; until: number }>();
export function rateLimit(key: string, max = 60) {
  const now = Date.now();
  for (const [k, v] of limits) if (v.until < now) limits.delete(k);
  const entry = limits.get(key) || { n: 0, until: now + 60000 };
  entry.n++;
  limits.set(key, entry);
  if (entry.n > max)
    throw new AppError(
      429,
      "Too many requests. Please wait one minute.",
      "rate_limited",
    );
}
export async function passwordHash(value: string) {
  if (Buffer.byteLength(value, "utf8") > 72)
    throw new AppError(400, "Password must be at most 72 UTF-8 bytes.");
  return bcrypt.hash(value, 12);
}
const dummyHash = bcrypt.hashSync(randomBytes(32).toString("hex"), 12);
export async function passwordMatches(value: string, hash?: string) {
  if (Buffer.byteLength(value, "utf8") > 72) return false;
  return bcrypt.compare(value, hash?.startsWith("$2") ? hash : dummyHash);
}
export async function newSession(db: Sql, userId: string) {
  const token = randomBytes(32).toString("base64url");
  await db.query(
    `INSERT INTO refresh_sessions(user_id,token_hash,expires_at) VALUES($1,$2,now()+interval '12 hours')`,
    [userId, sha(token)],
  );
  return token;
}
export function sessionResponse(data: unknown, token: string, status = 200) {
  const r = NextResponse.json(data, { status });
  r.cookies.set(cookieName, token, {
    httpOnly: true,
    secure: config.origin.startsWith("https://"),
    sameSite: "strict",
    path: "/",
    maxAge: 43200,
  });
  return r;
}
export async function revoke(req: NextRequest) {
  const token = req.cookies.get(cookieName)?.value;
  if (token)
    await query(
      "UPDATE refresh_sessions SET revoked_at=now() WHERE token_hash=$1 AND revoked_at IS NULL",
      [sha(token)],
    );
  const r = NextResponse.json({ message: "Logged out" });
  r.cookies.set(cookieName, "", {
    httpOnly: true,
    sameSite: "strict",
    path: "/",
    maxAge: 0,
    secure: config.origin.startsWith("https://"),
  });
  return r;
}
export const sameHash = (a: Buffer, b: Buffer) =>
  a.length === b.length && timingSafeEqual(a, b);
export async function verificationToken(db: Sql, userId: string) {
  await db.query(
    `UPDATE auth_tokens SET consumed_at=now() WHERE user_id=$1 AND purpose='verify_email' AND consumed_at IS NULL`,
    [userId],
  );
  const token = randomBytes(32).toString("base64url");
  await db.query(
    `INSERT INTO auth_tokens(user_id,purpose,token_hash,expires_at) VALUES($1,'verify_email',$2,now()+interval '30 minutes')`,
    [userId, sha(token)],
  );
  return token;
}
export async function deliverVerification(userId: string, token: string) {
  if (!config.localDemo)
    throw new AppError(
      503,
      "Local verification is available only in local-demo mode.",
    );
  const dir =
    process.env.LOCAL_VERIFICATION_OUTBOX ||
    path.join(os.tmpdir(), "crowdshield-verification");
  await mkdir(dir, { recursive: true, mode: 0o700 });
  await writeFile(path.join(dir, `${userId}.txt`), token, { mode: 0o600 });
}
export async function consumeVerification(token: string) {
  const userId = await tx(async (db) => {
    const { rows } = await db.query(
      `UPDATE auth_tokens SET consumed_at=now() WHERE token_hash=$1 AND purpose='verify_email' AND consumed_at IS NULL AND expires_at>now() RETURNING user_id`,
      [sha(token)],
    );
    if (!rows.length)
      throw new AppError(
        400,
        "Verification token is invalid, expired or already used.",
      );
    await db.query(
      "UPDATE users SET email_verified_at=coalesce(email_verified_at,now()) WHERE user_id=$1",
      [rows[0].user_id],
    );
    await db.query(
      `INSERT INTO audit_logs(actor_id,action,entity_type,entity_id) VALUES($1::uuid,'account.demo_verified','user',$1::text)`,
      [rows[0].user_id],
    );
    return rows[0].user_id;
  });
  const dir =
    process.env.LOCAL_VERIFICATION_OUTBOX ||
    path.join(os.tmpdir(), "crowdshield-verification");
  await unlink(path.join(dir, `${userId}.txt`)).catch(() => {});
  return userId;
}
