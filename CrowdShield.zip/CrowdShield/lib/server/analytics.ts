import { query, reportCollection } from "./db";
export async function overview() {
  const [counts] = await query(
    `SELECT (SELECT count(*) FROM urls WHERE NOT is_archived) urls,(SELECT count(*) FROM report_refs) reports,(SELECT count(*) FROM votes) votes,(SELECT count(*) FROM users WHERE status='active') contributors,(SELECT count(*) FROM report_refs WHERE sync_status='pending') pending,(SELECT count(*) FROM report_refs WHERE sync_status='failed') failed,(SELECT count(*) FROM report_refs WHERE workflow_status='pending' AND sync_status='synced') review_queue`,
  );
  const distribution = await query(
    `SELECT coalesce(r.label,'insufficient_evidence') label,count(*)::int count FROM urls u LEFT JOIN v_current_risk r USING(url_id) WHERE NOT is_archived GROUP BY 1 ORDER BY 1`,
  );
  const recent = await query(
    `SELECT * FROM v_url_summary ORDER BY first_seen_at DESC LIMIT 8`,
  );
  const [processing] = await query(
    `SELECT count(*) FILTER(WHERE status='pending')::int pending,count(*) FILTER(WHERE status='processing')::int processing,count(*) FILTER(WHERE status='failed')::int failed,max(processed_at) last_processed_at FROM outbox_events`,
  );
  let mongodb = "available";
  try {
    await (await reportCollection()).findOne({}, { projection: { _id: 1 } });
  } catch {
    mongodb = "unavailable";
  }
  const [vectors] = await query(
    `SELECT count(*)::int chunks,count(DISTINCT report_id)::int reports FROM embeddings`,
  );
  return {
    counts,
    distribution,
    recent,
    processing,
    services: {
      postgresql: "available",
      mongodb,
      vector_reports: vectors.reports,
      vector_chunks: vectors.chunks,
    },
  };
}
export async function trends() {
  const daily = await query(
    `SELECT d::date::text AS day,count(r.report_id)::int reports FROM generate_series(current_date-13,current_date,interval '1 day') d LEFT JOIN report_refs r ON r.created_at>=d AND r.created_at<d+interval '1 day' GROUP BY d ORDER BY d`,
  );
  const top = await query(
    `SELECT u.url_id,u.display_url,count(r.report_id)::int reports FROM urls u JOIN report_refs r USING(url_id) WHERE r.workflow_status='accepted' AND r.sync_status='synced' AND NOT u.is_archived GROUP BY u.url_id ORDER BY reports DESC LIMIT 8`,
  );
  // Restrict the Mongo aggregate to currently eligible SQL IDs and versions; stale Mongo copies cannot inflate public analytics.
  const eligible = await query(
    `SELECT r.report_id,r.content_version FROM report_refs r JOIN users owner ON owner.user_id=r.reporter_id JOIN urls u USING(url_id) WHERE r.workflow_status='accepted' AND r.sync_status='synced' AND owner.status='active' AND owner.email_verified_at IS NOT NULL AND NOT u.is_archived`,
  );
  let mongoData: any = null,
    mongoError: string | null = null;
  try {
    const col = await reportCollection();
    const match = eligible.length
      ? {
          $or: eligible.map((r) => ({
            _id: r.report_id,
            content_version: r.content_version,
          })),
        }
      : { _id: { $in: [] } };
    const [facet] = await col
      .aggregate([
        { $match: match },
        {
          $facet: {
            types: [
              { $group: { _id: "$report_type", count: { $sum: 1 } } },
              { $sort: { count: -1 } },
            ],
            daily: [
              {
                $group: {
                  _id: {
                    $dateToString: {
                      format: "%Y-%m-%d",
                      date: "$created_at",
                      timezone: "UTC",
                    },
                  },
                  count: { $sum: 1 },
                },
              },
              { $sort: { _id: 1 } },
            ],
            active: [
              { $group: { _id: "$reporter_id", count: { $sum: 1 } } },
              { $sort: { count: -1 } },
              { $limit: 5 },
            ],
          },
        },
      ])
      .toArray();
    const names = await query(
      `SELECT user_id,display_name FROM users WHERE user_id=ANY($1::uuid[])`,
      [(facet?.active || []).map((r: any) => r._id)],
    );
    mongoData = {
      ...facet,
      active: (facet?.active || []).map((r: any) => ({
        display_name:
          names.find((n) => n.user_id === r._id)?.display_name || "Contributor",
        count: r.count,
      })),
    };
  } catch {
    mongoError =
      "MongoDB analytics temporarily unavailable. SQL trends remain available.";
  }
  return { daily, top, mongo: mongoData, mongo_error: mongoError };
}
