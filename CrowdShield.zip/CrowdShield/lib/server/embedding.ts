import path from "node:path";
import { config, AppError } from "./config";
let extractorPromise: Promise<any> | null = null;
export async function extractor() {
  if (!/^[a-f0-9]{40}$/.test(config.modelRevision))
    throw new AppError(
      503,
      "Embedding model revision is not configured. Run the model setup instructions.",
      "model_unavailable",
    );
  if (!extractorPromise)
    extractorPromise = (async () => {
      const { pipeline, env } = await import("@huggingface/transformers");
      env.cacheDir =
        process.env.MODEL_CACHE_DIR || path.resolve(".model-cache");
      return pipeline("feature-extraction", config.modelId, {
        revision: config.modelRevision,
        dtype: "fp32",
        device: "cpu",
      });
    })().catch(() => {
      extractorPromise = null;
      throw new AppError(
        503,
        "The embedding model is unavailable. Run npm run model:download and retry.",
        "model_unavailable",
      );
    });
  return extractorPromise;
}
export async function embedChunks(
  text: string,
): Promise<{ text: string; vector: number[] }[]> {
  const p = await extractor();
  const tokens = p.tokenizer.encode(text, { add_special_tokens: false });
  const result = [];
  for (let i = 0; i < tokens.length; i += 150) {
    const chunk = p.tokenizer.decode(tokens.slice(i, i + 180), {
      skip_special_tokens: true,
    });
    const out = await p(chunk, { pooling: "mean", normalize: true });
    const vector = Array.from(out.data) as number[];
    if (vector.length !== 384 || vector.some((v) => !Number.isFinite(v)))
      throw new AppError(
        503,
        "Embedding model returned an invalid vector.",
        "model_unavailable",
      );
    result.push({ text: chunk, vector });
    if (i + 180 >= tokens.length) break;
  }
  return result;
}
export async function embedQuery(text: string) {
  const chunks = await embedChunks(text);
  if (!chunks.length) throw new AppError(400, "Enter a search phrase.");
  const avg = Array(384).fill(0);
  for (const c of chunks)
    for (let i = 0; i < 384; i++) avg[i] += c.vector[i] / chunks.length;
  const norm = Math.sqrt(avg.reduce((a, v) => a + v * v, 0));
  return avg.map((v) => v / norm);
}
export const vectorSql = (v: number[]) => "[" + v.join(",") + "]";
