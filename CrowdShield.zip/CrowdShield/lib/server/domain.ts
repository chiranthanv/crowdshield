import { randomUUID } from "node:crypto";
import { query, tx, type Sql, reportCollection } from "./db";
import { AppError } from "./config";
import { normalizeUrl, redact, sha, reportSchema } from "./validation";
import { sameHash, verified, isReviewer, type Actor } from "./auth";
export async function lockDomain(db: Sql) {
  await db.query("SELECT pg_advisory_xact_lock(434343)");
}
export async function audit(
  db: Sql,
  actorId: string,
  action: string,
  type: string,
  id: string,
  details: unknown = {},
) {
  await db.query(
    `INSERT INTO audit_logs(actor_id,action,entity_type,entity_id,details) VALUES($1,$2,$3,$4,$5)`,
    [actorId, action, type, id, JSON.stringify(details)],
  );
}
export async function resolveUrl(db: Sql, input: string, userId: string) {
  const u = normalizeUrl(input);
  const { rows } = await db.query(
    `INSERT INTO urls(canonical_url,hostname,display_url,submitted_by) VALUES($1,$2,$3,$4)
 ON CONFLICT(canonical_hash) DO UPDATE SET last_seen_at=now() WHERE urls.canonical_url=EXCLUDED.canonical_url RETURNING *`,
    [u.canonical_url, u.hostname, u.display_url, userId],
  );
  if (!rows.length) throw new AppError(409, "URL identity conflict.");
  if (rows[0].is_archived)
    throw new AppError(409, "This URL has been archived.");
  return rows[0];
}
export async function refreshRisk(db: Sql, ids: string[], invalidate = false) {
  const all = new Set(ids);
  if (invalidate && ids.length) {
    const { rows } = await db.query(
      `DELETE FROM similarity_edges WHERE url_id=ANY($1::uuid[]) OR neighbor_url_id=ANY($1::uuid[]) RETURNING url_id,neighbor_url_id`,
      [ids],
    );
    rows.forEach((r) => {
      all.add(r.url_id);
      all.add(r.neighbor_url_id);
    });
  }
  for (const id of [...all].sort()) {
    const { rows } = await db.query(
      "UPDATE urls SET evidence_version=evidence_version+1 WHERE url_id=$1 RETURNING evidence_version",
      [id],
    );
    await db.query(
      `INSERT INTO outbox_events(event_type,aggregate_id,aggregate_version,payload) VALUES('risk.refresh',$1,$2,'{}') ON CONFLICT DO NOTHING`,
      [id, rows[0].evidence_version],
    );
    await db.query("CALL recalculate_risk($1)", [id]);
  }
}
export async function createUrl(input: string, u: Actor) {
  return tx(async (db) => {
    await lockDomain(db);
    const row = await resolveUrl(db, input, u.user_id);
    await db.query("CALL recalculate_risk($1)", [row.url_id]);
    return row;
  });
}
export async function submitReport(raw: unknown, u: Actor) {
  verified(u);
  const input = reportSchema.parse(raw);
  const normalized = normalizeUrl(input.url);
  const message = redact(input.message_text);
  if (message.length < 15)
    throw new AppError(
      400,
      "Add a useful explanation without personal details.",
    );
  const hash = sha(
    JSON.stringify({
      url: normalized.canonical_url,
      report_type: input.report_type,
      message_text: message,
      channel: input.channel,
    }),
  );
  return tx(async (db) => {
    await lockDomain(db);
    const { rows: existing } = await db.query(
      "SELECT * FROM report_refs WHERE reporter_id=$1 AND idempotency_key=$2",
      [u.user_id, input.idempotency_key],
    );
    if (existing.length) {
      if (!sameHash(existing[0].request_hash, hash))
        throw new AppError(
          409,
          "This submission key was already used for different content.",
        );
      return { ...existing[0], replayed: true };
    }
    const url = await resolveUrl(db, input.url, u.user_id);
    const reportId = randomUUID();
    const { rows } = await db.query(
      `INSERT INTO report_refs(report_id,url_id,reporter_id,report_type,idempotency_key,request_hash) VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,
      [
        reportId,
        url.url_id,
        u.user_id,
        input.report_type,
        input.idempotency_key,
        hash,
      ],
    );
    const document = {
      _id: reportId,
      url_id: url.url_id,
      reporter_id: u.user_id,
      report_type: input.report_type,
      workflow_status: "pending",
      content_version: 1,
      message_text: message,
      narrative: message,
      channel: input.channel,
      created_at: rows[0].created_at,
      updated_at: rows[0].updated_at,
    };
    await db.query(
      `INSERT INTO outbox_events(event_type,aggregate_id,aggregate_version,payload) VALUES('report.created',$1,1,$2)`,
      [reportId, JSON.stringify(document)],
    );
    await audit(db, u.user_id, "report.submitted", "report", reportId);
    await refreshRisk(db, [url.url_id]);
    return { ...rows[0], replayed: false };
  });
}
export async function setVote(id: string, value: number | null, u: Actor) {
  verified(u);
  return tx(async (db) => {
    await lockDomain(db);
    const { rows } = await db.query(
      "SELECT url_id FROM urls WHERE url_id=$1 AND NOT is_archived",
      [id],
    );
    if (!rows.length) throw new AppError(404, "URL not found.");
    if (value === null)
      await db.query("DELETE FROM votes WHERE user_id=$1 AND url_id=$2", [
        u.user_id,
        id,
      ]);
    else
      await db.query(
        `INSERT INTO votes(user_id,url_id,verdict) VALUES($1,$2,$3) ON CONFLICT(user_id,url_id) DO UPDATE SET verdict=EXCLUDED.verdict,updated_at=now()`,
        [u.user_id, id, value],
      );
    await db.query("CALL recalculate_risk($1)", [id]);
    return { message: value === null ? "Vote withdrawn" : "Vote saved" };
  });
}
export async function withdrawReport(id: string, u: Actor) {
  return tx(async (db) => {
    await lockDomain(db);
    const { rows } = await db.query(
      "SELECT * FROM report_refs WHERE report_id=$1 FOR UPDATE",
      [id],
    );
    const r = rows[0];
    if (!r) throw new AppError(404, "Report not found.");
    if (r.reporter_id !== u.user_id)
      throw new AppError(403, "You can withdraw only your own report.");
    if (r.workflow_status === "withdrawn") return r;
    const { rows: updated } = await db.query(
      `UPDATE report_refs SET workflow_status='withdrawn',sync_status='pending',content_version=content_version+1,updated_at=now() WHERE report_id=$1 RETURNING *`,
      [id],
    );
    await db.query(
      `INSERT INTO outbox_events(event_type,aggregate_id,aggregate_version,payload) VALUES('report.status',$1,$2,'{"workflow_status":"withdrawn"}')`,
      [id, updated[0].content_version],
    );
    await db.query("DELETE FROM embeddings WHERE report_id=$1", [id]);
    await refreshRisk(db, [r.url_id], true);
    await audit(db, u.user_id, "report.withdrawn", "report", id);
    return updated[0];
  });
}
export async function reviewReport(
  id: string,
  accept: boolean,
  reason: string,
  u: Actor,
) {
  return tx(async (db) => {
    await lockDomain(db);
    const { rows } = await db.query(
      "SELECT * FROM report_refs WHERE report_id=$1 FOR UPDATE",
      [id],
    );
    if (!rows.length) throw new AppError(404, "Report not found.");
    if (rows[0].reporter_id === u.user_id)
      throw new AppError(403, "You cannot review your own report.");
    if (
      rows[0].workflow_status !== "pending" ||
      rows[0].sync_status !== "synced"
    )
      throw new AppError(
        409,
        "Review requires a pending, synchronized report.",
      );
    await db.query("CALL moderate_report($1,$2,$3,$4)", [
      id,
      u.user_id,
      accept,
      reason,
    ]);
    if (accept)
      await db.query(
        `INSERT INTO reputation_events(user_id,delta,reason,dedupe_key,awarded_by) VALUES($1,2,'Accepted contribution',$2,$3) ON CONFLICT(dedupe_key) DO NOTHING`,
        [rows[0].reporter_id, `accepted:${id}`, u.user_id],
      );
    await db.query("DELETE FROM embeddings WHERE report_id=$1", [id]);
    const { rows: affected } = await db.query(
      `SELECT url_id FROM votes WHERE user_id=$1 UNION SELECT url_id FROM report_refs WHERE reporter_id=$1`,
      [rows[0].reporter_id],
    );
    await refreshRisk(
      db,
      [...new Set([rows[0].url_id, ...affected.map((x) => x.url_id)])],
      true,
    );
    return {
      message: accept
        ? "Report accepted; synchronizing"
        : "Report rejected; synchronizing",
    };
  });
}
export async function setVerdict(
  id: string,
  verdict: string,
  reason: string,
  days: number | null,
  u: Actor,
) {
  return tx(async (db) => {
    await lockDomain(db);
    const { rows } = await db.query(
      "SELECT url_id FROM urls WHERE url_id=$1 AND NOT is_archived",
      [id],
    );
    if (!rows.length) throw new AppError(404, "URL not found.");
    await db.query(
      `INSERT INTO moderator_actions(moderator_id,url_id,action_kind,verdict,reason,valid_until) VALUES($1,$2,'set_verdict',$3,$4,CASE WHEN $5::int IS NULL THEN NULL ELSE now()+$5::int*interval '1 day' END)`,
      [u.user_id, id, verdict, reason, days],
    );
    const { rows: neighbors } = await db.query(
      "SELECT url_id FROM similarity_edges WHERE neighbor_url_id=$1",
      [id],
    );
    await refreshRisk(db, [id, ...neighbors.map((r) => r.url_id)]);
    await audit(db, u.user_id, "url.verdict", "url", id, { verdict, reason });
    return { message: "Reviewed verdict recorded" };
  });
}
export const eligibleSql = `r.workflow_status='accepted' AND r.sync_status='synced' AND NOT u.is_archived AND owner.status='active' AND owner.email_verified_at IS NOT NULL`;
export async function getReport(id: string, u: Actor | null) {
  const [r] = await query(
    `SELECT r.*,x.display_url,owner.status owner_status,owner.email_verified_at FROM report_refs r JOIN urls x USING(url_id) JOIN users owner ON owner.user_id=r.reporter_id WHERE r.report_id=$1 AND NOT x.is_archived`,
    [id],
  );
  if (!r) throw new AppError(404, "Report not found.");
  const privileged = isReviewer(u) || u?.user_id === r.reporter_id;
  if (
    !privileged &&
    !(
      r.workflow_status === "accepted" &&
      r.sync_status === "synced" &&
      r.owner_status === "active" &&
      r.email_verified_at
    )
  )
    throw new AppError(404, "Report not found.");
  const doc = await (
    await reportCollection()
  ).findOne({
    _id: id,
    content_version: r.content_version,
    workflow_status: r.workflow_status,
  });
  const [latest] = await query(
    `SELECT r.content_version,r.workflow_status,r.sync_status,owner.status,owner.email_verified_at FROM report_refs r JOIN users owner ON owner.user_id=r.reporter_id JOIN urls x USING(url_id) WHERE r.report_id=$1 AND NOT x.is_archived`,
    [id],
  );
  if (
    !latest ||
    latest.content_version !== r.content_version ||
    (!privileged &&
      !(
        latest.workflow_status === "accepted" &&
        latest.sync_status === "synced" &&
        latest.status === "active" &&
        latest.email_verified_at
      ))
  )
    throw new AppError(409, "Report changed during retrieval. Please refresh.");
  const meta = {
    report_id: r.report_id,
    url_id: r.url_id,
    display_url: r.display_url,
    report_type: r.report_type,
    workflow_status: r.workflow_status,
    sync_status: r.sync_status,
    content_version: r.content_version,
    created_at: r.created_at,
    owned: u?.user_id === r.reporter_id,
  };
  return {
    ...meta,
    message_text: doc?.message_text || null,
    channel: doc?.channel || null,
    content_pending: !doc,
  };
}
export async function listReports(id: string, u: Actor | null) {
  return query(
    `SELECT r.report_id,r.report_type,r.workflow_status,r.sync_status,r.content_version,r.created_at,(r.reporter_id=$2::uuid) owned
 FROM report_refs r JOIN users owner ON owner.user_id=r.reporter_id JOIN urls x USING(url_id)
 WHERE r.url_id=$1 AND NOT x.is_archived AND ((r.workflow_status='accepted' AND r.sync_status='synced' AND owner.status='active' AND owner.email_verified_at IS NOT NULL) OR r.reporter_id=$2::uuid OR $3::boolean)
 ORDER BY r.created_at DESC LIMIT 100`,
    [id, u?.user_id || null, isReviewer(u)],
  );
}
