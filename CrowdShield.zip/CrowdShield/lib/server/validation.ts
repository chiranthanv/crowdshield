import { createHash } from "node:crypto";
import { z } from "zod";
import { AppError } from "./config";
export const uuid = z.string().uuid();
export const registerSchema = z
  .object({
    email: z.string().trim().toLowerCase().email().max(254),
    display_name: z.string().trim().min(2).max(80),
    password: z
      .string()
      .min(12)
      .max(72)
      .refine(
        (v) => Buffer.byteLength(v, "utf8") <= 72,
        "Password must be at most 72 UTF-8 bytes",
      ),
  })
  .strict();
export const reportSchema = z
  .object({
    url: z.string().min(8).max(8192),
    report_type: z.enum(["phishing", "scam_message", "other"]),
    message_text: z.string().trim().min(15).max(12000),
    channel: z
      .enum(["sms", "email", "social", "website", "other"])
      .default("website"),
    idempotency_key: uuid,
  })
  .strict();
export function normalizeUrl(input: string) {
  let u: URL;
  try {
    u = new URL(input.trim());
  } catch {
    throw new AppError(400, "Enter a complete HTTP or HTTPS URL.");
  }
  if (
    !["http:", "https:"].includes(u.protocol) ||
    u.username ||
    u.password ||
    !u.hostname ||
    input.length > 8192
  )
    throw new AppError(
      400,
      "Only HTTP/HTTPS URLs without embedded credentials are supported.",
    );
  u.hash = "";
  // WHATWG URL canonicalizes scheme, IDNA hostname and default port, while preserving path/query case and query order.
  if (u.hostname.length > 253) throw new AppError(400, "Hostname is too long.");
  const canonical_url = u.href;
  return {
    canonical_url,
    hostname: u.hostname.toLowerCase(),
    display_url: canonical_url.replace(/^http/, "hxxp").replaceAll(".", "[.]"),
  };
}
export function redact(input: string) {
  return input
    .normalize("NFKC")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[EMAIL REDACTED]")
    .replace(/\b(?:\d[ -]?){10,19}\b/g, "[NUMBER REDACTED]")
    .replace(
      /\b(?:otp|password|passcode|token|secret)\s*[:=]\s*\S+/gi,
      "[SECRET REDACTED]",
    )
    .trim();
}
export function sha(value: string) {
  return createHash("sha256").update(value).digest();
}
