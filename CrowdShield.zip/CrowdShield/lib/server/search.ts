import { query, reportCollection } from "./db";
import { config } from "./config";
import { embedQuery, vectorSql } from "./embedding";
import { eligibleSql } from "./domain";
export async function textSearch(q: string, limit = 30, offset = 0) {
  return query(
    `SELECT s.*,u.public_summary FROM v_url_summary s JOIN urls u USING(url_id)
 WHERE ($1='' OR u.hostname ILIKE '%'||$1||'%' OR u.search_vector @@ websearch_to_tsquery('simple',$1))
 ORDER BY u.last_seen_at DESC,u.url_id LIMIT $2 OFFSET $3`,
    [q, limit, offset],
  );
}
export async function semanticSearch(q: string) {
  const v = await embedQuery(q);
  // Exact search is the predictable baseline for the small college dataset. HNSW is available for EXPLAIN demonstrations.
  const rows = await query(
    `SELECT e.report_id,e.url_id,u.display_url,max(1-(e.embedding <=> $1::vector)) cosine_similarity,r.content_version
 FROM embeddings e JOIN report_refs r ON r.report_id=e.report_id JOIN urls u ON u.url_id=e.url_id JOIN users owner ON owner.user_id=r.reporter_id
 WHERE ${eligibleSql} AND e.source_kind='report' AND e.content_version=r.content_version AND e.model_version=$2
 GROUP BY e.report_id,e.url_id,u.display_url,r.content_version ORDER BY cosine_similarity DESC LIMIT 10`,
    [vectorSql(v), config.modelVersion],
  );
  const col = await reportCollection();
  const docs = await col
    .find({ _id: { $in: rows.map((r) => r.report_id) } })
    .toArray();
  // Recheck SQL state after network read, so a withdrawn/suspended report is never released based on old Mongo/vector state.
  const current = await query(
    `SELECT r.report_id,r.content_version FROM report_refs r JOIN urls u USING(url_id) JOIN users owner ON owner.user_id=r.reporter_id WHERE r.report_id=ANY($1::uuid[]) AND ${eligibleSql}`,
    [rows.map((r) => r.report_id)],
  );
  return rows.flatMap((r) => {
    const doc = docs.find(
      (d) =>
        d._id === r.report_id &&
        d.content_version === r.content_version &&
        d.workflow_status === "accepted",
    );
    return doc &&
      current.some(
        (c) =>
          c.report_id === r.report_id &&
          c.content_version === r.content_version,
      )
      ? [{ ...r, message_text: doc.message_text.slice(0, 500) }]
      : [];
  });
}
export async function similarEvidence(id: string) {
  return query(
    `SELECT e.neighbor_url_id url_id,u.display_url,e.similarity,m.verdict moderator_verdict FROM similarity_edges e JOIN urls u ON u.url_id=e.neighbor_url_id LEFT JOIN v_effective_verdict m ON m.url_id=u.url_id
 WHERE e.url_id=$1 AND NOT u.is_archived AND e.model_version=$2 AND e.computed_at>now()-interval '7 days'
 AND EXISTS(SELECT 1 FROM report_refs r JOIN users owner ON owner.user_id=r.reporter_id WHERE r.url_id=u.url_id AND r.workflow_status='accepted' AND r.sync_status='synced' AND owner.status='active' AND owner.email_verified_at IS NOT NULL)
 ORDER BY similarity DESC LIMIT 5`,
    [id, config.modelVersion],
  );
}
