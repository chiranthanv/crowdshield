import "dotenv/config";
export const config = {
  origin: process.env.APP_ORIGIN || "http://localhost:3000",
  database: process.env.DATABASE_URL || "",
  mongo: process.env.MONGODB_URI || "",
  mongoDb: process.env.MONGODB_DATABASE || "crowdshield",
  modelVersion: "minilm-l6-v2:project-v1",
  modelId: "Xenova/all-MiniLM-L6-v2",
  modelRevision: process.env.EMBEDDING_MODEL_REVISION || "",
  localDemo: process.env.APP_MODE === "local-demo",
};
export class AppError extends Error {
  constructor(
    public status: number,
    message: string,
    public code = "request_error",
  ) {
    super(message);
  }
}
