import { NextRequest, NextResponse } from "next/server";
import { z, ZodError } from "zod";
import { query, tx } from "./db";
import { config, AppError } from "./config";
import {
  actor,
  requireRole,
  originCheck,
  rateLimit,
  passwordHash,
  passwordMatches,
  newSession,
  sessionResponse,
  revoke,
  verificationToken,
  deliverVerification,
  consumeVerification,
} from "./auth";
import { uuid, registerSchema, normalizeUrl, sha } from "./validation";
import {
  createUrl,
  submitReport,
  setVote,
  withdrawReport,
  reviewReport,
  setVerdict,
  getReport,
  listReports,
  lockDomain,
  refreshRisk,
  audit,
} from "./domain";
import { textSearch, semanticSearch, similarEvidence } from "./search";
import { overview, trends } from "./analytics";
const json = (data: unknown, status = 200) =>
  NextResponse.json(data, { status });
async function body(req: NextRequest) {
  if (!req.headers.get("content-type")?.includes("application/json"))
    throw new AppError(415, "Send JSON content.");
  const text = await req.text();
  if (Buffer.byteLength(text) > 65536)
    throw new AppError(413, "Request is too large.");
  try {
    return JSON.parse(text);
  } catch {
    throw new AppError(400, "Invalid JSON.");
  }
}
const reasonSchema = z.string().trim().min(10).max(2000);
export async function handle(req: NextRequest) {
  try {
    originCheck(req);
    const route =
      req.nextUrl.pathname.replace(/^\/api\/v1/, "").replace(/\/$/, "") || "/";
    const method = req.method;
    // One local process is the supported deployment. Bound the global auth burst as well as per-account attempts; do not trust arbitrary forwarded headers.
    if (route.startsWith("/auth/")) rateLimit("auth:global", 100);
    if (method === "POST" && route === "/auth/register") {
      if (!config.localDemo)
        throw new AppError(
          503,
          "Public registration requires an email delivery adapter. Use local-demo mode for this project.",
        );
      const input = registerSchema.parse(await body(req));
      rateLimit(`register:${input.email}`, 5);
      const hash = await passwordHash(input.password);
      const result = await tx(async (db) => {
        const { rows } = await db.query(
          `INSERT INTO users(email,display_name,password_hash) VALUES($1,$2,$3) RETURNING user_id,email,display_name,email_verified_at`,
          [input.email, input.display_name, hash],
        );
        const u = rows[0];
        await db.query(
          `INSERT INTO user_roles(user_id,role_id) SELECT $1,role_id FROM roles WHERE name='user'`,
          [u.user_id],
        );
        return {
          user: { ...u, roles: ["user"] },
          session: await newSession(db, u.user_id),
          verification: await verificationToken(db, u.user_id),
        };
      });
      let delivered = true;
      try {
        await deliverVerification(result.user.user_id, result.verification);
      } catch {
        delivered = false;
      }
      return sessionResponse(
        {
          user: result.user,
          message: delivered
            ? "Account created. Activate it using the local verification instructions."
            : "Account created. Ask the local operator to run account:verify to issue a new token.",
        },
        result.session,
        201,
      );
    }
    if (method === "POST" && route === "/auth/login") {
      const input = z
        .object({
          email: z.string().trim().toLowerCase().email().max(254),
          password: z.string().min(1).max(72),
        })
        .strict()
        .parse(await body(req));
      rateLimit(`login:${input.email}`, 10);
      const [u] = await query("SELECT * FROM users WHERE email=$1", [
        input.email,
      ]);
      const ok = await passwordMatches(input.password, u?.password_hash);
      if (!u || !ok || u.status !== "active")
        throw new AppError(401, "Email or password is incorrect.");
      const token = await tx((db) => newSession(db, u.user_id));
      return sessionResponse({ message: "Logged in" }, token);
    }
    if (method === "POST" && route === "/auth/logout") return revoke(req);
    if (method === "POST" && route === "/auth/verify-email") {
      const { token } = z
        .object({ token: z.string().min(30).max(128) })
        .strict()
        .parse(await body(req));
      await consumeVerification(token);
      return json({
        message:
          "Demo account activated. This does not verify mailbox ownership.",
      });
    }
    if (method === "GET" && route === "/health")
      return json({ application: "CrowdShield", status: "running" });
    const u = await actor(req, false);
    if (u) rateLimit(`user:${u.user_id}`, 120);
    else rateLimit("public:global", 300);
    const auth = () => {
      if (!u) throw new AppError(401, "Please log in.");
      return u;
    };
    if (method === "GET" && route === "/me") return json({ user: auth() });
    if (method === "POST" && route === "/auth/refresh") {
      auth();
      const token = req.cookies.get("crowdshield_session")?.value || "";
      const renewed = await tx(async (db) => {
        const { rows } = await db.query(
          "UPDATE refresh_sessions SET revoked_at=now() WHERE token_hash=$1 AND revoked_at IS NULL AND expires_at>now() RETURNING user_id",
          [sha(token)],
        );
        if (!rows.length)
          throw new AppError(
            401,
            "This session has already been renewed or expired.",
          );
        return newSession(db, rows[0].user_id);
      });
      return sessionResponse(
        { message: "Session renewed; previous session invalidated." },
        renewed,
      );
    }
    if (method === "GET" && route === "/me/contributions") {
      const person = auth();
      const reports = await query(
        `SELECT r.report_id,r.url_id,r.report_type,r.workflow_status,r.sync_status,r.content_version,r.created_at,u.display_url FROM report_refs r JOIN urls u USING(url_id) WHERE reporter_id=$1 ORDER BY created_at DESC LIMIT 100`,
        [person.user_id],
      );
      const [counts] = await query(
        `SELECT (SELECT count(*) FROM votes WHERE user_id=$1)::int votes,(SELECT count(*) FROM report_refs WHERE reporter_id=$1)::int reports,(SELECT reputation FROM v_user_reputation WHERE user_id=$1) reputation`,
        [person.user_id],
      );
      return json({ reports, counts });
    }
    if (method === "POST" && route === "/urls") {
      const input = z
        .object({ url: z.string().max(8192) })
        .strict()
        .parse(await body(req));
      return json({ url: await createUrl(input.url, auth()) }, 201);
    }
    if (method === "POST" && route === "/urls/lookup") {
      const { url } = z
        .object({ url: z.string().max(8192) })
        .strict()
        .parse(await body(req));
      const normalized = normalizeUrl(url);
      const [found] = await query(
        "SELECT url_id FROM urls WHERE canonical_url=$1 AND NOT is_archived",
        [normalized.canonical_url],
      );
      return json({
        found: !!found,
        url_id: found?.url_id || null,
        display_url: normalized.display_url,
      });
    }
    if (method === "GET" && (route === "/urls" || route === "/search/text")) {
      const q = z
        .string()
        .max(300)
        .parse(req.nextUrl.searchParams.get("q") || "");
      const offset = z.coerce
        .number()
        .int()
        .min(0)
        .max(10000)
        .parse(req.nextUrl.searchParams.get("offset") || 0);
      return json({
        items: await textSearch(q, 30, offset),
        next_offset: offset + 30,
      });
    }
    if (method === "POST" && route === "/search/semantic") {
      const { q } = z
        .object({ q: z.string().trim().min(4).max(2000) })
        .strict()
        .parse(await body(req));
      rateLimit("semantic:global", 15);
      return json({
        items: await semanticSearch(q),
        model_version: config.modelVersion,
      });
    }
    if (method === "POST" && route === "/reports")
      return json({ report: await submitReport(await body(req), auth()) }, 202);
    const reportMatch = route.match(/^\/reports\/([^/]+)$/);
    if (reportMatch) {
      const id = uuid.parse(reportMatch[1]);
      if (method === "GET") return json({ report: await getReport(id, u) });
      if (method === "DELETE")
        return json({ report: await withdrawReport(id, auth()) });
    }
    const urlMatch = route.match(/^\/urls\/([^/]+)(?:\/(risk|vote|reports))?$/);
    if (urlMatch) {
      const id = uuid.parse(urlMatch[1]),
        sub = urlMatch[2];
      if (sub === "vote" && method === "PUT") {
        const { verdict } = z
          .object({ verdict: z.union([z.literal(1), z.literal(-1)]) })
          .strict()
          .parse(await body(req));
        return json(await setVote(id, verdict, auth()));
      }
      if (sub === "vote" && method === "DELETE")
        return json(await setVote(id, null, auth()));
      if (sub === "reports" && method === "GET")
        return json({ items: await listReports(id, u) });
      if (method === "GET" && (!sub || sub === "risk")) {
        const [url] = await query(
          `SELECT url_id,hostname,display_url,public_summary,first_seen_at,last_seen_at,evidence_version FROM urls WHERE url_id=$1 AND NOT is_archived`,
          [id],
        );
        if (!url) throw new AppError(404, "URL not found.");
        const [risk] = await query(
          "SELECT * FROM v_current_risk WHERE url_id=$1",
          [id],
        );
        const stale =
          !risk ||
          Number(risk.inputs.evidence_version) !== url.evidence_version ||
          Date.now() - new Date(risk.computed_at).getTime() > 360000;
        if (sub === "risk") return json({ risk: risk || null, stale });
        const [votes] = await query(
          `SELECT count(*) FILTER(WHERE v.verdict=1)::int malicious,count(*) FILTER(WHERE v.verdict=-1)::int safe FROM votes v JOIN users voter USING(user_id) WHERE v.url_id=$1 AND voter.status='active' AND voter.email_verified_at IS NOT NULL`,
          [id],
        );
        const [own] = u
          ? await query(
              "SELECT verdict FROM votes WHERE user_id=$1 AND url_id=$2",
              [u.user_id, id],
            )
          : [];
        return json({
          url,
          risk: risk || null,
          risk_stale: stale,
          votes,
          my_vote: own?.verdict || null,
          reports: await listReports(id, u),
          similar: await similarEvidence(id),
          history: await query(
            "SELECT score,coverage,label,computed_at,algorithm_version FROM risk_scores WHERE url_id=$1 ORDER BY computed_at DESC,risk_score_id DESC LIMIT 12",
            [id],
          ),
        });
      }
    }
    if (method === "GET" && route === "/analytics/overview")
      return json(await overview());
    if (method === "GET" && route === "/analytics/trends")
      return json(await trends());
    if (route.startsWith("/moderation/")) {
      requireRole(auth(), "moderator", "admin");
      if (method === "GET" && route === "/moderation/reports")
        return json({
          items: await query(
            `SELECT r.report_id,r.url_id,r.created_at,r.sync_status,r.workflow_status,r.reporter_id,u.display_url FROM report_refs r JOIN urls u USING(url_id) WHERE r.workflow_status='pending' ORDER BY r.created_at LIMIT 100`,
          ),
        });
      const review = route.match(/^\/moderation\/reports\/([^/]+)\/decision$/);
      if (method === "POST" && review) {
        const input = z
          .object({ accept: z.boolean(), reason: reasonSchema })
          .strict()
          .parse(await body(req));
        return json(
          await reviewReport(
            uuid.parse(review[1]),
            input.accept,
            input.reason,
            auth(),
          ),
        );
      }
      const verdict = route.match(/^\/moderation\/urls\/([^/]+)\/verdict$/);
      if (method === "POST" && verdict) {
        const input = z
          .object({
            verdict: z.enum(["safe", "malicious", "clear"]),
            reason: reasonSchema,
            valid_days: z.number().int().min(1).max(365).nullable().default(30),
          })
          .strict()
          .parse(await body(req));
        return json(
          await setVerdict(
            uuid.parse(verdict[1]),
            input.verdict,
            input.reason,
            input.valid_days,
            auth(),
          ),
        );
      }
    }
    if (route.startsWith("/admin/")) {
      requireRole(auth(), "admin");
      if (method === "GET" && route === "/admin/users")
        return json({
          items: await query(
            `SELECT u.user_id,u.email,u.display_name,u.status,u.email_verified_at,coalesce(array_agg(r.name) FILTER(WHERE r.name IS NOT NULL),'{}') roles FROM users u LEFT JOIN user_roles ur USING(user_id) LEFT JOIN roles r USING(role_id) GROUP BY u.user_id ORDER BY u.created_at DESC LIMIT 200`,
          ),
        });
      if (method === "GET" && route === "/admin/jobs")
        return json({
          items: await query(
            `SELECT event_id,event_type,aggregate_id,aggregate_version,status,attempts,available_at,last_error,created_at,processed_at FROM outbox_events ORDER BY created_at DESC,event_id DESC LIMIT 100`,
          ),
        });
      if (method === "GET" && route === "/admin/audit-logs")
        return json({
          items: await query(
            "SELECT * FROM audit_logs ORDER BY audit_id DESC LIMIT 100",
          ),
        });
      const status = route.match(/^\/admin\/users\/([^/]+)\/status$/);
      if (method === "PATCH" && status) {
        const id = uuid.parse(status[1]);
        const input = z
          .object({ status: z.enum(["active", "suspended"]) })
          .strict()
          .parse(await body(req));
        if (id === u!.user_id)
          throw new AppError(
            409,
            "You cannot suspend your own administrator account.",
          );
        await tx(async (db) => {
          await lockDomain(db);
          const { rows: target } = await db.query(
            "SELECT user_id FROM users WHERE user_id=$1",
            [id],
          );
          if (!target.length) throw new AppError(404, "Account not found.");
          await protectLastAdmin(db, id, input.status === "suspended");
          await db.query("UPDATE users SET status=$2 WHERE user_id=$1", [
            id,
            input.status,
          ]);
          await db.query(
            "UPDATE refresh_sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL",
            [id],
          );
          const { rows } = await db.query(
            "SELECT url_id FROM votes WHERE user_id=$1 UNION SELECT url_id FROM report_refs WHERE reporter_id=$1",
            [id],
          );
          const ids = rows.map((r) => r.url_id);
          await db.query(
            "DELETE FROM embeddings WHERE report_id IN(SELECT report_id FROM report_refs WHERE reporter_id=$1)",
            [id],
          );
          await db.query(
            `UPDATE urls SET public_summary='' WHERE url_id=ANY($1::uuid[])`,
            [ids],
          );
          await refreshRisk(db, ids, true);
          if (input.status === "active")
            await db.query(
              `UPDATE outbox_events SET status='pending',attempts=0,available_at=now(),processed_at=NULL WHERE event_type='embedding.report' AND aggregate_id IN(SELECT report_id FROM report_refs WHERE reporter_id=$1 AND workflow_status='accepted' AND sync_status='synced')`,
              [id],
            );
          await audit(db, u!.user_id, "user.status", "user", id, input);
        });
        return json({ message: "Account updated; existing sessions revoked" });
      }
      const role = route.match(
        /^\/admin\/users\/([^/]+)\/roles\/(user|moderator|admin)$/,
      );
      if (role && ["PUT", "DELETE"].includes(method)) {
        const id = uuid.parse(role[1]);
        if (role[2] === "user" && method === "DELETE")
          throw new AppError(400, "Every account retains the user role.");
        await tx(async (db) => {
          await lockDomain(db);
          if (method === "DELETE" && role[2] === "admin")
            await protectLastAdmin(db, id, true);
          if (method === "PUT")
            await db.query(
              `INSERT INTO user_roles(user_id,role_id,granted_by) SELECT $1,role_id,$2 FROM roles WHERE name=$3 ON CONFLICT DO NOTHING`,
              [id, u!.user_id, role[2]],
            );
          else
            await db.query(
              "DELETE FROM user_roles WHERE user_id=$1 AND role_id=(SELECT role_id FROM roles WHERE name=$2)",
              [id, role[2]],
            );
          await db.query(
            "UPDATE refresh_sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL",
            [id],
          );
          await audit(
            db,
            u!.user_id,
            `role.${method === "PUT" ? "granted" : "revoked"}`,
            "user",
            id,
            { role: role[2] },
          );
        });
        return json({ message: "Role updated; sessions revoked" });
      }
    }
    throw new AppError(
      404,
      "Endpoint not found. Enhanced features are not enabled.",
    );
  } catch (e) {
    if (e instanceof ZodError)
      return json(
        {
          error: "Check the submitted fields.",
          code: "validation_error",
          fields: e.issues.map((i) => ({
            field: i.path.join("."),
            message: i.message,
          })),
        },
        400,
      );
    if (e instanceof AppError)
      return json({ error: e.message, code: e.code }, e.status);
    const code = (e as { code?: string }).code;
    if (code === "23505")
      return json(
        { error: "This record already exists.", code: "conflict" },
        409,
      );
    if (code === "23503" || code === "23514")
      return json(
        {
          error: "The change violates a database integrity rule.",
          code: "integrity_error",
        },
        400,
      );
    // Log only a diagnostic code. Never expose SQL text, connection strings, hashes or report payloads.
    console.error("API operation failed:", code || "service_error");
    return json(
      {
        error:
          "A required service is unavailable. Check database setup and try again.",
        code: "service_unavailable",
      },
      503,
    );
  }
}
async function protectLastAdmin(
  db: import("./db").Sql,
  id: string,
  removing: boolean,
) {
  if (!removing) return;
  const { rows } = await db.query(
    `SELECT u.user_id FROM users u JOIN user_roles ur USING(user_id) JOIN roles r USING(role_id) WHERE r.name='admin' AND u.status='active'`,
  );
  if (rows.length === 1 && rows[0].user_id === id)
    throw new AppError(409, "At least one active administrator must remain.");
}
