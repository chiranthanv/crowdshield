"""Embedding starter. Install requirements and pin an actual model commit first.
Input: one redacted, token-bounded text string. Output: 384 normalized values.
This does not crawl, classify, or certify a URL.
"""
import os
from sentence_transformers import SentenceTransformer

MODEL = 'sentence-transformers/all-MiniLM-L6-v2'
REVISION = os.environ['EMBEDDING_MODEL_REVISION']  # exact downloaded commit hash
model = SentenceTransformer(MODEL, revision=REVISION)

def embed(text: str) -> list[float]:
    tokens = model.tokenizer.encode(text, add_special_tokens=True)
    if len(tokens) > model.max_seq_length:
        raise ValueError('Chunk this text before embedding; do not silently truncate')
    vector = model.encode(text, normalize_embeddings=True)
    assert vector.shape == (384,)
    return vector.tolist()

if __name__ == '__main__':
    import json
    print(json.dumps(embed('Parcel delivery message requesting a small redelivery payment.')))
