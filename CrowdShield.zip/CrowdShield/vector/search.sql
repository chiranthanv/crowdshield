-- Core API fixes $3 to 'report'. URL-context retrieval is enhanced.
-- App-driver parameters: $1 = one 384-value vector; $2 = project model version.
-- $3 = source kind ('url' or 'report'); $4 = result limit, capped at 50 by API.
-- Exact search is the correctness baseline. HNSW is approximate at scale.
SELECT e.embedding_id,e.url_id,e.report_id,
       1-(e.embedding <=> $1::vector) AS cosine_similarity
FROM embeddings e JOIN urls u USING(url_id)
LEFT JOIN report_refs r ON r.report_id=e.report_id
WHERE e.model_version=$2 AND e.source_kind=$3 AND NOT u.is_archived
  AND (e.source_kind='url' OR
       (r.workflow_status='accepted' AND r.sync_status='synced'
        AND e.content_version=r.content_version))
ORDER BY e.embedding <=> $1::vector
LIMIT $4;
-- URL jobs delete older URL embedding versions in the same SQL transaction.
-- Report updates delete/replace old embeddings after moderation and sync.
-- To exclude the query URL, add e.url_id<>$5. Group multiple chunks by report
-- (maximum chunk similarity) after overfetching; return one result per report.
-- For pgvector 0.8+, within the search transaction:
-- SET LOCAL hnsw.iterative_scan='strict_order';
-- SET LOCAL hnsw.ef_search=100;
-- Complex joins/filters can still reduce ANN recall; compare exact results.
