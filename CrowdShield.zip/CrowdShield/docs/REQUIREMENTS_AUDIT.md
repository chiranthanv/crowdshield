# CrowdShield assignment requirements audit

Student: Chiranthan V · PES2UG24CS138 · Section C  
Source: DBMS Experiential Learning Level 3 Project Requirements, supplied Word document.  
Audit started: 2 November 2026.

CrowdShield investigates suspicious links through community evidence, independent review, auditable risk history, and semantic retrieval. The course requires a functional database application, not every optional feature in the project's design catalog. The 31 core APIs implement the classroom scope; 37 optional APIs remain explicitly planned. This audit maps the supplied assignment to inspectable source and execution evidence.

## Requirement coverage

| Assignment requirement | Implementation and documentation | Verification |
| --- | --- | --- |
| Unique title and meaningful problem beyond CRUD | CrowdShield; [problem, objectives, scope](../CrowdShield_Complete_Design.md). Transactional outbox, moderation, vote integrity, score history, and semantic evidence retrieval. | Instructor must confirm title uniqueness within Section C. |
| Approved two-member team with both members contributing to database and application work | [Responsibilities and cross-review plan, section 23](../CrowdShield_Complete_Design.md). Chiranthan's details are recorded above. | Teammate identity, instructor approval, and authentic individual contributions require the students' records. A responsibility plan is not proof of completed contributions. |
| Mandatory PostgreSQL/MySQL plus NoSQL and/or vector database | PostgreSQL + MongoDB + pgvector. [Database choice and justification, sections 7, 10, 11](../CrowdShield_Complete_Design.md). SQL protects identities and workflow, MongoDB stores evidence narratives, vectors retrieve paraphrases. | The portable demo uses PostgreSQL WASM with pgvector and native MongoDB. [Docker configuration](../docker-compose.yml) targets native PostgreSQL 16 and authenticated MongoDB; this separate deployment must be tested where Docker is installed. |
| ER diagram, relational schema, entities, attributes, PKs, FKs, relationships, constraints | [Rendered ER diagram](../diagrams/er.svg), [editable model](../diagrams/er.mmd), [relationship list](../diagrams/relationships.txt), [SQL schema](../database/01_schema.sql), [entity dictionary and relational schema, sections 8–9](../CrowdShield_Complete_Design.md). | Existing consistency tests compare all 22 SQL entities and attributes with the diagram and dictionary. The Mermaid model was parsed and rendered successfully after correcting unique-key annotations. |
| NoSQL/vector data model, indexes, embeddings, metadata, retrieval | [MongoDB validators/indexes](../mongodb/01_collections.js), [sample documents](../mongodb/sample_documents.json), [vector search](../lib/server/search.ts), [model inference](../lib/server/embedding.ts). | Model inference executed locally: real 384-dimensional vector. Full integration checks verify current accepted evidence, model/source versions, and cosine retrieval. |
| Execute CREATE, ALTER, DROP, keys, constraints, indexes, views | [Schema](../database/01_schema.sql), [features](../database/02_features.sql), [safe database demonstration](../scripts/demo.ts). | Demonstration executes DDL in a rolled-back fixture; integration checks SQL constraints and restricted-role privileges. |
| INSERT, UPDATE, DELETE, SELECT | Reports, votes, withdrawals, moderation, account changes, and [demonstration](../scripts/demo.ts). Vote withdrawal performs an actual DELETE; report withdrawal retains auditable history. | Unit, API, database and browser suites; DML demo checks application history is preserved. |
| JOIN, GROUP BY, HAVING, ORDER BY, aggregates, subqueries | [35 reference SELECT queries](../database/04_queries.sql), [live analytics](../lib/server/analytics.ts), [demonstration output](../scripts/demo.ts). | Full harness executes all reference queries and prints joins, aggregates and subqueries. |
| At least four advanced concepts | Transactions, views, stored procedures/functions, triggers, indexing, full-text search, Mongo aggregation, vector similarity search. [Features](../database/02_features.sql), [worker](../workers/processor.ts), [search](../lib/server/search.ts). | Eight concepts are present; integration scenarios exercise transaction rollback, vote audit, risk procedure, search, aggregation, and real outage recovery. |
| Explain semantic search, if used | Accepted report text → pinned MiniLM ONNX model → normalized 384D chunks → pgvector with source/model metadata → cosine search with SQL eligibility checks. [Vector design, section 11](../CrowdShield_Complete_Design.md). | Real inference and HTTP/browser semantic searches; no substitute random vectors. |
| Functional Next.js web interface with relevant forms, tables, search, filters, dashboards | [Next.js pages](../app/), [screens](../components/screens.tsx), [shared UI](../components/ui.tsx): Home, Dashboard, URL Detail, Report, Moderation, Admin, Analytics, auth pages. | Browser suite exercises actual forms and navigation, including mobile overflow and runtime errors; screenshots are captured from the running app. |
| Database integration through backend/API | [Next.js route handler](../app/api/v1/[...path]/route.ts), [server API](../lib/server/api.ts), [database clients](../lib/server/db.ts), [current API catalog](implemented-api.json). | 31 core method/route contracts plus health; integration tests send real HTTP requests and inspect persisted data. |
| Environment configuration, no hard-coded sensitive credentials | [.env.example](../.env.example), [random private configuration generator](../scripts/env-init.mjs), [ignore rules](../.gitignore). | Private configuration, caches and dependencies excluded from Git. Portable trusted-loopback database addresses are not production credentials. |
| Authentication and minimum two roles | User, Moderator, Administrator; bcrypt password hashes, hashed opaque session cookies, renewal/revocation, local activation. [Authentication](../lib/server/auth.ts). | API tests check sessions, ownership, moderator/admin denial, suspended accounts, revoked sessions and origin protection. Local activation demonstrates token verification, not mailbox delivery. |
| Database validation, consistency and integrity | SQL CHECK/UNIQUE/PK/FK, Mongo JSON Schema, input schemas, ordered versioned outbox, idempotency, lease checks. [Validation](../lib/server/validation.ts), [domain transactions](../lib/server/domain.ts), [worker](../workers/processor.ts). | Duplicate vote/report tests, invalid data, rollback, Mongo outage/recovery and stale-version/lease tests. |
| Basic database and web security; no plaintext password storage | bcrypt, hashed session/activation tokens, parameterized SQL, RBAC, origin checks, output escaping, defanged submitted URLs, bounded rate limits, restricted native application role. | Unit/API tests and privilege checks. Private local configuration must contain connection secrets; account password values are hashed before database storage. |
| Problem, objectives, scope, functional requirements | [Design sections 1–4](../CrowdShield_Complete_Design.md). | Present; historical implementation claims are superseded by this audit and current execution evidence. |
| ER, relational schema, database justification, data dictionary, implementation, important queries | [Design sections 7–15, 17–19](../CrowdShield_Complete_Design.md), [SQL](../database/), [MongoDB](../mongodb/), [vector reference](../vector/). | Schema consistency checks and executed database/API checks. |
| System architecture | [Architecture diagram](../diagrams/architecture.png), [editable source](../diagrams/architecture.mmd), [design section 6](../CrowdShield_Complete_Design.md). | App/API/worker/store boundaries also exercised by failure/recovery tests. |
| Application screenshots and testing results | [Screenshots](../screenshots/), [browser results](browser-results.json), [integration results](integration-results.json), [privilege results](permissions-results.json). | Read timestamps to distinguish historical Linux evidence from the current Windows run. No historical result is relabeled as current. |
| Conclusion and future enhancements | [Design section 24](../CrowdShield_Complete_Design.md), [implementation report](../IMPLEMENTATION_REPORT.md). | Optional discussions, AI explanations, campaigns, uploads, notifications and production email are future scope, not course-required missing modules. |
| Git/GitHub, individual contributions, setup README | Dedicated Git repository initialized in CrowdShield; [README](../README.md) includes Docker and portable local setup. | GitHub URL and both members' genuine commits are required. No bot, fabricated history, backdated commits or invented teammate contributions are created by this audit. |
| Final demonstration and individual explanations | [9-minute storyline and viva preparation, appendices B–C](../CrowdShield_Complete_Design.md), [local startup guide](../README.md). | Students must rehearse and deliver the demonstration and explain their actual work. |
| Originality and substantially different design | Evidence provenance, versioned risk/coverage, independently moderated anchors and cross-database recovery are documented design decisions. | Students and instructor must confirm originality and section-level uniqueness. Code inspection alone cannot certify academic originality. |

## Current execution record

Fresh Windows checks and remaining failures are recorded here as the audit proceeds. Older packaged logs describe their original environment and remain historical until a successful current run replaces them.

- Real MiniLM inference: passed after the image-library security update, 384 dimensions. The combined integration run verifies normalization, stored content versions and actual semantic results.
- TypeScript and ESLint: passed on the final source and restored dependencies.
- Node unit tests: 9 passed. Python schema/document/scoring checks: 30 passed.
- ER diagram: 22 entities parsed and rendered successfully; unique-key annotations corrected to Mermaid `UK`.
- Security dependencies: Next.js 16.4.1 and React/React DOM 19.3.1 are pinned. A `sharp` 0.35.5 override removes vulnerable older image libraries while retaining the pinned text model. The production npm audit reports zero vulnerabilities. See the [official Next.js security update](https://nextjs.org/blog/nextjs-security-update-october-14-2026).
- Production Next.js 16.4.1 build: passed.
- Full database/API/browser verification: passed on Windows with Node 24.11.1, PostgreSQL 18.6 WASM/pgvector, native MongoDB 8.0.16 and Chrome 156.0.8078.76. All 31 API/database scenarios passed, including a real MongoDB stop/restart. Browser workflows passed and produced 11 fresh screenshots, which were visually reviewed.
- The combined run exposed and fixed a browser-test assumption about the total moderation queue size. The test now selects a specific report and proves its removal from the queue. The final run includes both API fixtures and browser checks; it does not rely on a separate browser-only seed.
- [Final Windows verification ledger](windows-verification.json), [API/database results](integration-results.json), [browser results](browser-results.json), [role permissions](permissions-results.json), and [production dependency audit](windows-dependency-audit.json) contain the current evidence. The ledger preserves the earlier browser assertion failure and records the successful retry with source hashes.
- Native Docker deployment: Docker is not installed on this computer.

## Application evidence

These images were captured from the actual production build on 2 November 2026, using invented reserved-domain data. The API test fixtures deliberately exercise rejected, suspended, withdrawn and retry states, so their counts need not match a fresh persistent demonstration seed.

![Home with live database totals](../screenshots/01_home.png)

![Dashboard and database processing](../screenshots/03_dashboard.png)

![Validated report submission form](../screenshots/04_report_form.png)

![URL evidence and risk history](../screenshots/05_url_detail.png)

![SQL and MongoDB analytics](../screenshots/06_analytics.png)

![Independent moderation](../screenshots/07_moderation.png)

![Administrator role and account controls](../screenshots/08_admin_accounts.png)

![Real semantic search results](../screenshots/11_semantic_search.png)

## Course administration and student actions

The implementation cannot establish instructor team approval, title uniqueness, teammate identity, academic originality, individual contribution history or an oral demonstration. Those items remain open until the students provide authentic evidence. The project must not be represented as fully submission-complete while they are outstanding.
