# Implemented API routes

All routes use `/api/v1`. JSON mutations require the configured same-origin Origin header. Cookie sessions are issued by login/registration. P = public; U = signed-in user; M = moderator/admin; A = admin. The server also enforces activation and ownership where applicable. This table describes implemented routes; enhanced design contracts remain in the original catalog.

| Method | Route | Access | Behavior |
|---|---|---|---|
| POST | `/api/v1/auth/register` | P | Register an account |
| POST | `/api/v1/auth/login` | P | Authenticate and create a session |
| POST | `/api/v1/auth/refresh` | Cookie | Renew the opaque server-side session and revoke its predecessor; no JWT |
| POST | `/api/v1/auth/logout` | U | Revoke the current session |
| POST | `/api/v1/auth/verify-email` | Token | Consume the local demo verification token; production delivery is enhanced |
| GET | `/api/v1/me` | U | Read own profile |
| GET | `/api/v1/me/contributions` | U | Read own report metadata and vote/report/reputation counts |
| POST | `/api/v1/urls` | U | GET: query and offset pagination; POST: normalize and create or resolve URL |
| POST | `/api/v1/urls/lookup` | P | Exact lookup without placing raw URL in an access-log query string |
| GET | `/api/v1/urls` | P | GET: query and offset pagination; POST: normalize and create or resolve URL |
| GET | `/api/v1/urls/{id}` | P | Read sanitized URL detail |
| GET | `/api/v1/urls/{id}/risk` | P | Read score, coverage, label, moderator_verdict and staleness |
| PUT | `/api/v1/urls/{id}/vote` | U | Create or change own verdict |
| DELETE | `/api/v1/urls/{id}/vote` | U | Withdraw own verdict |
| POST | `/api/v1/reports` | U | Queue a redacted report with idempotency key |
| GET | `/api/v1/reports/{id}` | U or M | Read owned or reviewable report, including sync state |
| DELETE | `/api/v1/reports/{id}` | Owner | Withdraw report and invalidate derived content |
| GET | `/api/v1/urls/{id}/reports` | P | List public eligible reports plus owned or reviewer-visible metadata |
| GET | `/api/v1/search/text` | P | Search safe hostname and public summary |
| POST | `/api/v1/search/semantic` | U | Retrieve authorized current accepted report matches; core source_kind is report |
| GET | `/api/v1/analytics/overview` | P | Read public aggregate dashboard |
| GET | `/api/v1/analytics/trends` | P | Read a fixed 14-day SQL trend and eligible MongoDB aggregates |
| GET | `/api/v1/moderation/reports` | M | Read pending report metadata; review requires synchronized content |
| POST | `/api/v1/moderation/reports/{id}/decision` | M | Accept or reject with a reason |
| POST | `/api/v1/moderation/urls/{id}/verdict` | M | Set or clear a time-bounded reviewed verdict |
| GET | `/api/v1/admin/users` | A | List accounts without secrets |
| PATCH | `/api/v1/admin/users/{id}/status` | A | Suspend or restore account and invalidate scores |
| PUT | `/api/v1/admin/users/{id}/roles/{role}` | A | Grant an allowed role |
| DELETE | `/api/v1/admin/users/{id}/roles/{role}` | A | Revoke role while protecting final admin |
| GET | `/api/v1/admin/audit-logs` | A | Read the latest 100 audit entries |
| GET | `/api/v1/admin/jobs` | A | Read latest outbox delivery states without private payloads |
| GET | `/api/v1/health` | P | Process liveness; does not assert database readiness |
