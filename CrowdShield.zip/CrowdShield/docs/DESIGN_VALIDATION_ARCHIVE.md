# Validation status

Revised 30 September 2026. This file separates executed checks from planned integration testing.

## Executed successfully

- Ten standard-library Python tests of scoring arithmetic: no-evidence behavior, worked example, safe and malicious moderator overrides, clear decision, bounds, reputation clamping, per-reporter cap, and vote-direction monotonicity.
- Ten static package checks: 22 unique tables; referenced table names; ER table coverage; 15+5+5+5+5 query-category counts; 68 unique method-route pairs; 45 unique acceptance-test IDs; all 24 report sections; five sample MongoDB document types and key references; vector dimension/version contract; and idempotency/version fields.
- Ten cross-artifact consistency checks: every SQL/ER/report attribute and type; scope coverage; API and acceptance-test tables against JSON; MongoDB examples; risk fields and example precision; seven core pages; verification boundaries; and vector versions/authorization predicates. Total Python checks: 30 passed.
- JavaScript syntax checks for the three mongosh files using Node's parser. This does not execute MongoDB commands or validate server-specific behavior.
- JSON decoding for API contracts, test cases, and MongoDB sample documents.
- Baseline preservation comparison for table definitions and procedure logic apart from the coverage rename, all API method-route identities, all 45 test IDs, MongoDB samples and the embedding starter. All 35 SQL query IDs remain; S10 was adjusted to the revised retry-state contract.
- Word report rendered to 45 pages and each page visually reviewed. Tables, diagrams, SQL examples and page breaks are readable, with no observed overlapping or clipped content. This is document quality assurance, not application test evidence.

## Not executed in the preparation environment

- PostgreSQL DDL, the optional coverage migration, triggers, stored procedures, DML, query plans, concurrency, and SQL integration assertions. No PostgreSQL/pgvector server was used.
- MongoDB validators, seed insertion, aggregation pipelines, document transactions, or outbox integration. No MongoDB server was available.
- Embedding model download/inference, semantic relevance, HNSW recall, or AI-provider calls.
- Next.js UI, API implementation, browser security testing, end-to-end workflows, backup restoration, or load tests.

All 45 application acceptance cases remain **planned until execution**, with 25 core and 20 enhanced. Their actual-result and evidence fields are null. The 30 offline checks are not substitutes for those acceptance cases.

The SQL and MongoDB files are implementation examples to execute and verify in the team's development environment; static inspection and arithmetic tests do not establish that they are production-ready. No accuracy, latency, grade, or complete application test result is claimed.

## Commands

```bash
python -m unittest discover -s tests -p 'test_*.py' -v
node --check mongodb/01_collections.js
node --check mongodb/02_seed.js
node --check mongodb/03_aggregations.js
```

After installing and configuring the databases, follow README.md, execute `tests/constraints.sql`, and fill in actual results for `tests/test_plan.json`. Record the tested commit, exact dependency versions, hardware, dataset size, and screenshots.
