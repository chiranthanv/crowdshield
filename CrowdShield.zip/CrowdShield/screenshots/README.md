# Real application screenshots

Captured on 2 November 2026 from the production Next.js 16.4.1 app connected to a disposable PostgreSQL WASM/pgvector engine and native MongoDB 8.0.16 on Windows. Browser: Chrome 156.0.8078.76. All account names, addresses and evidence are invented seed data. Capture time and executed UI checks are recorded in [the browser results](../docs/browser-results.json).

| File | Demonstrated screen |
|---|---|
| 01_home.png | Live totals, lookup and recent URLs |
| 02_unknown_url.png | No-evidence score 37.5 and coverage zero |
| 03_dashboard.png | Contributions and database processing |
| 04_report_form.png | Connected submission form |
| 05_url_detail.png | Votes, evidence, score components and history |
| 06_analytics.png | SQL trends and Mongo aggregates |
| 07_moderation.png | Synchronized report content and review controls |
| 08_admin_accounts.png | Account and role management |
| 09_admin_jobs.png | Real outbox delivery history |
| 10_mobile_home.png | Mobile layout at 390px viewport |
| 11_semantic_search.png | Real model cosine-search results |

Screenshots 01–07 precede the browser test's moderator acceptance; later images reflect that action and removal of the seeded URL override. The combined run includes API test fixtures, so counts can differ from a fresh persistent demo seed. Tables on mobile scroll within their panels. All 11 captures were visually reviewed; they are actual local execution evidence.
