# CrowdShield — implementation and verification report

> For the 2 November 2026 Windows audit, see [the assignment requirements audit](docs/REQUIREMENTS_AUDIT.md). The dated results below describe the original verification environment; current test-result JSON files carry their own execution timestamps. The API design catalog now marks implemented core routes explicitly.

Implementation completed 13 October 2026. This is the current status of the working core application. The original revised report, ER diagram, relational schema, reference queries and enhanced scope remain in the package.

## Delivered application

The application connects a Next.js/TypeScript interface and `/api/v1` route handlers to PostgreSQL, MongoDB and pgvector. A separate Node.js worker delivers versioned reports and creates real report embeddings. It is designed for a local two-member college demonstration. No paid AI service, website crawling or message broker is required.

| Area | Implemented behavior | Executed evidence |
|---|---|---|
| Home / URL lookup | Exact URL lookup, PostgreSQL text search, semantic evidence search, live totals and risk distribution | API and browser checks |
| Dashboard | Own contributions, reputation, report delivery state and database/job status | API and browser checks |
| URL detail | Defanged URL, votes, report content, coverage, numerical score, components, history, similar evidence and reviewer verdict control | API and browser checks |
| Report scam | Validation, basic redaction, idempotency and atomic SQL metadata/outbox submission | API and browser checks |
| Moderation | Pending queue, synchronized evidence, reasoned accept/reject and separate reviewed verdict | API and browser checks |
| Admin | Accounts, role/status changes, session invalidation, jobs and audit trail | API checks; browser rendering |
| Analytics | SQL aggregates and MongoDB aggregation over eligible report documents | Database, API and browser checks |
| Authentication | Register, local activation, login, renew session, logout, ownership and three roles | Unit and API checks; browser login |
| Background processing | Leases, ordered document versions, retries, parked failures, embeddings and periodic score refresh | Database/API failure and recovery checks |

All 31 core method/route contracts have handlers. `GET /api/v1/health` is an additional process-liveness endpoint. See `docs/implemented-api.json` for the current descriptions and `docs/IMPLEMENTED_API.md` for the route table. The `api_endpoints.json` catalog marks the 31 core contracts implemented and the 37 enhanced contracts planned. Its core descriptions are synchronized with the current runtime catalog, including opaque session renewal.

## Database design remains authoritative

`database/01_schema.sql` and `database/02_features.sql` are the existing revised design, with 22 tables and their constraints, views, trigger and procedures. No parallel replacement schema was introduced. SQL UUIDs also identify MongoDB documents; cross-database integrity is enforced by application checks and the outbox rather than an impossible cross-engine foreign key.

The five MongoDB collection validators and indexes are installed. Only `scam_reports` participates in the working core UI. Discussions, comments, evidence files and campaign collections remain prepared for enhanced features. The original 35 SELECT examples, DML/DDL examples, four MongoDB aggregation examples and SQL constraints assertions executed successfully in the test environment described below. Executing the campaign aggregation syntax does not demonstrate a campaign application.

`npm run db:setup` installs the original schema on a fresh database and a restricted application role. It grants category insertion for the documented seed, denies schema creation, and does not grant modification/deletion of audit or score history. The API and worker share this application role in the student implementation; the owner connection is reserved for setup and the DDL demonstration. Permission checks were executed under `SET LOCAL ROLE crowdshield_app`; native connection authentication was not exercised here.

### Advanced DBMS features actually connected

| Concept | Application use | Demonstration |
|---|---|---|
| Transactions | URL, report reference and outbox commit together | Forced rollback leaves no partial submission |
| Constraints | Unique URL identity, one vote/user/URL, report idempotency, foreign keys and checks | SQL assertions and duplicate/invalid submissions |
| Trigger | Vote changes write audit entries and schedule score refresh | Insert/change/withdraw vote integration test |
| Stored procedures | `moderate_report` and `recalculate_risk` | Moderator and risk endpoints invoke the original procedures |
| Views | Current risk, reputation, effective verdict and URL summaries | Dashboard, URL detail and risk processing |
| Indexes and full-text search | SQL lookup/search, queue and identity indexes; vector index retained | Search APIs and schema execution; no performance benchmark claimed |
| NoSQL aggregation | Accepted evidence types, dates and contributors | Real MongoDB aggregation and Analytics |
| Vector similarity | 384-dimensional embeddings and cosine distance | Real model inference, stored vectors and semantic query results |

`npm run db:demo` executes CREATE/ALTER/DROP and INSERT/UPDATE/DELETE/SELECT on a fixture inside a transaction that is rolled back, runs all 35 reference queries, and prints JOIN/GROUP BY/HAVING/subquery results. It preserves application history and uses the owner connection.

## Cross-database synchronization

1. The API validates input, redacts obvious sensitive patterns and normalizes the URL without discarding meaningful path/query differences.
2. One SQL transaction resolves the URL, creates `report_refs`, and inserts a `report.created` outbox record. An idempotency key and request hash detect safe replay versus conflicting reuse.
3. The response truthfully reports a committed SQL record with pending document delivery.
4. The worker claims a ready job using `FOR UPDATE SKIP LOCKED`, a lease UUID and a five-minute lease. Earlier versions of the same report must finish first.
5. MongoDB uses the report UUID as `_id`; repeat delivery cannot create another identity. Conditional version updates stop older events from overwriting newer content.
6. SQL completion requires the current lease token. Report synchronization is acknowledged only for the matching content version.
7. Failures retry with exponential delay, capped at five minutes, up to eight attempts. Exhausted jobs remain visible as failed and can be deliberately retried by the local operator.

This is **at-least-once delivery with idempotent effects**, not a distributed transaction or a general exactly-once guarantee. The executed outage test stopped the real MongoDB process, observed pending retry state, restarted it, and verified one document plus synchronized SQL state. Separate tests covered stale versions, stale lease completion, withdrawal visibility and transaction rollback. README section 5 gives the Docker demonstration commands.

## Risk and vector consistency

`recalculate_risk` is the only production scoring implementation. The API and interface display its results; there is no second JavaScript formula.

The preserved base heuristic is `100 × (0.55 × community + 0.25 × reports + 0.20 × reviewed_similarity)`. Community evidence uses bounded reputation weights and a neutral prior. Report evidence caps each eligible reporter's contribution and decays over a 30-day window. Similarity uses up to five recent qualifying neighbors with human safe/malicious verdicts. A current human verdict overrides the score to 95 for malicious or 5 for safe. A clear/expired latest verdict does not revive an older verdict.

Coverage remains `min(1, (distinct_contributors + 2 × anchors) / 10)`, or 1 for an effective reviewed verdict. Coverage is an evidence indicator, not statistical confidence. Coverage below 0.3 gives `insufficient_evidence`. A URL with no evidence has score **37.5**, coverage **0**, and the insufficient-evidence label. History retains `crowdshield-v1` and its inputs.

The worker uses `Xenova/all-MiniLM-L6-v2`, revision `751bff37182d3f1213fa05d7196b954e230abad9`, through Transformers.js/ONNX on the CPU. This is the compatible ONNX export of the design's MiniLM model. It produces normalized 384-dimensional vectors with mean pooling. Report text is chunked with overlap; query and report vectors use the same model. Stored model version remains `minilm-l6-v2:project-v1`, alongside source version, chunk number and content hash.

Public vector results require a current accepted, synchronized report from an active, activated account on an unarchived URL. The code checks SQL eligibility and version again after reading MongoDB. Withdrawn/suspended evidence is invalidated; fake or random vectors are never substituted. Similarity is an investigative lead, not proof of maliciousness. The small-data implementation uses exact cosine search; the retained HNSW index is available for database study, but its recall and performance were not benchmarked.

## Authentication and implementation adjustments

The implementation brief allowed straightforward secure sessions. Consequently, the running app uses a random opaque HttpOnly cookie and a SQL hash in the existing `refresh_sessions` table, rather than the original JWT proposal. Sessions expire after 12 hours; renewal revokes the old token atomically. Logout and administrative role/status changes revoke sessions. Server-side checks read current roles and account state.

Passwords use bcrypt with cost 12 and a 72-byte input limit. Mutations check Origin and Fetch-Site; cookies are SameSite Strict and become Secure on HTTPS. Parameterized queries, input validation, React text rendering, defanged URLs, security headers and bounded in-process rate limits are implemented. Local HTTP is intentionally supported for the classroom workflow. The CSP retains inline script/style allowances required by this simple Next.js setup; it is not a strict nonce-based production CSP.

Local verification tokens expire in 30 minutes, are single-use and are hashed in SQL. Their delivery is an operator CLI/private local file, not email. This activates demo contribution eligibility; it does not prove mailbox ownership. The Node worker replaces the Python embedding starter for the working runtime; the Python reference remains preserved. Basic redaction is a convenience, not comprehensive personal-data detection: users must submit already-redacted invented evidence.

## Actual execution and evidence

Tests ran on 13 October 2026 in a Linux workspace with Node 24.19.0. Exact application dependency versions are pinned in `package-lock.json`. The test harness used **PostgreSQL 18.6 compiled to WASM through PGlite 0.5.9 with pgvector**, plus a **native MongoDB 8.0.16 process** and the production Next.js server. This is a real PostgreSQL engine executing the SQL, but it is not a native PostgreSQL service or the Docker target.

| Check | Result | Evidence |
|---|---|---|
| Original Python arithmetic/static/consistency tests | 30 passed | `docs/static-checks.log` |
| Node unit tests | 9 passed | `docs/static-checks.log` |
| TypeScript and ESLint | Passed | `docs/static-checks.log` |
| Production Next.js build | Passed | `docs/build.log` |
| HTTP/database integration scenarios | 31 passed, including actual MongoDB outage/recovery | `docs/integration-results.json` |
| Application-role privilege checks | Passed on WASM PostgreSQL | `docs/permissions-results.json` |
| DDL/DML demonstration CLI | Executed successfully | Full harness output and `scripts/demo.ts` |
| Browser workflows | Passed; actual Chromium version recorded | `docs/browser-results.json` |
| Real application screenshots | Captured, reviewed and included | `screenshots/` |

The first browser download route returned an unavailable-site page. Verification used an actual Chromium 153 binary supplied by `@sparticuz/chromium` 153.0.0 through the same Playwright tests. It is a test-environment fallback only, not an application dependency or a shipped browser. Users normally run `npx playwright install chromium`; `PLAYWRIGHT_CHROMIUM_EXECUTABLE` supports an existing compatible local binary when necessary.

The preserved 45-case acceptance plan is historical and remains marked planned. Its IDs and expected results are retained for the college report. The separate executed logs above are the evidence for this implementation; these two test inventories must not be conflated.

### Not executed or established

- Docker Compose startup, native PostgreSQL 16/pgvector and MongoDB authentication on the student's operating system. Native installation was unavailable in this workspace. Run the README setup and demo before presenting locally.
- The legacy-only `07_coverage_migration.sql` against an old installation; fresh installs already use coverage.
- Native PostgreSQL multi-session concurrency, load/latency benchmarks, HNSW recall, backups/restoration and production deployment hardening.
- Full accessibility auditing, all device/browser combinations, adversarial security assessment or measured phishing-detection accuracy.

The application serializes small-demo evidence mutations with an advisory transaction lock. The worker periodically recomputes scores and similarity edges. Both choices keep the student implementation understandable and require redesign/measurement before large-scale deployment. Health reports process liveness; Dashboard/API data calls provide database availability. In-memory rate limits assume one local API process.

## Enhanced components remain unimplemented

Discussions/comments, AI-generated explanations, campaign clustering, email delivery, file uploads/scanning, external feeds, browser extensions, production object storage, notification UI and CSV exports are outside the delivered core. Their original schema/reference material is retained. The working semantic search uses ML embeddings; it does not imply that a generative AI analysis feature exists.

## Submission and two-member handoff

Submit the original revised project report together with this implementation report, source ZIP, setup guide and actual screenshots/test evidence. Add your college cover page, names, IDs and your own local demonstration evidence according to your department's format. Professor acceptance and grading criteria have not been verified.

Member 1 should own SQL/Mongo setup, authentication/API, outbox/retry, moderation/risk and failure demonstrations. Member 2 should own the interface, vector model/search, analytics presentation, browser checks and screenshots. Both should be able to explain the schema, the transaction boundary, source-version checks, risk-versus-coverage distinction and the limitations of semantic similarity.

The delivered core is a realistic one-month demonstration scope for two students who work through the supplied implementation and reserve time for setup and viva preparation. The entire original enhanced feature list is substantially larger. Keep the remaining month focused on running, understanding, testing and presenting the core.
