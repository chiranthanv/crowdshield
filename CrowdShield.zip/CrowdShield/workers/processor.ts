import { randomUUID } from "node:crypto";
import {
  query,
  tx,
  reportCollection,
  type Sql,
  type ReportDoc,
} from "../lib/server/db";
import { lockDomain, refreshRisk, eligibleSql } from "../lib/server/domain";
import { embedChunks, vectorSql } from "../lib/server/embedding";
import { config } from "../lib/server/config";
import { sha } from "../lib/server/validation";
export type Job = {
  event_id: string;
  event_type: string;
  aggregate_id: string;
  aggregate_version: number;
  payload: any;
  lease_token: string;
  attempts: number;
};
export async function claim(): Promise<Job | undefined> {
  return tx(async (db) => {
    const expired = await db.query(
      `UPDATE outbox_events SET status='failed',last_error='Worker lease expired after maximum attempts',lease_token=NULL WHERE status='processing' AND locked_at<now()-interval '5 minutes' AND attempts>=8 RETURNING *`,
    );
    for (const e of expired.rows)
      if (e.event_type.startsWith("report."))
        await db.query(
          `UPDATE report_refs SET sync_status='failed' WHERE report_id=$1 AND content_version=$2`,
          [e.aggregate_id, e.aggregate_version],
        );
    const { rows } = await db.query(
      `WITH candidate AS(SELECT event_id FROM outbox_events o
 WHERE ((status='pending' AND available_at<=now()) OR (status='processing' AND locked_at<now()-interval '5 minutes')) AND attempts<8
 AND (event_type NOT LIKE 'report.%' OR NOT EXISTS(SELECT 1 FROM outbox_events earlier WHERE earlier.aggregate_id=o.aggregate_id AND earlier.event_type LIKE 'report.%' AND earlier.aggregate_version<o.aggregate_version AND earlier.status<>'done'))
 ORDER BY created_at,event_id FOR UPDATE SKIP LOCKED LIMIT 1)
 UPDATE outbox_events o SET status='processing',locked_at=now(),lease_token=$1,attempts=attempts+1 FROM candidate c WHERE o.event_id=c.event_id RETURNING o.*`,
      [randomUUID()],
    );
    return rows[0];
  });
}
async function owns(db: Sql, j: Job) {
  const { rows } = await db.query(
    `SELECT event_id FROM outbox_events WHERE event_id=$1 AND lease_token=$2 AND status='processing' FOR UPDATE`,
    [j.event_id, j.lease_token],
  );
  return rows.length > 0;
}
async function done(db: Sql, j: Job) {
  await db.query(
    `UPDATE outbox_events SET status='done',processed_at=now(),locked_at=NULL,lease_token=NULL,last_error=NULL WHERE event_id=$1 AND lease_token=$2`,
    [j.event_id, j.lease_token],
  );
}
export async function deliverReport(j: Job) {
  const col = await reportCollection();
  const version = j.aggregate_version;
  if (j.event_type === "report.created") {
    const payload = {
      ...j.payload,
      created_at: new Date(j.payload.created_at),
      updated_at: new Date(j.payload.updated_at),
    } as ReportDoc;
    await col.updateOne(
      { _id: j.aggregate_id },
      { $setOnInsert: payload },
      { upsert: true },
    );
    const existing = await col.findOne({ _id: j.aggregate_id });
    if (!existing || existing.content_version < version)
      throw new Error("Document version has not reached the event version");
    if (
      existing.url_id !== payload.url_id ||
      existing.reporter_id !== payload.reporter_id ||
      existing.message_text !== payload.message_text
    )
      throw new Error("Document identity/content mismatch");
  } else {
    const doc = await col.findOne({ _id: j.aggregate_id });
    if (!doc) throw new Error("Report predecessor is not synchronized");
    if (doc.content_version === version - 1)
      await col.updateOne(
        { _id: j.aggregate_id, content_version: version - 1 },
        {
          $set: {
            workflow_status: j.payload.workflow_status,
            content_version: version,
            updated_at: new Date(),
          },
        },
      );
    const current = await col.findOne({ _id: j.aggregate_id });
    if (!current || current.content_version < version)
      throw new Error("Report predecessor version is missing");
    if (
      current.content_version === version &&
      current.workflow_status !== j.payload.workflow_status
    )
      throw new Error("Conflicting document version");
  }
  const delivered = await col.findOne({ _id: j.aggregate_id });
  await tx(async (db) => {
    await lockDomain(db);
    if (!(await owns(db, j))) return;
    const { rows } = await db.query(
      `UPDATE report_refs SET sync_status='synced',updated_at=now() WHERE report_id=$1 AND content_version=$2 RETURNING *`,
      [j.aggregate_id, version],
    );
    if (rows.length) {
      const r = rows[0];
      await db.query("DELETE FROM embeddings WHERE report_id=$1", [
        r.report_id,
      ]);
      await db.query("UPDATE urls SET public_summary=$2 WHERE url_id=$1", [
        r.url_id,
        r.workflow_status === "accepted"
          ? (delivered?.message_text || "").slice(0, 500)
          : "",
      ]);
      await refreshRisk(db, [r.url_id], true);
      if (r.workflow_status === "accepted")
        await db.query(
          `INSERT INTO outbox_events(event_type,aggregate_id,aggregate_version,payload) VALUES('embedding.report',$1,$2,'{}') ON CONFLICT DO NOTHING`,
          [r.report_id, version],
        );
    }
    await done(db, j);
  });
}
export async function rebuildEdges(db: Sql) {
  await db.query("DELETE FROM similarity_edges WHERE model_version=$1", [
    config.modelVersion,
  ]);
  await db.query(
    `WITH valid AS(SELECT e.url_id,e.embedding FROM embeddings e JOIN report_refs r ON r.report_id=e.report_id JOIN urls u ON u.url_id=e.url_id JOIN users owner ON owner.user_id=r.reporter_id
 WHERE ${eligibleSql} AND e.source_kind='report' AND e.model_version=$1 AND e.content_version=r.content_version)
 INSERT INTO similarity_edges(url_id,neighbor_url_id,model_version,similarity)
 SELECT a.url_id,b.url_id,$1,least(1,greatest(-1,max(1-(a.embedding <=> b.embedding)))) FROM valid a JOIN valid b ON a.url_id<>b.url_id
 GROUP BY a.url_id,b.url_id HAVING max(1-(a.embedding <=> b.embedding))>=0.75`,
    [config.modelVersion],
  );
}
async function embedReport(j: Job) {
  const [r] = await query(
    `SELECT r.* FROM report_refs r JOIN urls u USING(url_id) JOIN users owner ON owner.user_id=r.reporter_id WHERE r.report_id=$1 AND r.content_version=$2 AND ${eligibleSql}`,
    [j.aggregate_id, j.aggregate_version],
  );
  if (!r) {
    await tx(async (db) => {
      if (await owns(db, j)) await done(db, j);
    });
    return;
  }
  const doc = await (
    await reportCollection()
  ).findOne({
    _id: r.report_id,
    content_version: r.content_version,
    workflow_status: "accepted",
  });
  if (!doc) throw new Error("Eligible report document version unavailable");
  const chunks = await embedChunks(doc.message_text);
  await tx(async (db) => {
    await lockDomain(db);
    if (!(await owns(db, j))) return;
    const { rows } = await db.query(
      `SELECT r.report_id FROM report_refs r JOIN urls u USING(url_id) JOIN users owner ON owner.user_id=r.reporter_id WHERE r.report_id=$1 AND r.content_version=$2 AND ${eligibleSql}`,
      [j.aggregate_id, j.aggregate_version],
    );
    if (rows.length) {
      await db.query("DELETE FROM embeddings WHERE report_id=$1", [
        r.report_id,
      ]);
      for (let i = 0; i < chunks.length; i++)
        await db.query(
          `INSERT INTO embeddings(url_id,report_id,source_kind,model_version,content_version,chunk_no,content_hash,embedding,metadata) VALUES($1,$2,'report',$3,$4,$5,$6,$7::vector,$8)`,
          [
            r.url_id,
            r.report_id,
            config.modelVersion,
            r.content_version,
            i,
            sha(chunks[i].text),
            vectorSql(chunks[i].vector),
            JSON.stringify({
              model_id: config.modelId,
              model_revision: config.modelRevision,
              dimensions: 384,
              pooling: "mean",
              normalized: true,
            }),
          ],
        );
      await rebuildEdges(db);
      const { rows: urls } = await db.query(
        "SELECT url_id FROM urls WHERE NOT is_archived",
      );
      await refreshRisk(
        db,
        urls.map((u) => u.url_id),
      );
    }
    await done(db, j);
  });
}
export async function processJob(j: Job) {
  try {
    if (j.event_type.startsWith("report.")) await deliverReport(j);
    else if (j.event_type === "embedding.report") await embedReport(j);
    else if (j.event_type === "risk.refresh")
      await tx(async (db) => {
        await lockDomain(db);
        if (!(await owns(db, j))) return;
        await db.query("CALL recalculate_risk($1)", [j.aggregate_id]);
        await done(db, j);
      });
    else throw new Error("Unsupported event type");
    return true;
  } catch (error) {
    const parked = j.attempts >= 8;
    const delay = Math.min(300, 2 ** j.attempts);
    // Do not persist connection strings, raw reports or driver details in public operational messages.
    const message =
      (error as { code?: string }).code === "model_unavailable"
        ? "Embedding model unavailable"
        : j.event_type.startsWith("report.")
          ? "Document delivery unavailable or version conflict"
          : "Job processing failed";
    await tx(async (db) => {
      if (!(await owns(db, j))) return;
      await db.query(
        `UPDATE outbox_events SET status=$3,available_at=now()+$4*interval '1 second',last_error=$5,locked_at=NULL,lease_token=NULL WHERE event_id=$1 AND lease_token=$2`,
        [
          j.event_id,
          j.lease_token,
          parked ? "failed" : "pending",
          delay,
          message,
        ],
      );
      if (parked && j.event_type.startsWith("report."))
        await db.query(
          `UPDATE report_refs SET sync_status='failed' WHERE report_id=$1 AND content_version=$2`,
          [j.aggregate_id, j.aggregate_version],
        );
    });
    console.error(`Job ${j.event_type} ${j.event_id}: ${message}`);
    return false;
  }
}
export async function runOnce(max = 100) {
  let count = 0;
  while (count < max) {
    const j = await claim();
    if (!j) break;
    await processJob(j);
    count++;
  }
  return count;
}
export async function sweep() {
  await tx(async (db) => {
    await lockDomain(db);
    // Refresh expiring human verdicts, rolling report weights and seven-day similarity anchors.
    const { rows } = await db.query(
      "SELECT url_id FROM urls WHERE NOT is_archived",
    );
    await rebuildEdges(db);
    await refreshRisk(
      db,
      rows.map((r) => r.url_id),
    );
  });
}
