import "dotenv/config";
import { runOnce, sweep } from "./processor";
import { closeDb } from "../lib/server/db";
let running = true;
for (const s of ["SIGINT", "SIGTERM"])
  process.on(s, () => {
    running = false;
  });
try {
  if (process.argv.includes("--once"))
    console.log(`Processed ${await runOnce()} jobs`);
  else {
    console.log("CrowdShield worker started. Ctrl+C to stop.");
    let nextSweep = 0;
    while (running) {
      try {
        await runOnce();
        if (Date.now() > nextSweep) {
          await sweep();
          nextSweep = Date.now() + 300000;
        }
      } catch {
        console.error("Worker cannot reach the database; retrying.");
      }
      await new Promise((r) => setTimeout(r, 1500));
    }
  }
} finally {
  await closeDb();
}
