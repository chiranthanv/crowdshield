# CrowdShield implementation status

## Current Windows verification 2 November 2026

The final local run passed TypeScript, ESLint, 9 Node unit tests, 30 Python checks, the Next.js production build, 31 live database/API scenarios, and browser workflows with 11 fresh screenshots. See [the verification ledger](docs/windows-verification.json), [current validation](VALIDATION.md), and [the assignment audit](docs/REQUIREMENTS_AUDIT.md). The log below preserves the original implementation history.

Security dependencies are pinned to Next.js 16.4.1, React/React DOM 19.3.1, and sharp 0.35.5; the production dependency audit reports zero vulnerabilities. The real MiniLM model continues to produce normalized 384-dimensional vectors. The ER model uses valid Mermaid unique-key annotations and is also provided as an SVG. Core API statuses and descriptions match their implemented session-based contracts.

Windows fixes include standalone browser/integration entrypoint path handling, omitting MongoDB's Unix-only socket option on Windows, cleaning up test services when startup fails, and targeting a specific moderation card instead of assuming a global queue count. The combined API and browser run passes together.

The persistent portable demo launches databases, app and worker through `npm.cmd run demo:local`; `-- --production` serves the verified build. Native Docker/PostgreSQL authentication remains a separate untested target. Team approval, teammate details, section-title uniqueness and authentic GitHub contributions require student/instructor evidence.

Started 13 October 2026. Working tree: this directory. Baseline ZIP extracted to ../implementation_baseline.

## Implementation checklist
- [x] Inspect starter schema, views/procedures, seeds, Mongo validators, vector contract, tests and scope.
- [x] Create pinned Next.js/TypeScript application and reproducible database setup.
- [x] Implement password hashing, revocable sessions, CSRF/origin checks, RBAC and ownership.
- [x] Implement URL normalization, lookup/full-text search, reports and idempotent transactional outbox.
- [x] Implement leased worker, Mongo version checks, retry and failure recovery.
- [x] Connect voting/moderation to existing SQL risk procedure and score history.
- [x] Implement real 384-dimensional embeddings and authorized pgvector search.
- [x] Connect seven core page areas, login/registration and unavailable states.
- [x] Execute Python, unit/integration, type, lint, build and browser checks.
- [x] Capture genuine application screenshots; document test evidence and any blockers.
- [x] Prepare source release, setup commands and implementation report.

## Decisions
- Existing 22-table schema is authoritative; new changes use explicit migrations.
- SQL recalculate_risk remains the sole production scoring implementation.
- Core local account activation will remain available to satisfy the existing verified-contributor predicate; no production email or custom token rotation is required.
- A server-side opaque session uses the existing refresh_sessions table; only token hashes are stored.
- Enhanced modules remain disabled. No website crawling, paid AI or fake embeddings.

## Inspection and environment
ZIP integrity checked: 31 files, no corrupt entries. Existing sources retained.
Node 24.19.0 is available. Docker, PostgreSQL and MongoDB executables were not initially present.
Initial step was application scaffolding and dependency installation; see the completed milestones below for current status.

### Milestone 1 — application foundation
Created package.json, TypeScript/Next/ESLint configuration, SQL/Mongo clients, validation/redaction, sessions, role checks and local token verification. Next.js 16.4.0 installed; model export pinned to verified revision 751bff37182d3f1213fa05d7196b954e230abad9. Native service installation is blocked by this container's uid/group capabilities. Investigating embedded PostgreSQL test engine and a real MongoDB test binary. Initial ONNX optional binary installer hit a proxy timeout; retrying with package-provided CPU binaries and no installer scripts. No database test is claimed yet.

### Milestone 2 — core application connected
Implemented seven page areas plus login/registration/verification, Next.js API dispatch, server-side RBAC/ownership, secure password hashing and hashed revocable cookies, URL normalization, idempotent reports, one-vote constraints, moderation and existing SQL risk scoring. Implemented Mongo outbox claims/version checks/lease acknowledgments/retries, real MiniLM ONNX embeddings, SQL text/vector search and SQL/Mongo analytics. Added Docker service configuration, private env generator, database setup and seed workflow.

Executed: production build PASS; TypeScript PASS; ESLint PASS; 9 Node unit tests PASS; existing 30 Python checks PASS. Real MiniLM model produced a normalized 384-dimensional vector. Original schema/procedures and runtime seed executed against PostgreSQL 18.6 WASM (PGlite 0.5.9), pgvector and native MongoDB 8.0.16; three seeded reports synchronized with no pending records. Native PostgreSQL/Docker is still unavailable here. TCP services must run in a common tool execution scope, so the full test harness starts databases, app and browser together.

### Milestone 3 — integrated verification complete

Executed 31 HTTP/database integration scenarios successfully, including actual MongoDB process outage/recovery, one-document delivery, stale-version/lease protection, withdrawal authorization, rollback, voting/moderation, session invalidation and real vector search. Fixed PostgreSQL parameter type inference and the analytics date alias found during execution. All 35 reference queries and the original Mongo aggregation scripts execute. The documented owner DDL/DML command also completed without changing application history.

Files: tests/app/integration.ts, tests/app/full.ts, tests/app/browser.ts and docs/*results.json. Commands: npm run test:full; npm run test:full -- --browser-only. The full HTTP pass is recorded in integration-results.json; browser/permission passes were captured in a subsequent fresh-seed run.

### Milestone 4 — real UI and setup verification complete

Chromium 153.0.8010.0 successfully tested login, lookup, reporting, moderation acceptance, URL Detail verdict changes, semantic search, admin views and mobile overflow. Eleven genuine screenshots were visually reviewed. The regular Playwright download route was unavailable; a separately downloaded @sparticuz/chromium binary supplied the test browser. No browser binaries are shipped.

Corrected a missing category-insert seed permission and explicit text typing in setup's role-creation query. Executed application-role permission checks under SET LOCAL ROLE: no schema CREATE and no audit UPDATE/DELETE, with category INSERT allowed. Revised moderator loading text and prevented review buttons from acting before evidence loads. TypeScript, ESLint, nine Node tests, 30 Python tests and the production build all pass after the final source edits.

### Milestone 5 — release prepared

README.md supplies one exact install/setup/seed/app/worker workflow. IMPLEMENTATION_REPORT.md separates completed, executed, untested and enhanced features. docs/IMPLEMENTED_API.md and implemented-api.json describe the 31 running core routes plus health. Original design documents, schema, ER model and reference tests remain preserved. Source release excludes secrets, dependencies, models, build output and temporary services.

Remaining environment limitation: Docker and native PostgreSQL were not available here; the SQL execution engine was PostgreSQL WASM with pgvector, alongside native MongoDB. Native PostgreSQL/Docker/authentication and the legacy coverage migration still require the student's local run. Enhanced modules remain outside scope.

Exact next step for the student: extract the source ZIP, open README.md and execute its six setup commands, then start the app and worker in separate terminals. Demonstrate the Mongo outage/retry sequence and retain local evidence before submission.
