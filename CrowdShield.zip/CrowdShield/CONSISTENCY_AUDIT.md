> Historical design audit. For the working application and current execution results, read IMPLEMENTATION_REPORT.md. The original schema and report remain preserved.

# CrowdShield Revision and Consistency Audit

Revision completed 30 September 2026. This audit covers the design and starter artifacts. It does not certify a completed application or passing database integration.

## Changes completed

| Requested change | Result and location |
|---|---|
| Core versus enhanced scope | Section 3, all 36 functional requirements, scope_manifest.json and README now distinguish completion requirements from optional modules |
| Seven core page areas | Section 20 defines Home / Lookup, Dashboard, URL Detail, Report Scam, Moderation, Admin and Analytics; auth screens are supporting flows |
| Risk terminology | risk_scores.coverage replaces the former field in schema, ER attributes, views, procedure, SQL assertions, API example and UI terminology |
| Verification contradiction | Section 21 specifies hashed, expiring, single-use local tokens with restricted delivery; production email is enhanced and demo verification does not prove mailbox ownership |
| Conclusion and future work | Section 24 added; contents and traceability references updated |
| API burden | All 68 original method-route pairs retained: 31 core and 37 enhanced; all handlers remain planned |
| Advanced database priorities | Seven mandatory concepts; procedure helpers retained as an additional demonstration and reusable implementation path |
| Risk model status | Existing formula, crowdshield-v1, bounds, coverage policy, moderator precedence and worked 67.57 example preserved; no probability or accuracy claim |
| Outbox feasibility | One local worker, retryable errors pending, exhausted attempts parked, version/lease checks retained, one mandatory MongoDB outage/retry demo |
| Vector first version | Core accepted-report embeddings, 384 dimensions, pinned model/version, cosine retrieval and current SQL filters; URL-context embeddings and clustering remain enhanced |
| Security scope | Core controls separated from upload scanning, crawling, external scanning and production storage; no claim those enhanced controls exist |
| Test priorities | All T01–T45 retained: 25 core and 20 enhanced, with planned status and null actual-result/evidence fields |
| Traceability | Appendix A has College Requirement, Core Implementation and Enhanced columns covering the college requirements |
| Team responsibilities | Both members own database, backend/application, tests and documentation work, with cross-review |
| Roadmap | Six weeks in Section 23: schema, auth/URLs, reports/outbox, votes/risk, vector/UI, tests/evidence |
| Demo | Appendix B defines the required 15-step 8–10 minute storyline and real screenshot checklist |
| Viva | Original 20 questions retained and updated where needed; 16 concise questions added for scope, coverage, verification and failure recovery |
| Internal audit | Report/schema/ER attributes and types, scopes, API/test rows, Mongo samples, vector versions and risk example checked against companion files |
| Document quality | Existing professional neutral formatting retained; repeated scope claims replaced with explicit priorities and evidence status |
| Artifacts | Existing Markdown and Word filenames preserved; companion files and ZIP updated rather than starting a new project |

## Preserved architecture and content

The stack remains Next.js Route Handlers, PostgreSQL, MongoDB, pgvector and a background worker. The relational schema still has 22 tables and the MongoDB model still has five collections. Primary/foreign keys, entity identities, query categories and MongoDB sample documents are preserved. PostgreSQL and pgvector remain one engine, with three paradigms across two engines.

All 35 SQL query IDs remain: 15 general SELECT, five JOIN, five GROUP BY, five HAVING and five subqueries. S10 was updated to query pending events with a retryable error, matching the revised outbox status contract; the remaining queries are unchanged. The vote trigger and stored procedures retain their logic, with the coverage rename in scoring references. The embedding starter is unchanged. All 68 API identities and all 45 test IDs are retained.

The original risk weights, distinct-reporter cap, bounded reputation, reviewed similarity anchors, moderator override/expiry rules, independent coverage value, risk history, outbox idempotency and stale-worker safeguards remain. The revision adds explicit invalidation instructions rather than new core tables.

## What moved to enhanced scope

Discussions/comments, AI explanations, campaign tracking/clustering/suggestions, notifications and subscriptions, evidence uploads, CSV export, advanced analytics, production email, external feeds, browser extension, multilingual embeddings, automated crawling, production object storage and advanced reconciliation are optional. Direct URL-context embeddings and duplicate-report suggestions are also deferred. Their schemas, API contracts, security requirements and tests remain available.

Creating optional tables or loading invented fixtures is not evidence that those application modules work. Optional navigation and endpoints must stay disabled until implemented and tested.

## Contradictions fixed

- The release scope no longer requires optional AI, discussions, campaigns or notification flows.
- The frontend count now matches seven mandatory feature areas; lookup tabs share the Home area.
- SQL, ER, API and UI use coverage. The word confidence appears only in explanatory distinctions, audit history, test assertions rejecting the old field, and the explicitly labeled legacy migration.
- Mandatory local account verification has a specified delivery mechanism; real email delivery is clearly enhanced.
- Retryable outbox failures remain pending, including S10 and DML examples; failed means parked after exhausted attempts.
- MongoDB scam_reports and SQL report_refs both use workflow_status and content_version. sync_status is SQL-owned.
- API component values in the example respect the SQL numeric(6,5) precision. The score is computed before component storage rounding, as in the existing procedure.
- Optional procedure demonstration does not make required moderation/scoring behavior optional. The starter setup still installs and uses the supplied helpers.

## Executed audit evidence

Thirty offline Python checks pass: ten scoring arithmetic checks, ten original package checks, and ten cross-artifact consistency checks. All three mongosh files pass JavaScript syntax checking. JSON files decode successfully. These checks do not execute PostgreSQL, MongoDB, pgvector inference or HTTP handlers.

The revised Word report was rendered to 45 pages and every page was visually reviewed. Tables, diagrams, code examples, headings and page breaks are readable; no overlapping or clipped content was observed. The temporary rendering is used for quality assurance and is not an application screenshot or test result.

The schema/ER/document audit compares every table's attributes and types. API and test tables are compared with their JSON catalogs, including descriptions and expected results. Core/enhanced counts and the seven page areas match the scope manifest. A baseline comparison confirmed preservation of API identities, test IDs, MongoDB examples, the embedding starter and SQL schema/procedure logic apart from the coverage rename and scope comments.

The optional database/07_coverage_migration.sql upgrades the previous field and view outputs while preserving score history. It is only for the previous schema; fresh installations use the updated 01_schema.sql. The migration is supplied but has not been executed against a database.

## Work still required

Implement and run the Next.js pages, 31 core handlers, local verification adapter, security policies, report-delivery worker, remaining risk refresh producers, embedding integration and dashboard queries. Execute schema, seed, constraints, views, triggers, procedures, MongoDB validators/aggregations and vector queries against actual services. Validate source invalidation, concurrency, retry and restore behavior.

Execute the 25 core acceptance cases and record actual results. Capture real screenshots for authentication/RBAC, normalization, SQL metadata/outbox/MongoDB, vote uniqueness, moderator review, risk and coverage, semantic retrieval, dashboards, failure/retry and executed database features. Record hardware, dataset, dependency versions, query plans and measured latency. Keep genuine commits and contributions from both students and rehearse the demo/viva. The remaining 20 cases apply to deeper evaluation or optional modules.

No application implementation, acceptance-test pass, screenshot, antivirus scan, AI result, detection accuracy, deployment or performance result is claimed by this revision.
