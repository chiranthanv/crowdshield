# CrowdShield Project Design

> Current implementation note (2 November 2026): this document preserves the original design and acceptance plan. The core application now exists; use [the requirements audit](docs/REQUIREMENTS_AUDIT.md), [the implementation report](IMPLEMENTATION_REPORT.md), and the timestamped test evidence in [docs](docs/) for current completion status. Historical JWT, token lifetime, and planned-status descriptions below are design proposals; the running application uses revocable opaque sessions and 30-minute local verification tokens. Optional features are future scope.

Crowdsourced Phishing and Scam URL Intelligence Platform

DBMS Level 3 Mini Project | Two member team | Design and implementation reference

CrowdShield collects suspicious URLs and scam messages, combines independent community evidence, and presents explainable risk assessments with moderator review. The proposed implementation uses Next.js, a backend API, PostgreSQL, MongoDB, and pgvector. Its main database contribution is the integration of relational integrity, flexible evidence documents, and semantic retrieval through a recoverable workflow.

This revised report contains 24 design sections, implementation references, a demonstration plan, and viva preparation. The mandatory core is sized for two students; enhanced features retain their reference designs without blocking completion. The companion package includes complete SQL scripts, MongoDB validation and aggregation scripts, an embedding starter, diagrams, and test specifications. The design is a blueprint and database starter, not a completed or deployed application. Performance and detection-quality targets must be measured during implementation; no test result or screenshot is presented as completed project evidence.

<!-- CONTENTS_START -->
### Contents

- 1 Problem Statement
- 2 Objectives
- 3 Scope
- 4 Functional Requirements
- 5 User Roles
- 6 System Architecture
- 7 Database Selection Justification
- 8 SQL Database Design
- 9 Relational Schema
- 10 MongoDB Design
- 11 Vector Database Design
- 12 SQL Queries
- 13 DDL Statements
- 14 DML Statements
- 15 Advanced Database Features
- 16 Risk Scoring Algorithm
- 17 NoSQL Aggregation Pipelines
- 18 Vector Search Features
- 19 REST API Design
- 20 Next.js Frontend
- 21 Security Features
- 22 Test Cases
- 23 Team Responsibilities
- 24 Conclusion and Future Enhancements
- Appendix A College Requirement Traceability
- Appendix B Final Demonstration and Presentation
- Appendix C Viva Preparation
- Appendix D References
<!-- CONTENTS_END -->

## 1 Problem Statement

Phishing deceives people into disclosing credentials, payment information, or one-time codes, or into installing unwanted software. Scam messages often create urgency through a delivery problem, account suspension, fake job, investment opportunity, or payment request. A plausible message and an unfamiliar URL can be enough to make a user act before checking the source.

URL blacklists are useful, but a newly created URL may not be listed until someone observes it, reports it, verifies it, and distributes the update. Attackers can change domains, paths, and message wording. Consequently, the absence of a URL from a blacklist is not evidence that it is safe. Some intelligence feeds update rapidly; the limitation is incomplete coverage and the time needed to collect reliable evidence, not that every blacklist is inherently slow.

Crowdsourcing can shorten the gap between first exposure and shared awareness. Users contribute suspicious URLs, redacted message text, and judgments; evidence screenshots are an enhanced option. Repeated independent reports can expose a pattern that one submission does not reveal. However, malicious users can submit false reports or manipulate votes. CrowdShield therefore limits duplicate contributions, weights trust modestly, preserves evidence provenance, and gives moderators explicit review controls.

The project solves the following problem: how can a web application combine structured community decisions, unstructured scam evidence, and similarity search into a consistent, explainable, and auditable URL intelligence service? It supports safer decisions by individuals and faster triage by researchers. It does not guarantee that a website is safe, identify every scam, or replace a security incident response team.

## 2 Objectives

1. Collect suspicious HTTP and HTTPS URLs and redacted scam messages through validated forms.
2. Maintain normalized relational records with keys, uniqueness constraints, and reliable transactions.
3. Store varying scam report narratives in MongoDB under document validation and shared identities.
4. Retrieve semantically similar accepted reports using reproducible 384-dimensional embeddings.
5. Calculate an explainable, versioned risk score from votes, accepted reports, reputation, reviewed neighbors, and moderator decisions, with separate evidence coverage.
6. Prevent duplicate voting and reduce repeated-report and reputation manipulation.
7. Support independent moderator review and auditable corrections to report status and URL verdicts.
8. Show useful daily report trends and contribution summaries through a Next.js interface.
9. Demonstrate recoverable SQL-to-MongoDB delivery, database integrity, and at least four advanced database concepts.
10. Evaluate the implemented core honestly and retain discussions, campaigns, AI explanations, and notifications as extensions after the core is stable.

## 3 Scope

| Stakeholder | Core implementation | Enhanced work |
|---|---|---|
| Individual users | Verify a demo account, look up URLs, submit reports, vote, inspect risk and coverage | Discussions, evidence files, watched URLs and notifications |
| Cybersecurity researchers | Search accepted evidence, compare related messages and inspect basic trends | Campaign investigation, exports and advanced analytics |
| Moderators | Review synchronized reports, record reasons, set or clear URL verdicts | Discussion moderation and campaign confirmation |
| Administrators | Manage accounts and roles, inspect audits and delivery state | Advanced reconciliation, AI operations and external integrations |

A researcher uses the User role unless separately granted moderation privileges. Private report content is visible only to its owner or an authorized reviewer. All sensitive operations are audited.

### Core Implementation

The required release uses Next.js Route Handlers, PostgreSQL, MongoDB, pgvector, and one local background worker. The seven mandatory feature areas are Home / Lookup, Dashboard, URL Detail, Report Scam, Moderation, Admin, and Analytics, as specified in Section 20. Registration, login, and account verification are supporting authentication screens.

The core includes authentication; User, Moderator and Admin roles; local single-use account verification; URL normalization and deduplication; scam and phishing reports; relational report workflow; MongoDB narrative storage; a transactional outbox with idempotency, content versions, retry, leases and stale-worker protection; voting with duplicate prevention; moderator review; versioned risk and separate evidence coverage; PostgreSQL full-text search; pgvector semantic search over accepted report text; basic dashboards and MongoDB aggregation; database query demonstrations; security, test execution, documentation and individual Git/GitHub contributions.

Seven advanced concepts are mandatory: transactions, triggers, views, indexing, full-text search, MongoDB aggregation, and vector similarity search. Stored procedures remain supplied implementation helpers and an additional demonstration concept. The core is complete when its acceptance tests and the required database demonstrations pass with recorded evidence. Enhanced features are not required for completion.

### Enhanced Features

Retain the designs for discussions and comments, AI-generated explanations, campaign clustering and suggestions, notifications, evidence-file uploads, CSV export, advanced analytics, production email delivery, external threat feeds, a browser extension, multilingual embeddings, automated URL crawling, production object storage, and advanced background processing or reconciliation. URL-context embeddings and duplicate-report suggestions are extensions to the initial accepted-report search. Implement these only after the core is stable.

### Implementation and evidence status

| Status | Meaning in this package |
|---|---|
| Planned | Application pages, API handlers, worker integration, security controls and the 45 acceptance cases are specified but still require implementation and execution |
| Implemented as starter artifacts | SQL, MongoDB scripts, the embedding starter, diagrams and arithmetic/static checks exist; this does not establish a working integrated application |
| Measured | Only the executed checks listed in VALIDATION.md; no application latency, detection accuracy, deployment result or real UI screenshot is claimed |
| Enhanced | Optional reference architecture; no completion claim unless separately built and tested |

### Nonfunctional targets

These are proposed targets, not measured results. On a disclosed machine with 10,000 URLs, 50,000 votes and 10,000 reports, target p95 below 500 ms for exact lookup and below 2 seconds for semantic retrieval excluding model cold start. Target report acceptance below 1 second for SQL commit, with a separate visible content-processing status. Exercise 20 concurrent users, restore PostgreSQL and MongoDB backups, and record the observed results and query plans.

Cap pagination at 50 rows and report text at 12,000 characters. Store timestamps in UTC and label chart time zones. Use accessible labels, keyboard navigation and explicit processing states. Core backups cover both databases; a simple post-restore version comparison identifies mismatches. If enhanced uploads are added, cap each file at 5 MiB and five per report, extend backups to the private evidence directory, and test the upload controls before enabling them.

## 4 Functional Requirements

M1 means Member 1 and M2 means Member 2. Core requirements block the working demonstration. Enhanced requirements remain documented for later implementation; they do not block the core release. All 36 requirement IDs are preserved.

| ID | Requirement and acceptance condition | Priority | Owner |
| --- | --- | --- | --- |
| FR01 | Register with a unique normalized email and a securely hashed password | Core | M1 |
| FR02 | Verify a demo account using an expiring single-use token delivered through a restricted local flow before voting or reporting | Core | M1 |
| FR03 | Log in, rotate sessions, log out, and reject revoked or expired sessions | Core | M1 |
| FR04 | Reset passwords using a single-use token without revealing whether an email exists | Enhanced | M1 |
| FR05 | Edit the current user's display name and view contribution history | Enhanced | M2 |
| FR06 | Submit only validated HTTP or HTTPS URLs and return the existing ID for exact duplicates | Core | M1 |
| FR07 | Submit a phishing report with a redacted explanation; evidence files are enhanced | Core | M1 |
| FR08 | Submit a redacted scam message linked to a URL and a message channel | Core | M2 |
| FR09 | Quarantine uploaded evidence and expose only permitted clean files | Enhanced | M1 |
| FR10 | Show report workflow_status and sync_status separately, including content_version | Core | M2 |
| FR11 | Create or change one safe or malicious vote per user and URL | Core | M1 |
| FR12 | Withdraw the user's own vote and recalculate affected risk | Core | M1 |
| FR13 | Perform exact URL lookup and indexed hostname lookup | Core | M1 |
| FR14 | Search sanitized URL summaries using PostgreSQL full-text search | Core | M1 |
| FR15 | Find similar accepted scam text using vector search and hide inaccessible results | Core | M2 |
| FR16 | Suggest potential duplicate reports without deleting independent evidence | Enhanced | M2 |
| FR17 | Compute and retain versioned risk snapshots with score, coverage, label and moderator_verdict | Core | M1 |
| FR18 | Show evidence coverage and insufficient_evidence independently of the numerical score | Core | M2 |
| FR19 | Request an asynchronous AI explanation with evidence references and limitations | Enhanced | M2 |
| FR20 | Create a discussion linked to a URL | Enhanced | M2 |
| FR21 | Add, edit, and soft-delete owned comments with ownership checks | Enhanced | M2 |
| FR22 | Lock or hide discussions and comments with an audited moderator reason | Enhanced | M1 |
| FR23 | Review synchronized reports and accept or reject them with a reason | Core | M1 |
| FR24 | Set, expire, or clear a reviewed URL verdict while retaining history | Core | M1 |
| FR25 | Maintain an append-only reputation ledger with deduplicated awards | Core | M1 |
| FR26 | View own contributions, report processing state and current risk summaries | Core | M2 |
| FR27 | View daily reports, risk distribution, top reported URLs and active contributors; richer analytics are enhanced | Core | M2 |
| FR28 | Create campaigns and attach analyst-reviewed URL memberships | Enhanced | M1 |
| FR29 | Suggest campaign candidates from similarity without auto-confirming them | Enhanced | M2 |
| FR30 | Subscribe to URL risk thresholds and receive in-app crossing notifications | Enhanced | M1 |
| FR31 | Mark notifications read and change or delete owned alert subscriptions | Enhanced | M2 |
| FR32 | Suspend accounts, manage role grants, and revoke sessions | Core | M1 |
| FR33 | Inspect audit records and outbox delivery state using restricted admin views | Core | M1 |
| FR34 | Retry leased versioned outbox delivery without duplicate documents; advanced reconciliation is enhanced | Core | M1 |
| FR35 | Export only sanitized, authorized aggregate data as CSV | Enhanced | M2 |
| FR36 | Show a campaign timeline with related URLs, reviewed evidence, and updates | Enhanced | M2 |

## 5 User Roles

Authentication establishes identity; authorization checks both role and ownership. The API reads the current account status and relevant role grants instead of trusting a role field supplied by the browser. Users may have multiple roles through user_roles. Admin privileges explicitly include moderator operations in the policy layer; inheritance is not inferred from a role name.

| Capability | User | Moderator | Admin |
|---|---|---|---|
| Read sanitized public intelligence | Yes | Yes | Yes |
| Submit and vote in core | Verified active account | Verified active account | Verified active account |
| Discuss and subscribe in enhanced scope | Verified active account | Verified active account | Verified active account |
| Edit or withdraw own contribution | Yes with workflow restrictions | Yes with workflow restrictions | Yes with workflow restrictions |
| View raw private report evidence | Own reports only | Assigned review scope | Authorized investigation scope |
| Review reports and URL verdicts | No | Yes except own report | Yes except own report |
| Create or confirm campaign membership when enhanced scope is enabled | Suggest only | Yes | Yes |
| Moderate discussions when enhanced scope is enabled | No | Yes | Yes |
| Grant roles or suspend accounts | No | No | Yes |
| Inspect job state in core and manually retry parked jobs in enhanced scope | Own report sync state only | Relevant moderation audit | Yes |

Public visitors may use sanitized lookup with strict rate limits. In enhanced scope, an authenticated User may suggest a campaign link through a discussion; only a moderator creates the authoritative membership. Admins cannot bypass audit logging. Require an independent reviewer for self-submitted evidence, and block self-promotion and removal of the final active admin. Those last two invariants need a locked role-management transaction because an ordinary row CHECK cannot express them.

## 6 System Architecture

The architecture is a modular monolith with a small worker, suitable for two students. Next.js renders pages; its Node.js Route Handlers form the backend API. A Python worker delivers report documents, generates local embeddings and refreshes scores; AI jobs are an enhanced worker module. Only the API and worker connect to databases. PostgreSQL and pgvector share one server and connection pool; MongoDB is a separate engine. This implements three database paradigms without introducing an unnecessary third database service.


```mermaid
flowchart TD
  P["Browser and Next.js pages"] --> A["Backend API and authorization"]
  A --> S["PostgreSQL relational data"]
  A --> M["MongoDB report content"]
  A --> V["pgvector embeddings inside PostgreSQL"]
  S --> O["Transactional outbox"]
  O --> W["Worker with retry and leases"]
  W --> M
  W --> V
  W --> L["Embedding model"]
  A --> E["Enhanced private evidence storage"]
  W --> S
```


Core backend modules are authentication, URL intake, reports, votes, scoring, moderation, search, basic analytics, and administration. Run one local worker with a simple polling loop for outbox delivery, embedding generation, and score refresh. Campaigns, discussions, notifications, AI generation, and advanced reconciliation are enhanced modules. If uploads are enabled later, store binaries privately; MongoDB holds metadata and access references. The architecture preserves that extension point without requiring file storage in the core demo.

### Core outbox implementation

The sequence is report submission, one PostgreSQL transaction writing report_refs and outbox_events, HTTP 202, worker delivery to MongoDB, SQL synchronization acknowledgement, then vector and risk refresh. Keep these steps in one small worker module before adding distributed processing.

### Submission and recovery workflow

1. Authenticate, check account status, validate the input, redact personal data, and normalize the URL without fetching it.
2. In one PostgreSQL transaction, insert or resolve the URL, insert report_refs, and insert an outbox event containing a bounded redacted payload. A unique reporter and idempotency-key pair makes retries safe. Roll back everything on error.
3. Return HTTP 202 with report_id and processing state after SQL commit. The UI must not say that the report is public or reviewed yet.
4. A worker claims an event with FOR UPDATE SKIP LOCKED and a five-minute lease, commits the claim, then conditionally writes the MongoDB document. It does not hold a SQL lock during a network call.
5. On successful delivery, update SQL sync_status only if content_version still equals the delivered version. Acknowledge the event only with its matching lease token. Remove the delivered narrative payload from the outbox after a short operational retention interval.
6. When a report is accepted and synchronized, create current embeddings and queue a risk refresh. Pending, rejected, withdrawn, unsynchronized, or hidden evidence is excluded from public semantic results.

There is no shared ACID transaction spanning PostgreSQL and MongoDB. The outbox gives recoverable, at-least-once delivery and eventual consistency. MongoDB is the persistent home of report text; SQL contains its ID, current workflow, and version, plus temporary delivery payloads. A worker crash after a MongoDB write and before acknowledgement is safe because replay uses the same ID and version. MongoDB document operations are atomic per document; cross-document or cross-engine atomicity must not be assumed [3].

For report version 1, use an insert with the shared UUID and treat a duplicate ID as a replay only after comparing version and payload hash. For version n, update only a document at version n-1. A document already at n is a replay; a document at a higher version must not be overwritten; a missing predecessor is retried. After eight failures, park the event for admin inspection. Use exponential retry delays with jitter and never log message text or credentials. Advanced automatic reconciliation is enhanced. Core recovery uses the visible event status, scheduled retry and a manual SQL/MongoDB version check; the admin can inspect a parked event. A retryable delivery error returns the event to pending with a future available_at and cleared lease; attempts remain recorded. If the worker dies instead, another claim can recover it after lease expiry. After the eighth unsuccessful attempt, mark the event failed and stop automatic attempts until an operator investigates.

The required classroom failure scenario is MongoDB temporarily unavailable: commit the report in SQL and return 202, observe the event pending after the failed attempt, restart MongoDB, let the worker retry, and query the shared report ID to prove exactly one MongoDB document exists. Idempotency, content versions, leases, and conditional acknowledgement remain required even with one worker. Advanced crash combinations and reconciliation dashboards are additional demonstrations.

For enhanced modules, direct discussion writes remain MongoDB-owned and are acknowledged only after that write succeeds. The API checks SQL account and URL access first; SQL URL rows are archived rather than hard-deleted, avoiding disappearing references. MongoDB cannot enforce those SQL foreign keys. Campaign identity and membership are SQL-owned; MongoDB campaign descriptions and cached campaign_ids follow the same versioned projection rule. A removed campaign link triggers projection and vector invalidation jobs.

## 7 Database Selection Justification

| Store | Authoritative content | Why it fits | Consistency rule |
|---|---|---|---|
| PostgreSQL | Users, roles, URLs, votes, report metadata, reputation, risk history, campaigns, alerts, audit, sessions | Relationships, uniqueness, transactions, joins, constraints, and reproducible analytics | SQL transactions and foreign keys protect structured state |
| MongoDB | Scam report narratives, discussion and comment bodies, evidence metadata, campaign narratives | Optional message and evidence fields vary by report; documents can evolve under validation | Shared UUIDs and application validation link to SQL; versions expose projection lag |
| pgvector | URL-context and report-text embeddings with source IDs and versions | Similarity retrieval is based on meaning rather than exact string equality | Derived data can be rebuilt; SQL checks filter current, accessible sources |

PostgreSQL stores users, roles, URLs, votes, risk scores, and audit logs exactly as requested. It also stores report_refs, which is a relational report envelope, not a second copy of the MongoDB narrative. MongoDB stores discussions and comments separately because a popular thread can grow without bound; embedding every comment inside one thread document would create growth and contention problems. Schema validation makes MongoDB flexible without making it unvalidated [4].

pgvector stores vectors and exposes exact and approximate similarity search inside PostgreSQL [5]. Qdrant is a valid alternative if an independent vector service is a project requirement, but would introduce another identity and synchronization boundary. For this team, pgvector reduces operational work while still demonstrating vector storage, metadata filtering, distance operators, and HNSW indexing. Confirm with the instructor that database paradigms, rather than three separate server products, are being assessed; the supplied brief explicitly lists PostgreSQL with pgvector as an accepted vector option.

## 8 SQL Database Design

The reference schema retains all 22 tables. Seventeen support the core: roles, users, user_roles, url_categories, urls, url_category_map, votes, report_refs, reputation_events, moderator_actions, risk_scores, audit_logs, refresh_sessions, auth_tokens, outbox_events, embeddings, and similarity_edges. Five serve enhanced modules: campaigns, campaign_urls, alerts, notifications, and ai_analyses. They may be created by the shared setup script while remaining unused; their presence does not require building optional application flows. Core business tables are normalized to third normal form: a user's email belongs to users; role names belong to roles; category names belong to url_categories; many-to-many memberships use bridge tables. Vote identity is the composite pair of user and URL. Reputation is a ledger and a computed view instead of an editable counter.

Generated URL hashes and full-text vectors, immutable risk snapshots, and similarity edges are deliberate derived data. JSONB in risk inputs and AI output stores bounded calculation metadata or varying model output; it is not used to hide core foreign-key relationships. Nullable columns indicate a genuinely optional relationship or state, not an unknown required field.

### Entity dictionary and key definitions

All attributes and data types appear in Section 9. risk_scores.coverage is the evidence-coverage field throughout SQL, API responses and UI; its valid range is 0 to 1. The following dictionary identifies the key and purpose of every entity; together they form the full data dictionary. NN, defaults, CHECK, UNIQUE, and delete actions are defined precisely in database/01_schema.sql.

| Entity | Primary key | Foreign keys | Purpose and alternate keys |
| --- | --- | --- | --- |
| roles | role_id | None | Fixed RBAC vocabulary; name is unique. |
| users | user_id | None | Identity and account eligibility; normalized email is unique. |
| user_roles | user_id + role_id | user_id to users; role_id to roles; granted_by to users | Role grants with grant provenance. |
| url_categories | category_id | None | Classification vocabulary; name is unique. |
| urls | url_id | submitted_by to users | Canonical URL identity, safe display, and search projection. |
| url_category_map | url_id + category_id | url_id to urls; category_id to url_categories; assigned_by to users | Many-to-many categorization. |
| votes | user_id + url_id | user_id to users; url_id to urls | One current vote per account and URL. |
| report_refs | report_id | url_id to urls; reporter_id to users | SQL envelope, state, sync version, and idempotency hash for a Mongo report. |
| reputation_events | event_id | user_id and awarded_by to users | Immutable trust ledger; dedupe_key unique. |
| campaigns | campaign_id | created_by to users | Campaign identity and review state. |
| campaign_urls | campaign_id + url_id | campaign_id to campaigns; url_id to urls; linked_by to users | Authoritative analyst-reviewed campaign membership. |
| moderator_actions | action_id | moderator_id to users; url_id to urls; report_id to report_refs | Append-only decision with target-exclusive CHECK. |
| risk_scores | risk_score_id | url_id to urls | Immutable score, component, coverage, and algorithm snapshots. |
| alerts | alert_id | user_id to users; url_id to urls; last_evaluated_score_id to risk_scores | Watch subscription; unique user and URL pair. Pointer tracks last evaluated score. |
| notifications | notification_id | user_id to users; alert_id to alerts; risk_score_id to risk_scores | Delivery record with per-alert score deduplication. |
| audit_logs | audit_id | actor_id to users | Immutable action trail; polymorphic entity_id is not an FK. |
| refresh_sessions | session_id | user_id to users | Hashed refresh secrets and rotation-family revocation. |
| auth_tokens | token_id | user_id to users | Hashed single-use email and reset tokens. |
| outbox_events | event_id | None | Durable delivery queue; aggregate_id is polymorphic. Event type, ID, and version unique. |
| ai_analyses | analysis_id | url_id to urls; requested_by to users | Async AI job and bounded structured output. |
| embeddings | embedding_id | url_id to urls; report_id + url_id to report_refs | 384-dimensional derived chunks; source/version uniqueness via partial indexes. |
| similarity_edges | url_id + neighbor_url_id + model_version | url_id and neighbor_url_id to urls | Directed derived neighbors; self-links forbidden. |


### Complete text ER relationship list

The parent has zero or many children unless otherwise stated. Each required child FK refers to exactly one parent. Nullable actor and target FKs are optional on the child side. Composite primary keys in bridge tables are made from their parent IDs.

- users to user_roles: one parent to zero or many children through user_id; child parent is required.
- roles to user_roles: one parent to zero or many children through role_id; child parent is required.
- users to user_roles: one parent to zero or many children through granted_by; child parent is optional.
- users to urls: one parent to zero or many children through submitted_by; child parent is required.
- urls to url_category_map: one parent to zero or many children through url_id; child parent is required.
- url_categories to url_category_map: one parent to zero or many children through category_id; child parent is required.
- users to url_category_map: one parent to zero or many children through assigned_by; child parent is required.
- users to votes: one parent to zero or many children through user_id; child parent is required.
- urls to votes: one parent to zero or many children through url_id; child parent is required.
- urls to report_refs: one parent to zero or many children through url_id; child parent is required.
- users to report_refs: one parent to zero or many children through reporter_id; child parent is required.
- users to reputation_events: one parent to zero or many children through user_id; child parent is required.
- users to reputation_events: one parent to zero or many children through awarded_by; child parent is optional.
- users to campaigns: one parent to zero or many children through created_by; child parent is required.
- campaigns to campaign_urls: one parent to zero or many children through campaign_id; child parent is required.
- urls to campaign_urls: one parent to zero or many children through url_id; child parent is required.
- users to campaign_urls: one parent to zero or many children through linked_by; child parent is required.
- users to moderator_actions: one parent to zero or many children through moderator_id; child parent is required.
- urls to moderator_actions: one parent to zero or many children through url_id; child parent is optional.
- report_refs to moderator_actions: one parent to zero or many children through report_id; child parent is optional.
- urls to risk_scores: one parent to zero or many children through url_id; child parent is required.
- users to alerts: one parent to zero or many children through user_id; child parent is required.
- urls to alerts: one parent to zero or many children through url_id; child parent is required.
- risk_scores to alerts: one parent to zero or many children through last_evaluated_score_id; child parent is optional.
- users to notifications: one parent to zero or many children through user_id; child parent is required.
- alerts to notifications: one parent to zero or many children through alert_id; child parent is optional.
- risk_scores to notifications: one parent to zero or many children through risk_score_id; child parent is optional.
- users to audit_logs: one parent to zero or many children through actor_id; child parent is optional.
- users to refresh_sessions: one parent to zero or many children through user_id; child parent is required.
- users to auth_tokens: one parent to zero or many children through user_id; child parent is required.
- urls to ai_analyses: one parent to zero or many children through url_id; child parent is required.
- users to ai_analyses: one parent to zero or many children through requested_by; child parent is required.
- urls to embeddings: one parent to zero or many children through url_id; child parent is required.
- report_refs to embeddings: one parent to zero or many children through report_id, url_id; child parent is optional.
- urls to similarity_edges: one parent to zero or many children through url_id; child parent is required.
- urls to similarity_edges: one parent to zero or many children through neighbor_url_id; child parent is required.

moderator_actions has exactly one logical target: a URL for set_verdict, or a report for accept_report and reject_report. A CHECK enforces this. embeddings always belongs to a URL; report embeddings also carry a composite FK to report_refs(report_id, url_id), ensuring the report actually belongs to that URL. audit_logs.entity_id and outbox_events.aggregate_id are intentionally polymorphic identifiers, not claimed foreign keys. Their producers validate the relevant entity and preserve tombstones or audit context when entities are archived.

The package contains diagrams/er.mmd for rendering the full ER diagram, plus an entity relationship list useful when drawing it in a diagramming tool. Keep conceptual report and campaign entities visible even though their narratives live in MongoDB.

## 9 Relational Schema

Notation: PK means primary key, FK means foreign key, and UQ means unique. Composite key definitions and referenced tables are in the entity dictionary; generated columns are marked generated. PostgreSQL types are used throughout, so these statements must not be copied unchanged into MySQL. All timestamps are timestamptz except dates computed for analytics.


```text
ROLES(
  role_id smallint PK NN generated,
  name varchar(20) UQ NN,
  description text NN
)
```


```text
USERS(
  user_id uuid PK NN,
  email varchar(254) NN,
  display_name varchar(80) NN,
  password_hash text NN,
  status varchar(16) NN,
  email_verified_at timestamptz,
  created_at timestamptz NN
)
```


```text
USER_ROLES(
  user_id uuid PK FK NN,
  role_id smallint PK FK NN,
  granted_by uuid FK,
  granted_at timestamptz NN
)
```


```text
URL_CATEGORIES(
  category_id smallint PK NN generated,
  name varchar(60) UQ NN,
  description text NN
)
```


```text
URLS(
  url_id uuid PK NN,
  canonical_url text NN,
  canonical_hash bytea UQ generated,
  hostname varchar(253) NN,
  display_url text NN,
  public_summary text NN,
  evidence_version integer NN,
  submitted_by uuid FK NN,
  is_archived boolean NN,
  first_seen_at timestamptz NN,
  last_seen_at timestamptz NN,
  search_vector tsvector generated
)
```


```text
URL_CATEGORY_MAP(
  url_id uuid PK FK NN,
  category_id smallint PK FK NN,
  assigned_by uuid FK NN,
  assigned_at timestamptz NN
)
```


```text
VOTES(
  user_id uuid PK FK NN,
  url_id uuid PK FK NN,
  verdict smallint NN,
  created_at timestamptz NN,
  updated_at timestamptz NN
)
```


```text
REPORT_REFS(
  report_id uuid PK NN,
  url_id uuid FK NN,
  reporter_id uuid FK NN,
  report_type varchar(24) NN,
  workflow_status varchar(16) NN,
  sync_status varchar(16) NN,
  content_version integer NN,
  idempotency_key uuid NN,
  request_hash bytea NN,
  created_at timestamptz NN,
  updated_at timestamptz NN
)
```


```text
REPUTATION_EVENTS(
  event_id bigint PK NN generated,
  user_id uuid FK NN,
  delta smallint NN,
  reason varchar(100) NN,
  dedupe_key varchar(120) UQ NN,
  awarded_by uuid FK,
  created_at timestamptz NN
)
```


```text
CAMPAIGNS(
  campaign_id uuid PK NN,
  content_version integer NN,
  name varchar(150) NN,
  status varchar(16) NN,
  created_by uuid FK NN,
  created_at timestamptz NN
)
```


```text
CAMPAIGN_URLS(
  campaign_id uuid PK FK NN,
  url_id uuid PK FK NN,
  linked_by uuid FK NN,
  link_reason text NN,
  linked_at timestamptz NN
)
```


```text
MODERATOR_ACTIONS(
  action_id bigint PK NN generated,
  moderator_id uuid FK NN,
  url_id uuid FK,
  report_id uuid FK,
  action_kind varchar(24) NN,
  verdict varchar(12),
  reason text NN,
  valid_until timestamptz,
  created_at timestamptz NN
)
```


```text
RISK_SCORES(
  risk_score_id bigint PK NN generated,
  url_id uuid FK NN,
  score numeric(5,2) NN,
  coverage numeric(5,4) NN,
  label varchar(24) NN,
  community_component numeric(6,5) NN,
  report_component numeric(6,5) NN,
  similarity_component numeric(6,5) NN,
  moderator_verdict varchar(12),
  algorithm_version varchar(30) NN,
  inputs jsonb NN,
  computed_at timestamptz NN
)
```


```text
ALERTS(
  alert_id uuid PK NN,
  user_id uuid FK NN,
  url_id uuid FK NN,
  threshold smallint NN,
  enabled boolean NN,
  last_evaluated_score_id bigint FK,
  created_at timestamptz NN
)
```


```text
NOTIFICATIONS(
  notification_id uuid PK NN,
  user_id uuid FK NN,
  alert_id uuid FK,
  risk_score_id bigint FK,
  kind varchar(30) NN,
  message varchar(500) NN,
  read_at timestamptz,
  created_at timestamptz NN
)
```


```text
AUDIT_LOGS(
  audit_id bigint PK NN generated,
  actor_id uuid FK,
  action varchar(60) NN,
  entity_type varchar(40) NN,
  entity_id text NN,
  details jsonb NN,
  created_at timestamptz NN
)
```


```text
REFRESH_SESSIONS(
  session_id uuid PK NN,
  family_id uuid NN,
  user_id uuid FK NN,
  token_hash bytea UQ NN,
  expires_at timestamptz NN,
  revoked_at timestamptz,
  created_at timestamptz NN
)
```


```text
AUTH_TOKENS(
  token_id uuid PK NN,
  user_id uuid FK NN,
  purpose varchar(20) NN,
  token_hash bytea UQ NN,
  expires_at timestamptz NN,
  consumed_at timestamptz,
  created_at timestamptz NN
)
```


```text
OUTBOX_EVENTS(
  event_id uuid PK NN,
  event_type varchar(50) NN,
  aggregate_id uuid NN,
  aggregate_version integer NN,
  payload jsonb NN,
  status varchar(16) NN,
  attempts integer NN,
  available_at timestamptz NN,
  locked_at timestamptz,
  lease_token uuid,
  processed_at timestamptz,
  last_error varchar(300),
  created_at timestamptz NN
)
```


```text
AI_ANALYSES(
  analysis_id uuid PK NN,
  url_id uuid FK NN,
  requested_by uuid FK NN,
  model_name varchar(120) NN,
  prompt_version varchar(40) NN,
  input_hash bytea NN,
  status varchar(16) NN,
  output jsonb,
  created_at timestamptz NN,
  completed_at timestamptz
)
```


```text
EMBEDDINGS(
  embedding_id uuid PK NN,
  url_id uuid FK NN,
  report_id uuid FK,
  source_kind varchar(12) NN,
  model_version varchar(140) NN,
  content_version integer NN,
  chunk_no integer NN,
  content_hash bytea NN,
  embedding vector(384) NN,
  metadata jsonb NN,
  created_at timestamptz NN
)
```


```text
SIMILARITY_EDGES(
  url_id uuid PK FK NN,
  neighbor_url_id uuid PK FK NN,
  model_version varchar(140) PK NN,
  similarity numeric(6,5) NN,
  computed_at timestamptz NN
)
```


Important constraints include one role grant per user and role, one vote per user and URL, one alert per user and URL, one report submission per reporter and idempotency key, valid score ranges, nonzero 384-dimensional vectors, and a unique normalized URL digest. The API must compare the full canonical URL after a digest match and treat a digest collision as a conflict rather than silently combining records.

PostgreSQL CHECK constraints validate a single row; cross-row rules need keys, transactions, or carefully designed triggers [1]. Foreign keys do not automatically create indexes on the referencing columns, so query-driven FK indexes are explicitly included. Do not cascade-delete reports, votes, or audit records when an account is closed; anonymize the user record and retain the surrogate ID under the documented retention policy.

## 10 MongoDB Design

scam_reports is the mandatory document collection. discussions, comments, evidence_files and phishing_campaigns remain enhanced reference collections. Keep all five validators and sample documents; loading their invented fixtures does not demonstrate implemented discussion, upload or campaign features.

Use UUID strings in MongoDB to match SQL UUIDs. This avoids an unnecessary second ObjectId identifier for SQL-linked reports and campaigns. Discussion, comment, and evidence IDs are also application-generated UUIDs. Dates below use Extended JSON; import them with an Extended JSON-aware importer or use the supplied mongosh seed script, which constructs Date values.

### scam_reports

```json
{
  "_id": "00000000-0000-4000-8000-000000000201",
  "url_id": "00000000-0000-4000-8000-000000000101",
  "reporter_id": "00000000-0000-4000-8000-000000000001",
  "report_type": "scam_message",
  "workflow_status": "accepted",
  "content_version": 1,
  "message_text": "Your parcel is on hold. Pay a small redelivery fee at the linked page.",
  "narrative": "The message claims to be a delivery service and requests payment. Personal contact details were removed.",
  "channel": "sms",
  "language": "en",
  "claimed_brand": "Example Parcel Service",
  "campaign_ids": [
    "00000000-0000-4000-8000-000000000301"
  ],
  "redactions": [
    "phone_number"
  ],
  "created_at": {
    "$date": "2026-09-29T05:30:00Z"
  },
  "updated_at": {
    "$date": "2026-09-29T05:30:00Z"
  }
}
```

### discussions

```json
{
  "_id": "00000000-0000-4000-8000-000000000401",
  "url_id": "00000000-0000-4000-8000-000000000101",
  "author_id": "00000000-0000-4000-8000-000000000002",
  "title": "Similar parcel fee messages",
  "body": "Has anyone received the same wording? Please remove personal details.",
  "status": "open",
  "content_version": 1,
  "created_at": {
    "$date": "2026-09-29T05:30:00Z"
  },
  "updated_at": {
    "$date": "2026-09-29T05:30:00Z"
  }
}
```

### comments

```json
{
  "_id": "00000000-0000-4000-8000-000000000501",
  "discussion_id": "00000000-0000-4000-8000-000000000401",
  "author_id": "00000000-0000-4000-8000-000000000003",
  "parent_comment_id": null,
  "body": "I saw a similar message; the attached URL used a different path.",
  "status": "visible",
  "content_version": 1,
  "created_at": {
    "$date": "2026-09-29T05:30:00Z"
  }
}
```

### evidence_files

```json
{
  "_id": "00000000-0000-4000-8000-000000000601",
  "report_id": "00000000-0000-4000-8000-000000000201",
  "owner_id": "00000000-0000-4000-8000-000000000001",
  "object_key": "evidence/00000000-0000-4000-8000-000000000601.png",
  "mime_type": "image/png",
  "size_bytes": 248120,
  "sha256": "0000000000000000000000000000000000000000000000000000000000000000",
  "scan_status": "quarantined",
  "caption": "Invented evidence metadata only; no image file is supplied.",
  "created_at": {
    "$date": "2026-09-29T05:30:00Z"
  }
}
```

### phishing_campaigns

```json
{
  "_id": "00000000-0000-4000-8000-000000000301",
  "description": "Invented parcel redelivery messages with a repeated payment request.",
  "content_version": 1,
  "updated_by": "00000000-0000-4000-8000-000000000004",
  "indicators": [
    {
      "type": "message_theme",
      "value": "parcel redelivery fee"
    },
    {
      "type": "hostname",
      "value": "parcel-check.example"
    }
  ],
  "analyst_notes": [
    "Campaign links must be reviewed against evidence."
  ],
  "updated_at": {
    "$date": "2026-09-29T05:30:00Z"
  }
}
```


The evidence object_key refers to private storage. Do not put file bytes into JSON, expose filesystem paths to browsers, or serve quarantined uploads. A hash identifies an uploaded file for integrity checks; it does not prove that the evidence is true. Evidence_files metadata supports different file types while keeping access policy tied to the report owner and reviewer.

The full mongodb/01_collections.js script creates all five collections with required fields, enum states, maximum text lengths, date types, UUID formats, and indexes. MongoDB does not enforce references to users, report_refs, or other collections: the API checks them, core restore checks identify mismatches, and enhanced reconciliation can detect orphans automatically. A comment's parent, if present, must be in the same discussion, and maximum nesting depth is three. Enforce parent consistency through the API and use a MongoDB transaction on a replica set if an operation changes multiple discussion documents atomically.

| Collection | Main access pattern | Indexes beyond the built-in unique _id |
|---|---|---|
| scam_reports | URL review, user history, accepted trend windows | (url_id, workflow_status, created_at), (reporter_id, created_at), (workflow_status, created_at), (campaign_ids, created_at) |
| discussions | Threads belonging to one URL | (url_id, status, created_at) |
| comments | Paginated visible comments in one discussion | (discussion_id, status, created_at, _id) |
| evidence_files | Evidence belonging to one report | (report_id, created_at), unique object_key |
| phishing_campaigns | Narrative lookup by SQL campaign ID | Built-in _id index |

Use SQL as the current authority for report visibility. Before exposing a MongoDB report, check its workflow status and content_version against report_refs. A stale accepted MongoDB copy must not leak a newly withdrawn report. Aggregate trend counts may be eventually consistent, so display a refresh timestamp and do not treat them as the authorization source.

## 11 Vector Database Design

Use sentence-transformers/all-MiniLM-L6-v2 as the initial English-language embedding model. Its published output dimension is 384 and its default input truncation limit is 256 word pieces [6]. Pin the actual model revision in EMBEDDING_MODEL_REVISION and record it in the repository and embedding metadata. The project label minilm-l6-v2:project-v1 identifies this immutable combination of model, preprocessing, and chunking. A changed model or preprocessing rule requires a new version and a separate reindexing run.

### Inputs and metadata

URL embeddings represent a short structured context such as: hostname tokens, meaningful path tokens, assigned category, and a sanitized public summary. A sentence model is not a reliable raw-URL classifier; domain spelling and URL syntax still need exact lookup and explicit validation. Report embeddings represent redacted scam message text plus the reporter's explanation and claimed brand. Do not embed passwords, OTPs, email addresses, phone numbers, private evidence storage keys, or raw query tokens.

Chunk longer reports into approximately 180 tokenizer tokens with 30 tokens of overlap; reserve room for the context prefix and special tokens, then verify every final chunk fits the model limit. Store one vector per chunk with source_kind, url_id, report_id when applicable, content_version, chunk_no, model_version, content_hash, and metadata containing model_revision, language, preprocessing_version, and created time. Do not mix vector dimensions or versions in a result set.

For vectors a and b, cosine similarity equals dot(a,b) divided by norm(a) times norm(b). Cosine distance is one minus similarity. pgvector uses the <=> operator for cosine distance and vector_cosine_ops for a matching index. Normalize embeddings, reject zero vectors, and order by distance ascending. Similarity is not a probability of phishing [5].

### Core vector workflow

Start with accepted, synchronized report text only. Redact the message and narrative, generate 384-dimensional vectors with the pinned model, store them in pgvector with source and model versions, retrieve top-k candidates, recheck SQL authorization and current report state, and return similar evidence. The core API accepts source_kind=report; source_kind=url is an enhanced option. The generic search SQL supports both for the reference architecture.

After grouping chunks by report, group candidate reports by their distinct URL to build similarity_edges for the existing risk model. Use the highest qualifying report-pair similarity per distinct neighboring URL, exclude self-links, and keep at most five reviewed anchors at scoring time. A related report does not determine whether a URL is malicious; only effective moderator verdicts label similarity anchors. No usable anchors means S=0.5.

### Retrieval workflow

1. Validate and redact the search text; normalize it with the same pipeline as indexed documents.
2. Generate a query vector with the pinned model. Choose the source kind and model version explicitly.
3. Search matching vectors, excluding the current URL for neighbor detection and excluding stale or inaccessible source versions.
4. Overfetch candidates, combine chunks by report using maximum chunk similarity, and return one result per report or URL.
5. Recheck SQL authorization and workflow status immediately before returning the result. Show the similarity score, snippet, source, and version.
6. Compare approximate HNSW retrieval against exact search. Metadata filters and joins can reduce ANN recall; use iterative scans where supported, overfetch, or exact search for small filtered sets.

A starting candidate threshold of 0.75 for reviewed risk neighbors and 0.90 for duplicate suggestions is a tunable project heuristic, not a validated accuracy claim. Tune thresholds on labeled holdout examples. The embedding starter raises an error rather than silently truncating long text. The vector/search.sql file contains the complete parameterized query.

## 12 SQL Queries

The following are 35 distinct examples: 15 general SELECT queries, five explicit JOIN examples, five GROUP BY examples, five HAVING examples, and five subquery examples. The groups are separated for assessment even though JOIN and aggregation queries are also SELECT statements. Comments explain each query. They use the exact schema and invented seed IDs provided in the package.


```sql
-- 35 distinct examples: 15 general SELECT, 5 JOIN, 5 GROUP BY,
-- 5 HAVING and 5 subquery examples. UUIDs refer to 03_seed.sql.

-- S01: newest visible URL submissions, deterministic pagination order.
SELECT url_id,display_url,first_seen_at FROM urls WHERE NOT is_archived
ORDER BY first_seen_at DESC,url_id LIMIT 20;
-- S02: exact normalized URL lookup using a digest index; verify full equality.
SELECT url_id,display_url FROM urls
WHERE canonical_hash=digest('https://parcel-check.example/verify','sha256')
  AND canonical_url='https://parcel-check.example/verify';
-- S03: hostname lookup, returning all observed paths on one host.
SELECT url_id,display_url FROM urls WHERE hostname='parcel-check.example';
-- S04: high-risk results with enough evidence, via the latest-score view.
SELECT * FROM v_current_risk WHERE label='high' ORDER BY score DESC,url_id;
-- S05: URLs first observed in the last week.
SELECT url_id,first_seen_at FROM urls
WHERE first_seen_at>=now()-interval '7 days' ORDER BY first_seen_at DESC;
-- S06: one user's unread notifications.
SELECT notification_id,message FROM notifications
WHERE user_id='00000000-0000-4000-8000-000000000001' AND read_at IS NULL
ORDER BY created_at DESC,notification_id;
-- S07: synchronized reports waiting for review.
SELECT report_id,url_id,created_at FROM report_refs
WHERE workflow_status='pending' AND sync_status='synced'
ORDER BY created_at,report_id;
-- S08: a user's current votes.
SELECT url_id,verdict,updated_at FROM votes
WHERE user_id='00000000-0000-4000-8000-000000000001' ORDER BY updated_at DESC;
-- S09: immutable score timeline for one URL.
SELECT score,label,algorithm_version,computed_at FROM risk_scores
WHERE url_id='00000000-0000-4000-8000-000000000101'
ORDER BY computed_at,risk_score_id;
-- S10: pending outbox deliveries with a recorded retryable error.
SELECT event_id,event_type,attempts,last_error FROM outbox_events
WHERE status='pending' AND last_error IS NOT NULL AND attempts<8
ORDER BY available_at,event_id;
-- S11: full-text search over sanitized public summary and hostname.
SELECT url_id,display_url,
 ts_rank(search_vector,websearch_to_tsquery('simple','parcel payment')) AS rank
FROM urls WHERE search_vector @@ websearch_to_tsquery('simple','parcel payment')
ORDER BY rank DESC,url_id LIMIT 20;
-- S12: enabled alerts above a selected threshold.
SELECT alert_id,url_id,threshold FROM alerts WHERE enabled AND threshold>=70;
-- S13: active verified users, without exposing hashes or email addresses.
SELECT user_id,display_name FROM users
WHERE status='active' AND email_verified_at IS NOT NULL ORDER BY display_name,user_id;
-- S14: one user's reputation event ledger.
SELECT delta,reason,created_at FROM reputation_events
WHERE user_id='00000000-0000-4000-8000-000000000001' ORDER BY created_at,event_id;
-- S15: completed AI analyses, newest first; owner/moderator access only.
SELECT analysis_id,url_id,model_name,completed_at FROM ai_analyses
WHERE status='done' ORDER BY completed_at DESC,analysis_id LIMIT 20;

-- J01: users and their assigned roles (many-to-many bridge).
SELECT u.display_name,r.name AS role FROM users u
JOIN user_roles ur USING(user_id) JOIN roles r USING(role_id)
ORDER BY u.display_name,r.name;
-- J02: visible URLs with optional current risk; unscored URLs remain visible.
SELECT u.display_url,r.score,r.label FROM urls u
LEFT JOIN v_current_risk r USING(url_id) WHERE NOT u.is_archived;
-- J03: report queue showing reporter display name and URL.
SELECT rr.report_id,u.display_name,l.display_url,rr.workflow_status
FROM report_refs rr JOIN users u ON u.user_id=rr.reporter_id
JOIN urls l ON l.url_id=rr.url_id;
-- J04: campaign membership with time of analyst linking.
SELECT c.name,u.display_url,cu.linked_at FROM campaigns c
JOIN campaign_urls cu USING(campaign_id) JOIN urls u USING(url_id);
-- J05: classifications and who assigned them.
SELECT u.display_url,c.name,a.display_name AS assigned_by FROM url_category_map m
JOIN urls u USING(url_id) JOIN url_categories c USING(category_id)
JOIN users a ON a.user_id=m.assigned_by;

-- G01: report count by workflow status.
SELECT workflow_status,count(*) AS reports FROM report_refs GROUP BY workflow_status;
-- G02: distinct reporting users per URL; avoids counting one user repeatedly.
SELECT url_id,count(DISTINCT reporter_id) AS reporters FROM report_refs
WHERE workflow_status='accepted' AND sync_status='synced' GROUP BY url_id;
-- G03: vote distribution by URL and verdict.
SELECT url_id,verdict,count(*) AS votes FROM votes GROUP BY url_id,verdict;
-- G04: daily new URLs using a stated UTC reporting boundary.
SELECT (first_seen_at AT TIME ZONE 'UTC')::date AS day,count(*) AS urls
FROM urls GROUP BY day ORDER BY day;
-- G05: current risk distribution (one current score per URL).
SELECT label,count(*) AS urls,round(avg(score),2) AS average_score
FROM v_current_risk GROUP BY label;

-- H01: URLs with at least two independent accepted reporters.
SELECT url_id,count(DISTINCT reporter_id) AS reporters FROM report_refs
WHERE workflow_status='accepted' AND sync_status='synced'
GROUP BY url_id HAVING count(DISTINCT reporter_id)>=2;
-- H02: users who have voted on at least two URLs.
SELECT user_id,count(*) AS votes FROM votes GROUP BY user_id HAVING count(*)>=2;
-- H03: hostnames associated with at least two distinct stored URLs.
SELECT hostname,count(*) AS urls FROM urls GROUP BY hostname HAVING count(*)>=2;
-- H04: campaigns containing at least two URLs.
SELECT campaign_id,count(*) AS urls FROM campaign_urls
GROUP BY campaign_id HAVING count(*)>=2;
-- H05: contested URLs with both safe and malicious votes.
SELECT url_id,count(*) AS votes FROM votes GROUP BY url_id
HAVING bool_or(verdict=1) AND bool_or(verdict=-1);

-- Q01: URLs with no votes (correlated NOT EXISTS).
SELECT u.url_id,u.display_url FROM urls u
WHERE NOT EXISTS (SELECT 1 FROM votes v WHERE v.url_id=u.url_id);
-- Q02: URLs above the current population mean score (scalar subquery).
SELECT url_id,score FROM v_current_risk
WHERE score>(SELECT avg(score) FROM v_current_risk);
-- Q03: users who have submitted an accepted report (correlated EXISTS).
SELECT u.user_id,u.display_name FROM users u
WHERE EXISTS (SELECT 1 FROM report_refs r
 WHERE r.reporter_id=u.user_id AND r.workflow_status='accepted' AND r.sync_status='synced');
-- Q04: URLs belonging to a confirmed campaign (IN subquery).
SELECT url_id,display_url FROM urls WHERE url_id IN (
 SELECT cu.url_id FROM campaign_urls cu JOIN campaigns c USING(campaign_id)
 WHERE c.status='confirmed');
-- Q05: most recent report time for every URL, including NULL when absent.
SELECT u.url_id,u.display_url,
 (SELECT max(r.created_at) FROM report_refs r WHERE r.url_id=u.url_id) AS last_report
FROM urls u;
```


The UI should not run arbitrary SQL from the browser. Bind user input with driver parameters such as $1 and $2, allow-list sortable column names, and cap result limits. A report count and a vote count must be aggregated separately before joining; directly joining both child tables can multiply rows and inflate totals. v_url_summary demonstrates the correct pattern.

## 13 DDL Statements

database/01_schema.sql is the complete executable DDL for all 22 tables, including primary and foreign keys, CHECK and UNIQUE constraints, generated columns, ordinary indexes, full-text GIN, and vector HNSW. database/02_features.sql creates views, functions, triggers, and procedures. Run them in that order on a clean database before loading seed data.

Representative CREATE TABLE and index definitions are shown below. The complete file is included in the companion package so every attribute in Section 9 has an executable definition.


```sql
CREATE TABLE votes (
  user_id uuid REFERENCES users(user_id),
  url_id uuid REFERENCES urls(url_id),
  verdict smallint NOT NULL CHECK (verdict IN (-1,1)),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, url_id)
);

CREATE TABLE report_refs (
  report_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url_id uuid NOT NULL REFERENCES urls(url_id),
  reporter_id uuid NOT NULL REFERENCES users(user_id),
  report_type varchar(24) NOT NULL
    CHECK (report_type IN ('phishing','scam_message','other')),
  workflow_status varchar(16) NOT NULL DEFAULT 'pending'
    CHECK (workflow_status IN ('pending','accepted','rejected','withdrawn')),
  sync_status varchar(16) NOT NULL DEFAULT 'pending'
    CHECK (sync_status IN ('pending','synced','failed')),
  content_version integer NOT NULL DEFAULT 1 CHECK (content_version > 0),
  idempotency_key uuid NOT NULL,
  request_hash bytea NOT NULL CHECK (octet_length(request_hash) = 32),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (reporter_id, idempotency_key),
  UNIQUE (report_id, url_id)
);

CREATE INDEX urls_search_gin ON urls USING gin(search_vector);
CREATE INDEX embeddings_cosine_hnsw ON embeddings
  USING hnsw (embedding vector_cosine_ops);
```


The ALTER and DROP demonstration operates on a temporary classroom table and rolls back, rather than destroying the project schema.

```sql
BEGIN;
CREATE TABLE ddl_demo (id integer PRIMARY KEY, label text);
ALTER TABLE ddl_demo ADD COLUMN created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE ddl_demo ADD CONSTRAINT label_not_blank
  CHECK (length(trim(label)) > 0);
CREATE INDEX ddl_demo_label_idx ON ddl_demo(label);
DROP TABLE ddl_demo;
ROLLBACK;
```

Use numbered migrations in Git, separate migration credentials from API credentials, and review each migration before applying it. Do not use DROP TABLE CASCADE to solve foreign-key errors in a shared database. Back up before a destructive schema change and rehearse restoration on a separate database.

## 14 DML Statements

database/05_dml.sql contains INSERT, UPDATE, SELECT, and DELETE demonstrations for the mutable major tables: users, roles, user_roles, urls, url_categories, url_category_map, votes, report_refs, campaigns, campaign_urls, alerts, notifications, refresh_sessions, auth_tokens, outbox_events, ai_analyses, embeddings, and similarity_edges. Each demonstration rolls back. It includes a synthetic vector only for exercising vector-type DML; that vector is not presented as a real model result.

Optional campaign, alert, notification and AI examples use fixture data solely to retain the full reference schema. Core functionality does not require those application modules.

The four history tables, reputation_events, moderator_actions, risk_scores, and audit_logs, are append-only under application credentials. They demonstrate INSERT and SELECT. A reputation correction is a compensating event, a revised verdict is a new moderator action, and a new calculation inserts a risk snapshot. Updating or deleting these records through ordinary application endpoints would defeat the audit design. Anonymization and retention run through a separately authorized maintenance process.


```sql
-- Run after seed. Every block rolls back, so sample edits are reversible.
-- Parameters in a real API come from a driver, not string concatenation.

-- USERS: four operations on a temporary account.
BEGIN;
INSERT INTO users(user_id,email,display_name,password_hash)
VALUES('00000000-0000-4000-8000-000000009901','demo@example.test','Demo','DISABLED');
UPDATE users SET display_name='Demo Student' WHERE user_id='00000000-0000-4000-8000-000000009901';
SELECT user_id,display_name,status FROM users WHERE user_id='00000000-0000-4000-8000-000000009901';
DELETE FROM users WHERE user_id='00000000-0000-4000-8000-000000009901';
ROLLBACK;

-- VOTES: upsert changes a verdict instead of allowing duplicate votes.
BEGIN;
INSERT INTO votes(user_id,url_id,verdict)
VALUES('00000000-0000-4000-8000-000000000002','00000000-0000-4000-8000-000000000104',1);
UPDATE votes SET verdict=-1,updated_at=now() WHERE user_id='00000000-0000-4000-8000-000000000002' AND url_id='00000000-0000-4000-8000-000000000104';
SELECT * FROM votes WHERE url_id='00000000-0000-4000-8000-000000000104';
DELETE FROM votes WHERE user_id='00000000-0000-4000-8000-000000000002' AND url_id='00000000-0000-4000-8000-000000000104';
ROLLBACK;

-- REPORT_REFS and OUTBOX_EVENTS must be created in the same transaction.
BEGIN;
INSERT INTO report_refs(report_id,url_id,reporter_id,report_type,idempotency_key,request_hash)
VALUES('00000000-0000-4000-8000-000000009201','00000000-0000-4000-8000-000000000104','00000000-0000-4000-8000-000000000001','scam_message','00000000-0000-4000-8000-000000009902',digest('redacted-demo-request','sha256'));
INSERT INTO outbox_events(event_type,aggregate_id,aggregate_version,payload)
VALUES('report.create','00000000-0000-4000-8000-000000009201',1,'{"message_text":"Redacted demo message"}');
UPDATE report_refs SET sync_status='pending' WHERE report_id='00000000-0000-4000-8000-000000009201';
UPDATE outbox_events SET status='pending',last_error='Retryable demo failure',available_at=now()+interval '30 seconds' WHERE aggregate_id='00000000-0000-4000-8000-000000009201';
SELECT * FROM report_refs WHERE report_id='00000000-0000-4000-8000-000000009201';
SELECT event_type,status FROM outbox_events WHERE aggregate_id='00000000-0000-4000-8000-000000009201';
DELETE FROM outbox_events WHERE aggregate_id='00000000-0000-4000-8000-000000009201';
DELETE FROM report_refs WHERE report_id='00000000-0000-4000-8000-000000009201';
ROLLBACK;
```


Production report creation also inserts an outbox event in the same transaction; changing report status or text increments its version and projects that change to MongoDB. A normal withdrawal changes workflow_status to withdrawn and invalidates related vector entries. The hard DELETE in the teaching script applies only to a newly created, rolled-back fixture. Referenced URL rows are archived, and closed accounts are anonymized instead of breaking evidence references.

## 15 Advanced Database Features

All eight concepts remain documented. Seven are mandatory implementation demonstrations, exceeding the college minimum of four. Stored procedures/functions are an additional concept, with supplied helpers that the team can reuse to reduce backend code. Their separate viva demonstration is optional; the core report-review and scoring behavior is mandatory whether orchestrated by those helpers or equivalent backend transactions. The starter setup retains the helpers, and its seed and scoring examples call them. Scripts exist, but database execution still requires validation.

| Feature | Priority | CrowdShield use | Demonstration evidence |
| --- | --- | --- | --- |
| Transactions | Core | Report envelope plus outbox; moderation and risk snapshots | Inject a SQL failure and prove rollback |
| Triggers | Core | vote_audit records changes and queues risk refresh | Show vote, audit and outbox writes in one transaction |
| Views | Core | Current reputation, latest risk, effective verdict and summary | Compare history with current rows |
| Indexing | Core | Unique URL hash, lookup/queue indexes, GIN and HNSW | Capture query plans and measured timings |
| Full-text search | Core | Sanitized hostname and summary search | Execute ranked lookup through search_vector |
| MongoDB aggregation | Core | Top reported URLs, daily reports and contributors | Run the first three pipelines; campaign growth is enhanced |
| Vector similarity | Core | Accepted report retrieval and reviewed anchors | Compare exact and HNSW results on one small dataset |
| Stored procedures and functions | Additional | Supplied moderate_report and recalculate_risk helpers | Optional separate CALL walkthrough; used by the starter scripts |


```sql
CREATE VIEW v_current_risk AS
SELECT DISTINCT ON (url_id) * FROM risk_scores
ORDER BY url_id, computed_at DESC, risk_score_id DESC;

-- Latest decision wins, including clear; expiry never revives older decisions.
CREATE VIEW v_effective_verdict AS
SELECT url_id,
  CASE WHEN verdict <> 'clear'
       AND (valid_until IS NULL OR valid_until > now())
       THEN verdict END AS verdict,
  action_id, created_at, valid_until
FROM (
  SELECT DISTINCT ON (url_id) * FROM moderator_actions
  WHERE action_kind = 'set_verdict'
  ORDER BY url_id, created_at DESC, action_id DESC
) latest;


CREATE FUNCTION audit_vote_change() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v_user uuid; v_url uuid; v_verdict smallint; v_version integer;
BEGIN
  IF TG_OP='DELETE' THEN
    v_user:=OLD.user_id; v_url:=OLD.url_id; v_verdict:=OLD.verdict;
  ELSE
    v_user:=NEW.user_id; v_url:=NEW.url_id; v_verdict:=NEW.verdict;
  END IF;
  INSERT INTO audit_logs(actor_id,action,entity_type,entity_id,details)
  VALUES (v_user,'vote.'||lower(TG_OP),'url',v_url::text,
    jsonb_build_object('verdict',v_verdict));
  UPDATE urls SET evidence_version=evidence_version+1
  WHERE url_id=v_url RETURNING evidence_version INTO v_version;
  INSERT INTO outbox_events(event_type,aggregate_id,aggregate_version,payload)
  VALUES('risk.refresh',v_url,v_version,'{}');
  IF TG_OP='DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END $$;
CREATE TRIGGER vote_audit AFTER INSERT OR UPDATE OR DELETE ON votes
FOR EACH ROW EXECUTE FUNCTION audit_vote_change();


-- Full procedure definitions: database/02_features.sql.
BEGIN ISOLATION LEVEL REPEATABLE READ;
CALL recalculate_risk('00000000-0000-4000-8000-000000000101');
COMMIT;
SELECT * FROM v_current_risk;
SELECT * FROM urls
WHERE search_vector @@ websearch_to_tsquery('simple','parcel fee');
```


Use REPEATABLE READ for a consistent risk calculation snapshot, plus a URL row lock to serialize competing recalculations. Retry serialization failures rather than swallowing them. PostgreSQL's isolation level affects what concurrent transactions can observe; a SQL transaction does not extend to MongoDB [2]. A score is an as-of snapshot, so a vote arriving just after that snapshot must queue another refresh.

Each material evidence change increments urls.evidence_version and inserts a risk.refresh outbox event in the same source transaction. The vote trigger implements this for vote changes; the other event producers must do the same. Campaign narrative updates use campaigns.content_version. Discussion and comment edits conditionally increment their MongoDB content_version.

Recalculate affected URLs when votes, accepted report state, account eligibility, reputation, reviewed verdicts, or similarity neighbors change. Expiring verdicts and time-decayed reports also need a periodic refresh, for example hourly in the college implementation. A changed reviewed neighbor invalidates dependent scores through similarity_edges. Show computed_at and flag stale scores; an expired verdict must not remain displayed as current confirmation merely because an old score row exists.

## 16 Risk Scoring Algorithm

### Risk Model Status

These weights and thresholds are project heuristics selected for transparency and demonstration. They are not claimed to be scientifically calibrated probabilities. The algorithm remains crowdshield-v1 because this revision changes scope and field naming, not its formula. Its implementation reference is recalculate_risk; arithmetic checks are separate from database execution or detection-quality evaluation. AI output never contributes to the calculation.

The score is an explainable project heuristic on a 0 to 100 scale, not a calibrated probability. Use it to prioritize review. Use the exact contract fields score, coverage, label and moderator_verdict. The first two are numbers; label is insufficient_evidence, low, medium or high; moderator_verdict is safe, malicious or null. A clear or expired action remains in history but yields null as the effective moderator_verdict. PostgreSQL, the API and the UI use the same rounded score and label thresholds.

### Community and reputation

For user i, reputation r_i = clamp(20 + sum of reputation deltas, 0, 100). Voting weight w_i = 0.5 + r_i / 100, so one account has a bounded weight from 0.5 to 1.5. Only active, verified users contribute. For the college demo, email_verified_at records completion of the restricted local verification flow; it does not prove real mailbox ownership. Let m_i be 1 for a malicious vote and 0 for a safe vote.

V = (1 + sum(w_i times m_i)) / (2 + sum(w_i)).

The two pseudocounts make no-vote evidence neutral at 0.5. One account has one current vote. A report is not automatically a vote. Moderators award reputation for independently verified contributions, never merely for matching the current majority. Use unique dedupe keys for awards and negative events for demonstrated abuse.

### Independent accepted reports

Consider only accepted, synchronized reports from eligible accounts within the last 30 days. For reporter j, use only the largest contribution among their reports on that URL: a_j = max(w_j times exp(-age_days / 30)). Then:

R = 1 - exp(-sum(a_j) / 5).

This saturating function makes additional independent reports matter less at high volume. Repeated reports from the same account do not amplify its contribution. It does not eliminate coordinated multiple-account abuse; verification, limits, reviewer judgment, and abuse detection are still required.

### Similarity to reviewed URLs

Take up to five distinct neighboring URLs with cosine similarity at least 0.75, computed within seven days under the same model version. Exclude the URL itself, archived URLs, and neighbors without a currently effective moderator verdict. Let t_k be 1 for a reviewed malicious neighbor and 0 for a reviewed safe neighbor.

S = sum(similarity_k times t_k) / sum(similarity_k).

If there are no eligible anchors, set S = 0.5. Never use a neighbor's computed risk score as its label, because that creates recursive amplification. Candidate edges are derived from current accepted content. In a report withdrawal, rejection, edit or relevant account-status transaction, conservatively delete similarity_edges both from and to every affected URL, invalidate its report embeddings, and queue refreshed calculations for those URLs and the previously dependent URLs. Snapshot the dependent URL IDs before deletion. Workers rebuild edges only from current accepted synchronized sources, rechecking versions at commit. This keeps stale edges out of scoring without adding provenance tables to the core. Correlated neighbors within one campaign may still overstate evidence. A stricter later version can cap one anchor per campaign after measuring the effect.

### Combined score and moderator precedence

BaseScore = 100 times (0.55V + 0.25R + 0.20S).

If the latest currently effective moderator verdict is malicious, Score = 95. If it is safe, Score = 5. If it is clear, expired, or absent, Score = BaseScore. These values are policy choices and do not mean certainty. The latest verdict action always supersedes earlier ones; expiration must not resurrect an older decision.

Let N be the number of distinct eligible contributors across votes and counted reports, and K be the number of reviewed similarity anchors. Coverage C = min(1, (N + 2K) / 10). A current moderator verdict sets C to 1 as a reviewed-evidence flag. C is an evidence-coverage indicator, not a statistical confidence interval and not independence-adjusted certainty.

| Condition | Display label |
|---|---|
| C below 0.30 | Insufficient evidence, regardless of numerical score |
| C at least 0.30 and score below 40 | Low observed risk |
| C at least 0.30 and score from 40 to below 70 | Medium observed risk |
| C at least 0.30 and score at least 70 | High observed risk |

With no votes, accepted reports, or neighbors, V = 0.5, R = 0, S = 0.5, BaseScore = 37.5, and C = 0. The UI must display Insufficient evidence, not Safe. Absence of reports is not a safety certification.

Worked example: suppose malicious vote weight is 4.0, safe vote weight is 1.0, accepted-report contribution sum is 3.0, and S is 0.85. V = 5/7 = 0.7143 and R = 1 - exp(-0.6) = 0.4512. The base score is approximately 67.57, which is Medium if coverage is adequate. A currently effective reviewed malicious decision changes it to 95 and shows the review reason and expiry. The SQL procedure implements these same components and records its algorithm version. For an illustrative N=5 and K=2 in this example, coverage=0.9; those counts are additional example inputs, not deductions from the weighted totals.

### Explainability and evaluation

Show the number of independent contributors, report window, weighted vote balance, reviewed neighbor count, moderator reason, component values, and computation time. Core testing verifies the formula, review precedence, evidence eligibility and retrieval on a small disclosed fixture. A larger detection-quality study is enhanced: evaluate on a labeled holdout set with campaign-level splits to reduce leakage, then measure false-positive/false-negative rates, precision, recall and confusion counts. Do not tune and report final accuracy on the same examples. AI text must not silently override the deterministic score.

## 17 NoSQL Aggregation Pipelines

A01 to A03 are mandatory. A04 campaign growth is preserved as an enhanced pipeline; sample campaign memberships do not imply a completed campaign feature. All counts use MongoDB workflow_status and must expose projection freshness.

These pipelines rank top reported URLs, calculate daily phishing reports, identify active contributors, and show campaign trends. They use accepted MongoDB projections. Review-state changes may take time to appear, so the UI displays when analytics were refreshed. SQL remains the visibility authority for individual records.


```javascript
// Read-only mongosh examples. Counts reflect Mongo's projected state;
// reconcile permissions and current report state with SQL before public display.
const since7 = new Date(Date.now()-7*86400000);
const since14 = new Date(Date.now()-14*86400000);

// A01 Top reported URLs: rank by distinct reporters, then raw report count.
printjson(db.scam_reports.aggregate([
 {$match:{workflow_status:'accepted'}},
 {$group:{_id:'$url_id',report_count:{$sum:1},reporters:{$addToSet:'$reporter_id'}}},
 {$project:{_id:1,report_count:1,unique_reporters:{$size:'$reporters'}}},
 {$sort:{unique_reporters:-1,report_count:-1,_id:1}},{$limit:10}
]).toArray());

// A02 Daily accepted phishing reports in UTC buckets.
printjson(db.scam_reports.aggregate([
 {$match:{workflow_status:'accepted',report_type:'phishing',created_at:{$gte:since14}}},
 {$group:{_id:{$dateTrunc:{date:'$created_at',unit:'day',timezone:'UTC'}},count:{$sum:1}}},
 {$sort:{_id:1}}
]).toArray());
// Days with zero reports are filled by the API calendar series, not fabricated.

// A03 Most active users, measured as accepted reports in the last seven days.
printjson(db.scam_reports.aggregate([
 {$match:{workflow_status:'accepted',created_at:{$gte:since7}}},
 {$group:{_id:'$reporter_id',accepted_reports:{$sum:1},urls:{$addToSet:'$url_id'}}},
 {$project:{accepted_reports:1,distinct_urls:{$size:'$urls'}}},
 {$sort:{accepted_reports:-1,_id:1}},{$limit:10}
]).toArray());
// Resolve public display names through the backend; never publish account email.

// A04 Trending campaigns: compare equal seven-day windows.
printjson(db.scam_reports.aggregate([
 {$match:{workflow_status:'accepted',created_at:{$gte:since14}}},
 {$unwind:'$campaign_ids'},
 {$group:{_id:{campaign:'$campaign_ids',report:'$_id'},
   reporter:{$first:'$reporter_id'},created_at:{$first:'$created_at'}}},
 {$group:{_id:'$_id.campaign',
   recent:{$sum:{$cond:[{$gte:['$created_at',since7]},1,0]}},
   previous:{$sum:{$cond:[{$lt:['$created_at',since7]},1,0]}}}},
 {$match:{recent:{$gte:2}}},
 {$set:{growth:{$divide:[{$subtract:['$recent','$previous']},{$max:['$previous',1]}]}}},
 {$sort:{growth:-1,recent:-1,_id:1}},{$limit:10}
]).toArray());
// campaign_ids is a cached SQL-membership projection. A report in two campaigns
// counts in each campaign; the sum across campaigns is not a global report count.
```


For trends, recent and previous each span seven days. Dividing by max(previous, 1) avoids division by zero; label campaigns with previous = 0 as new rather than claiming a mathematically infinite percentage rise. Sort ties deterministically. The top-reported pipeline counts independent reporters as well as documents. A top-scam-category chart can join authorized SQL category counts or group MongoDB report_type, but those are different metrics and must be labeled accordingly.

## 18 Vector Search Features

Semantic search over accepted report text and related URLs derived from that evidence are core. Direct URL-context embedding, duplicate-report suggestions, campaign clustering and campaign suggestions are enhanced. All use cases remain below as the reference design. Core evaluation includes a small exact-versus-HNSW comparison; a large ANN benchmark and campaign-quality study are enhanced.

| Feature | Input and operation | Returned value and safeguard |
|---|---|---|
| Similar phishing URL detection | Embed a URL context and compare with reviewed URL contexts | Related examples and similarity, never automatic proof |
| Scam campaign clustering | Form candidate edges among recent accepted reports above a tuned similarity threshold | Analyst-review queue of clusters; moderator confirms membership |
| Duplicate report detection | Compare new redacted message text with recent accepted or own pending reports | Potential duplicates; retain independent reporters and provenance |
| Semantic search | Natural-language query such as fake parcel redelivery fee | Authorized report snippets even if exact wording differs |

For the enhanced clustering implementation, create a graph of candidate URLs connected by strong semantic similarity and shared indicators such as brand, template, or domain pattern. Find connected components as suggestions, then show the links for manual review. Similarity transitivity can join unrelated groups through a weak bridge, so do not automatically label every connected component a confirmed campaign. Record a moderator's link_reason in campaign_urls and preserve a rejected-suggestion record in audit context if needed.

Evaluate duplicate retrieval with precision at k and campaign suggestions with reviewer acceptance rate. Compare semantic retrieval to exact and full-text search using a small documented set of queries. Measure recall at 10 for HNSW against exact retrieval using the same vectors and filters. Store model and preprocessing versions with the experiment so it can be reproduced.

## 19 REST API Design

All routes start with /api/v1. P means public sanitized access, U means authenticated active User with required ownership, M means Moderator or Admin, and A means Admin only. Verification is additionally required for community writes. Backend authorization is mandatory even if the UI hides a button.

### Core API

Implement these 31 method-route pairs for the working demo. Reuse URL detail for vote totals and risk history SQL for the database demonstration; dedicated convenience endpoints remain optional. Every row is a planned handler contract, not a completed route.

| Method | Route | Access | Description |
| --- | --- | --- | --- |
| POST | /auth/register | P | Register an account |
| POST | /auth/login | P | Authenticate and create a session |
| POST | /auth/refresh | Cookie | Renew the opaque server-side session and revoke its predecessor; no JWT |
| POST | /auth/logout | U | Revoke the current session |
| POST | /auth/verify-email | Token | Consume the local demo verification token; production delivery is enhanced |
| GET | /me | U | Read own profile |
| GET | /me/contributions | U | Read own report metadata and vote/report/reputation counts |
| POST | /urls | U | GET: query and offset pagination; POST: normalize and create or resolve URL |
| POST | /urls/lookup | P | Exact lookup without placing raw URL in an access-log query string |
| GET | /urls | P | GET: query and offset pagination; POST: normalize and create or resolve URL |
| GET | /urls/{id} | P | Read sanitized URL detail |
| GET | /urls/{id}/risk | P | Read score, coverage, label, moderator_verdict and staleness |
| PUT | /urls/{id}/vote | U | Create or change own verdict |
| DELETE | /urls/{id}/vote | U | Withdraw own verdict |
| POST | /reports | U | Queue a redacted report with idempotency key |
| GET | /reports/{id} | U or M | Read owned or reviewable report, including sync state |
| DELETE | /reports/{id} | Owner | Withdraw report and invalidate derived content |
| GET | /urls/{id}/reports | P | List public eligible reports plus owned or reviewer-visible metadata |
| GET | /search/text | P | Search safe hostname and public summary |
| POST | /search/semantic | U | Retrieve authorized current accepted report matches; core source_kind is report |
| GET | /analytics/overview | P | Read public aggregate dashboard |
| GET | /analytics/trends | P | Read a fixed 14-day SQL trend and eligible MongoDB aggregates |
| GET | /moderation/reports | M | Read pending report metadata; review requires synchronized content |
| POST | /moderation/reports/{id}/decision | M | Accept or reject with a reason |
| POST | /moderation/urls/{id}/verdict | M | Set or clear a time-bounded reviewed verdict |
| GET | /admin/users | A | List accounts without secrets |
| PATCH | /admin/users/{id}/status | A | Suspend or restore account and invalidate scores |
| PUT | /admin/users/{id}/roles/{role} | A | Grant an allowed role |
| DELETE | /admin/users/{id}/roles/{role} | A | Revoke role while protecting final admin |
| GET | /admin/audit-logs | A | Read the latest 100 audit entries |
| GET | /admin/jobs | A | Read latest outbox delivery states without private payloads |

### Enhanced optional API

These 37 preserved method-route pairs are the reference architecture. Leave them unmounted and hide their controls until implemented and tested. Disabled routes return 404; clients must not rely on them in the core workflow.

| Method | Route | Access | Description |
| --- | --- | --- | --- |
| POST | /auth/forgot-password | P | Request a generic password-reset response |
| POST | /auth/reset-password | Token | Reset using a single-use token and revoke sessions |
| PATCH | /me | U | Change own display name |
| GET | /urls/{id}/risk-history | P | Read score timeline |
| GET | /urls/{id}/votes | P | Read aggregate vote counts |
| PATCH | /reports/{id} | Owner | Edit own pending report using version check |
| POST | /reports/{id}/evidence | Owner | Upload one quarantined evidence file |
| GET | /evidence/{id} | Owner or M | Authorize access to clean evidence |
| DELETE | /evidence/{id} | Owner or M | Tombstone evidence and queue binary deletion |
| GET | /urls/{id}/similar | P | Read sanitized related URL contexts |
| POST | /reports/duplicate-check | U | Suggest duplicates in accepted or own evidence |
| POST | /urls/{id}/analyses | U | Queue an AI explanation |
| GET | /analyses/{id} | Owner or M | Read AI job status and permitted output |
| POST | /discussions | U | Create a URL discussion |
| GET | /discussions | P | List visible threads |
| GET | /discussions/{id} | P | Read visible thread with paginated comments |
| PATCH | /discussions/{id} | Owner | Edit own open discussion |
| POST | /discussions/{id}/comments | U | Add a comment to an open discussion |
| PATCH | /comments/{id} | Owner | Edit own visible comment |
| DELETE | /comments/{id} | Owner | Soft-delete own comment |
| GET | /campaigns | P | List sanitized campaign summaries |
| GET | /campaigns/{id} | P | Read campaign description and member URLs |
| POST | /campaigns | M | Create a campaign and narrative job |
| PATCH | /campaigns/{id} | M | Change campaign state or narrative version |
| POST | /campaigns/{id}/urls | M | Link a URL with a review reason |
| DELETE | /campaigns/{id}/urls/{urlId} | M | Remove membership and invalidate projections |
| GET | /campaigns/suggestions | M | Read candidate clusters for review |
| GET | /analytics/export | U | Download sanitized bounded CSV aggregates |
| POST | /alerts | U | Subscribe own account to a URL threshold |
| GET | /alerts | U | List own subscriptions |
| PATCH | /alerts/{id} | Owner | Change threshold or enable state |
| DELETE | /alerts/{id} | Owner | Delete a subscription |
| GET | /notifications | U | List own notifications |
| PATCH | /notifications/{id}/read | Owner | Mark a notification read |
| PATCH | /moderation/discussions/{id} | M | Lock or hide a thread with audit |
| PATCH | /moderation/comments/{id} | M | Hide or restore a comment with audit |
| POST | /admin/jobs/{id}/retry | A | Retry a failed or parked idempotent job |

### Request contracts and failures

POST /urls accepts url and optional public_summary. POST /reports accepts url_id, report_type, redacted message_text, narrative, channel, and an Idempotency-Key header. The authenticated identity supplies reporter_id; ignore any browser-supplied author or role. Return 201 for synchronous creation and 202 for queued processing. A replay with the same key and same payload returns the original result; the same key with different payload returns 409 after comparing the request hash retained in report_refs.request_hash.

PUT /urls/{id}/vote accepts verdict as safe or malicious, translated to -1 or 1. POST /search/semantic accepts query, source_kind=report, limit, and an optional category filter in core; other source kinds are rejected until the enhanced path exists. In enhanced scope, POST /urls/{id}/analyses returns analysis_id and status; the UI polls the analysis endpoint. POST /moderation/urls/{id}/verdict accepts verdict, reason, and optional valid_until. A clear action removes the effective override without deleting history.

Use 400 for malformed input, 401 for unauthenticated access, 403 for a forbidden operation, 404 for unavailable or inaccessible records, 409 for state/version conflicts, 413 for oversized evidence, 422 for semantic validation failure, 429 for limits, and 503 for a required unavailable service. Return a stable error code and request ID, not SQL errors or stack traces. Report responses expose workflow_status, sync_status and content_version separately. MongoDB scam_reports uses the same workflow_status and content_version names; sync_status stays authoritative in SQL. Mutation responses include the new content_version when applicable. An If-Match version prevents silent overwrites of concurrent report, discussion, or campaign edits.

List responses contain items, next_cursor, and as_of. Cursors encode stable pairs such as created_at and UUID; validate or sign them. A maximum limit of 50 prevents unbounded queries. Authorized detail endpoints can return private information but must not be cached in a shared public cache. Refresh and logout operations are POST requests protected against CSRF.

### Risk response example

GET /api/v1/urls/{id}/risk returns the persisted calculation fields below. This is an illustrative payload for the worked example, not measured output. Numeric SQL values are serialized as JSON numbers after range validation; the UI displays score to two decimals and coverage as a percentage. It never recalculates a different score in the browser.

```json
{
  "url_id": "00000000-0000-4000-8000-000000000101",
  "score": 67.57,
  "coverage": 0.9,
  "label": "medium",
  "moderator_verdict": null,
  "community_component": 0.71429,
  "report_component": 0.45119,
  "similarity_component": 0.85,
  "algorithm_version": "crowdshield-v1",
  "inputs": {"distinct_contributors": 5, "anchors": 2},
  "computed_at": "2026-09-29T12:00:00Z",
  "is_stale": false
}
```

is_stale is API-derived from evidence_version, pending refreshes and time-sensitive expiry; it is not an extra SQL column. If no calculation exists, return risk=null with processing=true in the URL detail response, and show Processing rather than inventing a score. For the dedicated risk endpoint, return 202 with processing=true until a snapshot exists.

## 20 Next.js Frontend

Use the App Router with server-rendered lookup and detail pages, and client components for forms, votes, filters, charts and polling. Keep database access in server-only modules and Route Handlers [7]. Pin tested package versions in the application lockfile. The mandatory demo contains exactly seven feature page areas; authentication screens support them and are not counted as additional feature areas.

### Core Pages

| Page and route | Components | Important states |
|---|---|---|
| Home / Lookup at / | URL input, exact lookup, full-text and semantic tabs, sanitized results | Unknown URL, invalid input, no matches, rate limit |
| Dashboard /dashboard | Own contributions, reports table, processing status, risk summaries | Signed out, no activity, pending delivery, retry scheduled |
| URL Detail /urls/[id] | Defanged URL, score, coverage, label, moderator_verdict, component breakdown, accepted evidence and vote buttons | Insufficient evidence, stale score, review expiry, processing |
| Report Scam /reports/new | URL selection, report type, redacted message and narrative, channel, consent preview | Validation error, idempotency conflict, 202 pending |
| Moderation /moderation | Synchronized review queue, private report viewer, reason form, verdict expiry | Own-report restriction, conflict, stale document version |
| Admin /admin | Accounts, role grants, suspensions, outbox status and audit filters | Last-admin guard, restricted access, failed delivery |
| Analytics /analytics | Daily reports, risk distribution, top reported URLs and contributors | Empty range, explicit time zone, freshness timestamp |

Supporting /login, /register and /verify screens implement authentication and local token consumption. /lookup may redirect to the Home / Lookup area. Semantic retrieval lives in its search tab and does not need a dedicated page.

Core reusable components are UrlInput, RiskBadge, EvidenceCoverage, RiskBreakdown, VoteButtons, ReportStatus, SimilarityResult, Pagination, AuditTable and AsyncJobStatus. ReportStatus shows workflow_status, sync_status and content_version separately. EvidenceCoverage displays coverage × 100 percent with the label Evidence coverage. The UI uses the API label and effective moderator_verdict, including null after clear or expiry; no label implies guaranteed safety. Use readable neutral tables, visible labels, inline errors and keyboard navigation.

### Enhanced Pages

| Page or module | Retained design |
|---|---|
| Discussions /discussions and /discussions/[id] | Threads, comments, ownership checks, lock/hide controls and versioned edits |
| Campaigns /campaigns/[id] | Description, indicators, members, timeline and reviewed suggestions |
| Dedicated semantic search /search | Optional convenience page using the existing semantic API |
| Extensions inside core pages | AI panel, evidence uploads/viewer, notifications, watched URLs, CSV export and campaign analytics |

Enhanced navigation and actions appear only when their backend and tests exist. URLs display as defanged text such as hxxps://parcel-check[.]example. Do not fetch previews or render attacker-controlled HTML. Public pages omit email addresses, private notes, token-bearing query values and unreviewed message text.

The retained enhanced AI panel contains a summary, observed signals, linked evidence IDs, precautions and limitations. Its prompt uses only authorized redacted evidence as untrusted data and requires structured JSON. The worker validates schema and source IDs, records model_name and prompt_version, and shows failures clearly. AI text has no authority over the risk score. The enhanced evidence viewer authorizes each private download and releases only files whose implemented checks have passed.

## 21 Security Features

### Mandatory security

Core release controls are password hashing, JWT/session validation, RBAC, resource ownership, SQL parameterization, MongoDB and API validation, XSS and CSRF defenses, rate limiting, environment configuration and exclusion of secrets from source control. They are implementation requirements; the design document does not establish their execution.

### Identity and authorization

Use short-lived signed JWT access tokens with issuer, audience, subject, expiry, and a fixed allow-list of algorithms. Verify the signature and claims on the server; decoding alone is not validation. An opaque high-entropy refresh token is stored in an HttpOnly, Secure, SameSite cookie, with only its hash stored in refresh_sessions. Rotate it atomically; revoke the session family on detected reuse. The family_id groups rotated refresh-session records; each rotation carries it forward, and reuse revokes the whole family. Never store refresh tokens in localStorage.

Hash passwords with a maintained Argon2id library and per-password salts. A starting OWASP-recommended configuration is 19 MiB memory, two iterations, and parallelism one, subject to benchmarking on the deployment machine [8]. Keep any pepper and signing keys outside the database and source repository. Account verification tokens are random, hashed, expiring and consumed once in a transaction. Enhanced password reset must use the same token protections. The demo SQL uses DISABLED password fields that must never authenticate.

Every protected operation checks active account state, role, resource ownership, and workflow. Check suspended status and role changes against current server state, including for an otherwise unexpired JWT. The moderator procedure validates a moderator role as defense in depth, but the trusted API must supply the authenticated actor ID. Do not grant browsers database credentials.

### Local account verification for the college demo

Core verification uses a development-only local delivery flow. The meaning is explicit: it tests token issuance, expiry and consumption, but does not establish real email ownership. Retain email_verified_at for schema compatibility and display Demo account verified in the local UI. Production mailbox verification and delivery are enhanced.

1. After registration, generate 32 cryptographically random bytes, encode a URL-safe token, and store only its SHA-256 hash in auth_tokens with purpose=verify_email and a 15-minute expiry. Never put a raw token into SQL, Git, shared logs or an API response.
2. With APP_MODE=local-demo and VERIFICATION_DELIVERY=local-file, deliver the raw token once to a restricted local outbox directory outside public/ and the repository. The directory has owner-only access and files use mode 0600. Bind the demo app to loopback with local HTTPS so Secure cookies remain enabled. The operator reads the file locally and pastes the token into /verify; no public token-retrieval endpoint exists. Remove the delivery file after consumption or expiry.
3. POST /api/v1/auth/verify-email receives the token in the request body, hashes it, and atomically consumes a matching unused unexpired token and sets users.email_verified_at for an active account. Use one SQL transaction and row locking or UPDATE ... RETURNING. Exactly one concurrent request can succeed. Invalid, expired or reused tokens give a generic failure.
4. Fail closed at startup if local delivery is selected outside local-demo mode. A hosted release must implement a real delivery adapter or disable new community writes; it must not expose the local outbox. Tokens are redacted from logs and use the same rate and browser protections as other authentication operations.

The backend and local delivery adapter remain planned. Tests T01 and T04 include issuance, expiry and single-use checks. The existing auth_tokens table supplies the required storage; no production email infrastructure is necessary for the core classroom demo.

### Input and browser security

Bind SQL parameters with the database driver. Do not concatenate URL, search, pagination, or sort input into SQL. Validate MongoDB inputs against an allow-listed schema, construct operators on the server, and reject client-supplied $ operators or arbitrary JSON query fragments. Validation is required both in the API and through SQL constraints or MongoDB validators.

Render report text as text. If a Markdown editor is used, disable raw HTML or sanitize its output, and enforce a Content Security Policy. Escape text in titles, filenames, chart labels, and AI output. Reject dangerous URI schemes. Client-side escaping alone does not protect raw HTML inserted elsewhere.

For cookie-authenticated state-changing requests, validate an anti-CSRF token and Origin, use appropriate SameSite settings, and never mutate through GET. CORS is a separate browser policy, not a substitute for CSRF protection. If an access token is kept in memory and sent through an Authorization header, the refresh-cookie endpoints still need CSRF protection.

Start with project limits such as five login attempts per account and IP per 15 minutes, ten reports per verified user per hour, and 30 semantic searches per user per minute. These are configurable initial limits, not universal security recommendations. Use a shared limiter for multi-process deployment, return Retry-After, and monitor coordinated abuse without collecting unnecessary personal data.

### URL safety in core

URL intake does not fetch the submitted website. Parse with a standard URL library, allow HTTP and HTTPS, reject embedded credentials, normalize scheme and host case, convert internationalized hostnames consistently, remove default ports and fragments, and preserve path case, query ordering, and meaningful query values. Do not blindly strip or sort query parameters, since that can change the resource. Reject or require user redaction of known credential-bearing query fields. Do not claim complete detection of all secrets.

Keep canonical_url restricted to appropriate backend and reviewer access; public display_url is defanged and redacts sensitive query values. For exact lookup, apply the same normalization version on submission and query. If normalization rules change, migrate and deduplicate carefully rather than silently changing identity.

### Enhanced security

These controls apply only when the corresponding optional feature is built and tested. Automated URL fetching would require a separate sandboxed egress worker. Validate resolved addresses and every redirect, block loopback, private, link-local, and metadata endpoints, and guard against DNS rebinding. URL parsing alone does not prevent server-side request forgery [9]. The initial release avoids this entire fetch pathway while still supporting user-supplied evidence.

For enhanced evidence uploads, validate size, detected MIME type, extension, and content; generate random object keys, quarantine new uploads, and scan before release. Do not execute HTML or scripts. Serve downloads with safe headers and scoped authorization. Scan availability and sample test files should be documented rather than claimed as implemented without evidence.

### Core data controls and enhanced AI safeguards

Use separate migration, API, worker, and read-only analytics credentials. Restrict audit and history mutation privileges, encrypt transport, and keep secrets in environment variables such as DATABASE_URL, MONGODB_URI, JWT_SIGNING_KEY, and AI_API_KEY. No secret may use a NEXT_PUBLIC_ prefix. Avoid writing request bodies, raw tokens, or full sensitive URLs to logs.

For an enhanced AI module, reports and retrieved messages may contain prompt-injection instructions. The model receives them as quoted evidence, with no browser, shell, database-write, or URL-fetch tools. Require source IDs in output and validate those IDs against the input set. Cap prompt and output size, redact before any external model call, and explain the configured data-processing choice to users. Treat AI output as untrusted display data and keep it outside scoring authority.

Document retention by data type, allow report withdrawal, anonymize closed accounts, and propagate tombstones to MongoDB, embeddings, cached analytics, and AI outputs. Backups require their own expiry policy. Do not equate withdrawing a report with instantly removing it from every retained backup.

## 22 Test Cases

Planned until execution. All 45 acceptance-test IDs are retained: 25 core tests and 20 enhanced tests. Actual result and evidence are null in tests/test_plan.json. The Python arithmetic/static checks recorded in VALIDATION.md do not mark these application acceptance tests as passed.

The core cases include bounded checks for ownership, single-use local verification, vote change/withdrawal, current model versions, reporter caps, basic exact-versus-HNSW comparison, and the final-admin guard. Detailed concurrency or evaluation suites remain enhanced. An enhanced test classification never permits omitting a core security or integrity rule; the core scenario coverage is stated below and in the JSON plan.

### Core tests

| ID | Area | Test action | Expected result | FR | Owner |
| --- | --- | --- | --- | --- | --- |
| T01 | Registration | Submit the same normalized email twice | Second creation is rejected by the unique index | FR01 | M1 |
| T02 | Authentication | Wrong password and unknown email | Generic failure; no hash or account enumeration | FR03 | M1 |
| T03 | JWT | Alter signature, issuer, audience, or expiry | 401; no protected operation runs | FR03 | M1 |
| T04 | Token reuse | Replay a consumed verification or refresh token; try an expired verification token | Verification succeeds once; expired/reused tokens fail; refresh reuse revokes its family | FR02 FR03 | M1 |
| T05 | RBAC | User calls admin or moderation route | 403 even when request bypasses the UI | FR23 FR32 | M1 |
| T07 | Normalization | Submit host case and default-port variants | Same canonical URL ID returned | FR06 | M1 |
| T09 | Unsafe scheme | Submit javascript, file, embedded credentials | Validation fails and nothing is fetched | FR06 | M1 |
| T10 | Duplicate votes | Two simultaneous votes from one account for same URL | One row remains; upsert determines current verdict | FR11 | M1 |
| T12 | Report replay | Repeat identical idempotency key and payload | Same report ID; no duplicate outbox event | FR07 FR34 | M1 |
| T13 | Conflicting replay | Reuse key with different request hash | 409; original report unchanged | FR07 | M1 |
| T14 | SQL atomicity | Fail report creation after metadata insert | Metadata and outbox both roll back | FR07 FR34 | M1 |
| T15 | Mongo outage | Stop MongoDB after SQL accepts report | 202 pending; retry delivers exactly one current MongoDB document and marks SQL synced | FR10 FR34 | M1 |
| T18 | Mongo validation | Write wrong UUID, status, or string date | Database rejects invalid document | FR07 | M2 |
| T19 | Moderation state | Review pending unsynced report or own report | Procedure or API refuses review | FR23 | M1 |
| T20 | Withdrawn evidence | Withdraw an accepted report while search cache exists | Public lookup and vector result filters exclude it | FR15 FR23 | M2 |
| T21 | No evidence | Score a URL with no input evidence | 37.5 and coverage 0; insufficient evidence label | FR17 FR18 | M1 |
| T22 | Scoring arithmetic | Use worked formula inputs from Section 16 | Approximately 67.57 before moderator override | FR17 | M1 |
| T25 | Verdict expiry | Latest override expires or is cleared | Base score restored after refresh; older verdict not revived | FR24 | M1 |
| T28 | Vector dimension | Insert vector of wrong length or all zero values | Type or CHECK rejects it | FR15 | M2 |
| T32 | Aggregation dates | Use events around UTC midnight and zero-count dates | Correct buckets and explicit zero-fill behavior | FR27 | M2 |
| T34 | XSS | Place script-like text in a report and public URL summary | Text is displayed inertly; no script execution | FR07 FR08 | M2 |
| T35 | CSRF | Send cookie-authenticated mutation from an untrusted origin | Rejected without state change | FR03 | M1 |
| T36 | Injection | Submit SQL quotes and Mongo operator objects | Rejected or treated as data; no expanded query | FR13 | M1 |
| T44 | Performance | Load target data and 20 concurrent users | Record p50/p95, query plans, machine, and bottlenecks | FR13 FR15 | Both |
| T45 | Restore | Restore PostgreSQL and MongoDB backups to a clean environment | Check identities and versions, then replay pending events without duplicates | FR34 | Both |

### Core scenario coverage

- T01: Generate a hashed verification token; no raw token appears in SQL or API output.
- T02: Enforce login rate limits and reject a suspended account.
- T04: Consume a local verification token once; reject reuse, expiry and concurrent consumption.
- T05: Deny another user private report content and prevent removal of the final active admin.
- T07: Keep path case and meaningful query values distinct (basic T08 coverage).
- T10: Change and withdraw a vote; verify audit and risk.refresh writes roll back with the vote.
- T15: After an outage and retry, count exactly one MongoDB document for the report ID; check version and lease-token acknowledgement.
- T18: Reject invalid MongoDB fields while valid report documents retain their content_version.
- T19: Accept a synchronized report as an independent moderator; wait for the new version to sync before including it in search and risk.
- T20: Drop withdrawn, superseded and inaccessible report matches using current SQL state.
- T22: Check reporter capping, reputation bounds and current-account eligibility using the existing formula.
- T25: Show stale state until refreshed; do not revive an earlier moderator verdict after clear or expiry.
- T28: Use the pinned model version; reject mixed versions and compare one exact top-k result set with HNSW.
- T32: Run the three core aggregations and verify dashboard summary joins do not multiply vote/report counts.
- T34: Render script-like report and URL-summary text inertly in core forms and detail pages.
- T44: Measure core lookup, report acceptance and semantic retrieval on the disclosed dataset; record actual p50/p95.
- T45: Restore both core databases, compare report IDs and content versions, and replay retained pending delivery events safely.

### Enhanced tests

These retained cases deepen core edge-case coverage or test optional modules. T16/T17 expand the single required outage demonstration into crash and stale-worker sequences; the underlying replay and lease protections remain core. T31 adds broader ANN evaluation beyond the small core comparison. T43 is a detailed accessibility audit; basic keyboard operation and labels are still core UI requirements.

| ID | Area | Test action | Expected result | FR | Owner |
| --- | --- | --- | --- | --- | --- |
| T06 | Ownership | Read another user private report or evidence | 404 or 403 with no content disclosure | FR09 FR10 | M1 |
| T08 | URL semantics | Change path case or meaningful query value | Different URLs remain distinct | FR06 | M1 |
| T11 | Vote change | Change malicious vote to safe then withdraw | One vote then none; audit and score refresh agree | FR11 FR12 | M1 |
| T16 | Worker replay | Crash after Mongo write before acknowledgement | Replay is idempotent and marks correct version synced | FR34 | M1 |
| T17 | Stale worker | Deliver version 2 after version 3 or with expired lease | No older overwrite and no wrong acknowledgement | FR34 | M1 |
| T23 | Report cap | One account files several accepted reports on same URL | Only that reporter largest contribution counts | FR17 FR25 | M1 |
| T24 | Reputation bounds | Apply large positive or negative ledger sum | Derived reputation remains between 0 and 100 | FR25 | M1 |
| T26 | Derived invalidation | Suspend voter or change reviewed neighbor verdict | Dependent score queued and refreshed | FR17 FR32 | M1 |
| T27 | SQL query integrity | Run summary with three votes and two reports | Counts remain three and two, not six and six | FR27 | M1 |
| T29 | Embedding version | Query with a different model version | No mixed-version results | FR15 | M2 |
| T30 | Semantic relevance | Search paraphrases against labeled held-out messages | Record precision at k and failed matches honestly | FR15 FR16 | M2 |
| T31 | ANN recall | Compare HNSW and exact top 10 on identical filters | Report overlap and latency; handle too few matches | FR15 | M2 |
| T33 | Campaign links | Remove a SQL campaign membership | Mongo cache and related derived content converge | FR28 FR29 | M1 |
| T37 | Evidence upload | Upload oversized or disguised executable attachment | Rejected or quarantined; never publicly executable | FR09 | M1 |
| T38 | AI grounding | Evidence contains instructions and invented source requests | No tool use; output cites only authorized input IDs | FR19 | M2 |
| T39 | AI failure | Configured provider times out or returns invalid JSON | Visible failed/retry state; score unchanged | FR19 | M2 |
| T40 | Notification crossing | Calculate scores below, above, above, below, above threshold | Two notifications, with deduplication on retries | FR30 | M1 |
| T41 | Last admin | Concurrent attempts to remove final active admin | Invariant preserved under a locked transaction | FR32 | M1 |
| T42 | Discussion rules | Reply to locked thread or cross-thread parent | Rejected; own edits use version preconditions | FR20 FR21 | M2 |
| T43 | Accessibility | Complete form and voting flow with keyboard only | Labels, focus, errors, and risk text remain usable | FR26 | M2 |

Retain the original password-reset replay scenario within T04 when FR04 is enabled; extend T34 to comments and AI output when FR19/FR21 are enabled; extend T45 to private evidence backup and automatic reconciliation when those modules exist. These optional variants are also preserved in tests/test_plan.json.

Add tests to CI in layers: migration and seed, SQL constraints and transactions, API authorization, MongoDB projection, vector retrieval, and a small browser flow. Use reserved domains and invented messages. Record commit, date, dependency versions, hardware, actual output and screenshots for each executed case. A failed service produces an honest UI state.

## 23 Team Responsibilities

Both students contribute to database development, backend/application code, testing and documentation. The primary ownership remains Member 1 Database and Backend and Member 2 Frontend and Vector Search, with cross-review of every database boundary.

| Area | Member 1 Database and Backend | Member 2 Frontend and Vector Search |
|---|---|---|
| PostgreSQL | Schema, keys, constraints, auth tables, outbox, risk snapshots and audit | ER review, vector tables/indexes, retrieval SQL and analytics queries |
| MongoDB | Report projection, version checks and retry workflow | Validators, report read queries, three core aggregations and consistency checks |
| Backend | Authentication, local verification, roles, URLs, reports, votes and moderation | Semantic-search and analytics handlers, embedding jobs and API integration |
| Frontend | Moderation and admin screens, review of authorization flows | Home / Lookup, Dashboard, URL Detail, Report Scam, Analytics and shared components |
| Testing | SQL integrity, RBAC, transactions, risk arithmetic and failure recovery | MongoDB queries, vectors, browser flows and measured lookup/search performance |
| Documentation | Relational schema, workflow, security and SQL examples | Architecture diagrams, Mongo/vector design, frontend and result records |
| Shared | Restore rehearsal, code review, Git history, screenshots and viva | Restore rehearsal, code review, Git history, screenshots and viva |

### Six week priority plan

| Week | Priority work | Exit evidence |
|---|---|---|
| 1 | Project setup, GitHub, PostgreSQL schema, ER diagram and invented seed | Shared repository, reviewed ER/schema and executed migrations with recorded output |
| 2 | Authentication, local verification, RBAC, URL submission, normalization and deduplication | User/Moderator/Admin accounts; same canonical URL resolves once; auth checks |
| 3 | Reports, PostgreSQL outbox to MongoDB, retry and moderation | Shared report ID/version, pending/synced states and one outage/retry exercise |
| 4 | Voting, versioned risk and coverage, SQL full-text search, dashboards and advanced DB demonstrations | Duplicate-vote constraint, risk worked example, trigger/view/transaction evidence and aggregation output |
| 5 | pgvector, pinned embeddings, accepted-report semantic search and frontend polish | Authorized top-k results, small exact/HNSW comparison and all seven feature areas connected |
| 6 | Core acceptance tests, restore, screenshots, performance measurements, final documentation and viva | Actual test records, measured results, contributions and the 8–10 minute demo rehearsal |

Enhanced features begin only after this core is stable. Reuse the supplied database helpers rather than rewriting working logic for an optional milestone. If time shrinks, defer optional modules and broad evaluation studies first; retain all core database paradigms, security and required college demonstrations.

Each student commits their own implementation and tests, reviews the other's database work, and explains the complete report lifecycle and schema in viva. Keep setup, migrations, seed, commands, secret-free configuration and measured results in Git. Do not manufacture contribution history.

## 24 Conclusion and Future Enhancements

### Conclusion

CrowdShield addresses the delay and uncertainty between encountering a suspicious URL and finding useful evidence about it. Its core combines community reports and votes with independent moderation, recoverable document storage, and similarity retrieval. Users see the evidence supporting a risk assessment and whether enough evidence exists to interpret it.

PostgreSQL protects identities, relationships, vote uniqueness, report workflow and immutable risk history. MongoDB holds redacted report narratives under validation. A PostgreSQL outbox records report changes atomically, and the worker projects them to MongoDB using shared IDs, versions and retries. Accepted synchronized text becomes pgvector embeddings in PostgreSQL, with current SQL state controlling what search may return.

This design goes beyond CRUD through transactional consistency, audited triggers, derived views, indexed full-text and vector search, aggregation, temporal risk snapshots and a demonstrable failure-recovery workflow. The heuristic score remains separate from coverage and moderator_verdict; its components, algorithm version and timestamps make the result explainable. AI generation is an optional explanation layer and cannot change the score.

The architecture and starter artifacts are prepared, but the integrated application, database execution, deployment and acceptance evidence are still outstanding. Coordinated accounts, mistaken reviews, stale projections and English-focused semantic retrieval remain limitations. Similarity does not prove maliciousness, local demo verification does not prove mailbox ownership, and a URL without evidence cannot be certified safe. The two-member project is complete after the core is implemented, demonstrated and tested; optional features do not block that completion.

### Future Enhancements

- External threat-intelligence feeds with provenance, licensing and freshness controls.
- A browser extension that queries reviewed intelligence without exposing browsing history unnecessarily.
- Automated website analysis in a separately sandboxed, SSRF-aware fetching service.
- Multilingual embeddings, model migration and language-specific evaluation.
- Richer campaign detection, analyst-reviewed clusters and campaign timelines.
- Production email delivery and real mailbox ownership verification.
- Scalable private object storage and implemented upload scanning.
- Larger labeled datasets, held-out evaluation, calibrated thresholds and broader ANN comparisons.
- Discussions, notifications, CSV export, evidence-grounded AI explanations and advanced reconciliation after the core has passed its tests.

## Appendix A College Requirement Traceability

All core evidence below is planned until executed and recorded. Script examples for optional entities may be shown with clearly labeled invented seed data; this does not imply the associated application module is complete.

| College Requirement | Core Implementation | Enhanced |
| --- | --- | --- |
| Meaningful project beyond CRUD | Demonstrate vote integrity, versioned risk, semantic retrieval and outage recovery | Campaigns, AI and notifications |
| Two members and individual contributions | Section 23 ownership, reviews, real commits and viva by both | Optional modules retain shared review |
| SQL plus another database paradigm | PostgreSQL + MongoDB + pgvector; Sections 6–11 | External vector engine not required |
| ER diagram and relational schema | 17 core tables within the retained 22-table reference; keys, types and relationships in Sections 8–9 | Five optional-module tables remain designed |
| DDL and integrity constraints | Execute CREATE, safe ALTER/DROP, CHECK, UNIQUE and FK examples; Section 13 | Optional-module migrations |
| DML | Execute INSERT, UPDATE, DELETE and SELECT demonstrations; Section 14 | Optional-table examples retained |
| JOIN | Run J01–J05 and explain join cardinality | Additional report-specific queries |
| GROUP BY | Run G01–G05 and explain aggregation | Richer analytics |
| HAVING | Run H01–H05 and distinguish row and group filtering | Extra investigations |
| Subqueries | Run Q01–Q05; optional-module fixture queries may use documented seed data | Broader analyst queries |
| At least four advanced concepts | Seven mandatory concepts in Section 15 with executed output and plans | Separate stored-procedure walkthrough |
| NoSQL/vector model and retrieval | scam_reports validator, three aggregations, embeddings, current-state filters | Other four collections and campaign-growth pipeline |
| Next.js and backend integration | Seven feature areas plus auth screens connected to 31 core API routes | 37 preserved optional routes |
| Authentication and at least two roles | Local token flow plus User, Moderator and Admin checks | Production email and password reset |
| Validation and consistency | API schemas, SQL constraints, Mongo validators, idempotent versioned outbox | Automatic reconciliation dashboard |
| Security and environment variables | Section 21 controls; secret-free config and tested ownership/CSRF/XSS limits | Uploads, malware scanning and crawling controls |
| Screenshots | Capture real core screens and SQL/Mongo/vector outputs listed in Appendix B | Only completed optional modules |
| Testing and results | Execute 25 core acceptance cases; record results, restore and measurements | 20 retained extended/optional cases |
| Git/GitHub | Repository, setup, commits and reviews from both members | CI and deployment automation |
| Conclusion and future work | Section 24 explains contributions, status and limitations | Explicit future enhancements |
| Originality and working demo | Check topic uniqueness with college; run Appendix B demo and explain decisions | Optional showcase only if complete |

Check the title for uniqueness within the college section. A design cannot guarantee a grade; Level 3 evidence consists of the implemented database concepts, authentic results and explanations by both students.

## Appendix B Final Demonstration and Presentation

### Mandatory 8 to 10 minute demo

Use invented reserved-domain fixtures, prepared accounts and a preloaded pinned embedding model. Rehearse a local database stop/start and a short configured retry delay before presenting. These are demonstration instructions, not a claim of a completed demo.

| Time | Step | Evidence to show |
| --- | --- | --- |
| 0:00–0:30 | 1 Login | Use an already locally verified demo account; identify the three roles |
| 0:30–1:10 | 2 Submit URL; 3 normalize and deduplicate | Submit hostname/default-port variants and show the same url_id |
| 1:10–2:15 | 4 Submit report; 5 show SQL metadata; 6 outbox; 7 MongoDB | Show 202, report_refs, leased event and matching document ID/version |
| 2:15–3:10 | 8 Add votes; 9 prevent duplicates | Vote with prepared accounts; show one row per user/URL and current verdict |
| 3:10–4:00 | 10 Show risk and coverage | Explain score, coverage, label, components and algorithm_version |
| 4:00–4:50 | 11 Moderator review | Independent reviewer accepts evidence and sets a reasoned verdict; show refresh |
| 4:50–5:50 | 12 Semantic search | Use a paraphrased message; show accepted current evidence and similarity |
| 5:50–6:35 | 13 Show an advanced DB feature | Inspect vote trigger audit/outbox or a rollback; keep other required outputs ready |
| 6:35–8:05 | 14 MongoDB failure and retry | Stop MongoDB, submit, observe pending, restart and prove exactly one document |
| 8:05–9:00 | 15 Dashboard | Show contributions, trends, freshness and the recorded test evidence |

The timed storyline is approximately nine minutes. Keep SQL query output, all seven advanced-concept examples and restore/performance results ready for follow-up questions. Enhanced features appear only if complete and tested; omit them from the mandatory storyline otherwise.

Presentation outline: problem and objectives; core versus enhanced scope; architecture and database choices; ER and normalization; relational and document models; outbox and integrity; risk plus coverage; full-text and semantic search; core UI; actual tests and measurements; both members' contributions; Section 24 conclusion and future work.

### Screenshot and testing evidence still required

Capture registration/local verification without exposing the token; login and role protection; URL normalization/deduplication; report metadata, outbox and MongoDB document; duplicate-vote prevention and trigger audit; moderator decision; score, coverage and history; semantic retrieval with source/model versions; dashboard and analytics; retry after MongoDB outage; executed SQL queries and core test/restore output. Use captions identifying requirement, test data, commit and result. Record actual performance figures with hardware and dataset. Optional campaign, discussion, upload, notification and AI screenshots are required only if those features are claimed. Never include secrets, connection strings or private unredacted reports.

## Appendix C Viva Preparation

1. Why is this beyond CRUD? The system coordinates transactions, event delivery, temporal score history, moderation, similarity retrieval, and trend analysis. Explain a failure case and show recovery.
2. Why PostgreSQL? Relationships and invariants such as one vote per user and URL require keys, constraints, and transactions. Explain the query plans you measured.
3. Why MongoDB when PostgreSQL supports JSONB? Flexible evidence and thread documents are a deliberate modeling choice and a course demonstration. JSONB is a possible simpler alternative; explain the added synchronization cost honestly.
4. Is pgvector a separate server? No. It is a PostgreSQL extension providing vector storage and retrieval, so three paradigms run on two database engines.
5. What is normalized? Role and category names occur once, bridges resolve many-to-many relationships, and mutable totals are derived from source rows.
6. What is intentionally denormalized? Generated search fields, versioned risk snapshots, cached campaign memberships in MongoDB, and derived similarity edges. Each has an update or rebuild rule.
7. How do you stop duplicate votes? A composite primary key, an upsert for verdict changes, and server-side identity. Explain why a UI check alone is insufficient under concurrency.
8. Is one SQL transaction atomic with MongoDB? No. A transactional outbox, idempotent versioned writes and retries provide eventual consistency. Advanced automatic reconciliation is enhanced.
9. Why keep report_refs in SQL? Votes, workflow, scoring, and ownership need relational joins; report narratives remain in MongoDB under the same UUID.
10. What happens after a worker crash? Its lease expires; another worker replays the same event. Version checks prevent stale overwrites, and acknowledgement requires the current lease token.
11. What is a trigger doing? vote_audit inserts a corresponding audit record in the same SQL transaction. A failure rolls back both.
12. What is the difference between WHERE and HAVING? WHERE filters input rows before grouping; HAVING filters aggregate groups. Demonstrate accepted reports with at least two independent reporters.
13. Why aggregate before joining votes and reports? Joining both detail tables multiplies matching rows; pre-aggregation prevents inflated counts.
14. What is a vector embedding? A numeric representation used to compare text meaning. Dimension and model version must match between stored and query vectors.
15. Does high similarity mean phishing? No. Similarity retrieves candidates. Only documented evidence and review inform the risk design.
16. Why not score from other computed scores? That would create feedback loops. Similarity anchors use effective moderator verdicts instead.
17. Is the score a probability? No. It is a versioned heuristic; calibration would require a labeled data set and evaluation on unseen cases.
18. Can a zero-report URL be called safe? No. The model reports insufficient evidence, and the example baseline score has no safety guarantee.
19. If the enhanced AI module is built, how do you handle malicious text sent to the AI? Treat it as data, provide no action tools, redact it, validate output and source IDs, and keep the AI outside scoring authority.
20. What remains limited? Coordinated accounts, imperfect evidence, English-focused embeddings, stale projections, false positives, and no live website scan. Explain how each limit appears in the UI and test plan.


21. Why use PostgreSQL and MongoDB together? PostgreSQL protects accounts, votes and report workflow. MongoDB stores changing report narratives. We accept the synchronization work to demonstrate both relational and document modeling.
22. Why pgvector? It provides semantic retrieval beside the SQL identities and authorization data, without operating a separate vector server.
23. Why not use only PostgreSQL JSONB? That is a reasonable alternative, but this project deliberately demonstrates a document database and cross-store recovery. MongoDB is a design tradeoff, not a claim that JSONB cannot store reports.
24. Why is MongoDB eventually consistent with PostgreSQL? The SQL transaction commits first; a worker writes the document afterward. Pending/synced states expose that delay, and version checks prevent stale content becoming authoritative.
25. What is the transactional outbox? It is a SQL event row committed with the business change. The worker can retry delivery even if MongoDB was unavailable when the report was accepted.
26. Why is risk score not probability? Its weights and thresholds are transparent project choices. A score of 80 does not mean an 80 percent chance of phishing.
27. Why is coverage different from confidence? coverage summarizes the amount of eligible evidence and reviewed anchors. It is not statistical confidence; a reviewed verdict sets it to 1 as a review flag, not certainty.
28. Why does no evidence not mean safe? A new attack may have no reports. We return the baseline score 37.5 with coverage 0 and label insufficient_evidence.
29. What happens when MongoDB fails? SQL retains the report and outbox event. The worker schedules a retry; after MongoDB recovers, the same ID/version produces one document and SQL becomes synced.
30. Which features are core and which are enhanced? Auth, three roles, reports, outbox, votes, moderation, risk/coverage, SQL and vector search, basic analytics and testing are core. Discussions, AI, campaigns, uploads and notifications are enhanced.
31. Why does the reduced scope still go beyond CRUD? The core still demonstrates transactions, triggers, current-state views, indexed queries, MongoDB aggregation, vector search, versioned scoring and recovery.
32. Which database feature contributes most? The transactional outbox is central: it keeps an accepted SQL report recoverable when MongoDB fails. Vote uniqueness and the audit trigger provide a second clear integrity example.
33. What would you remove if time were reduced? Defer every enhanced module and broader benchmark first. Retain the core databases, integrity, security, accepted-report semantic search and required demonstration evidence.
34. How can verification be core while email delivery is enhanced? A restricted local flow delivers a single-use demo token. We test hash storage, expiry and atomic consumption, and label it demo verification. Real mailbox ownership needs the later email adapter.
35. Are all 22 tables and 68 APIs mandatory? The reference design is preserved, but only 17 tables support core behavior and 31 routes are in the core API. Optional tables may exist with no enabled UI.
36. Why are procedures additional if scripts call them? The helper code is already supplied and can be reused. The extra assessed concept is optional; report review and risk calculation still must work and be tested.

## Appendix D References

The college's supplied DBMS Level 3 Mini Project Requirements draft is the governing assessment brief. The following primary technical references were checked on 29 September 2026. Project weights, thresholds, time limits, ownership rules, and test targets are design choices rather than claims made by these sources.

1. PostgreSQL documentation, Constraints. https://www.postgresql.org/docs/current/ddl-constraints.html
2. PostgreSQL documentation, Transaction Isolation. https://www.postgresql.org/docs/current/transaction-iso.html
3. MongoDB documentation, Atomicity and Transactions. https://www.mongodb.com/docs/manual/core/write-operations-atomicity/
4. MongoDB documentation, Schema Validation. https://www.mongodb.com/docs/manual/core/schema-validation/
5. pgvector project documentation. https://github.com/pgvector/pgvector
6. Sentence Transformers model card, all-MiniLM-L6-v2. https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2
7. Next.js documentation, Route Handlers. https://nextjs.org/docs/app/api-reference/file-conventions/route
8. OWASP Password Storage Cheat Sheet. https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
9. OWASP Server Side Request Forgery Prevention Cheat Sheet. https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html
10. PostgreSQL documentation, Full Text Search. https://www.postgresql.org/docs/current/textsearch.html
