// Persistent, loopback-only demo using the database engines already in devDependencies.
import "dotenv/config";
import { PGlite } from "@electric-sql/pglite";
import { vector } from "@electric-sql/pglite-pgvector";
import { pgcrypto } from "@electric-sql/pglite/contrib/pgcrypto";
import { PGLiteSocketServer } from "@electric-sql/pglite-socket";
import { MongoMemoryServer } from "mongodb-memory-server";
import { spawn, type ChildProcess } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";
import pg from "pg";

const runtime = path.resolve(".test-runtime/local-demo");
await fs.mkdir(path.join(runtime, "mongo"), { recursive: true });
process.env.APP_MODE = "local-demo";
process.env.APP_ORIGIN = "http://localhost:3000";
process.env.DATABASE_URL = "postgresql://postgres@127.0.0.1:5433/postgres";
process.env.DATABASE_ADMIN_URL = process.env.DATABASE_URL;
process.env.PG_POOL_MAX = "1";
const children: ChildProcess[] = [];
const production = process.argv.includes("--production");
const db = await PGlite.create({ dataDir: path.join(runtime, "postgres"), extensions: { vector, pgcrypto } });
const socket = new PGLiteSocketServer({ db, host: "127.0.0.1", port: 5433, maxConnections: 10 });
await socket.start();
let mongo: MongoMemoryServer | undefined;
let stopping = false;
async function stop() {
  if (stopping) return;
  stopping = true;
  for (const child of children) child.kill("SIGTERM");
  const { closeDb } = await import("../lib/server/db");
  await closeDb();
  await mongo?.stop({ doCleanup: false });
  await socket.stop();
  await db.close();
}
for (const signal of ["SIGINT", "SIGTERM"] as const) process.on(signal, () => { void stop(); });
try {
  mongo = await MongoMemoryServer.create({
    binary: { version: "8.0.16" },
    instance: { ip: "127.0.0.1", port: 27018, dbPath: path.join(runtime, "mongo"), storageEngine: "wiredTiger" },
  });
  process.env.MONGODB_URI = mongo.getUri("crowdshield");
  const { setupSql, setupMongo } = await import("./setup");
  const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();
  try { await setupSql(client); } finally { await client.end(); }
  await setupMongo(process.env.MONGODB_URI);
  const { seed } = await import("./seed");
  await seed();
  for (const args of [
    ["node_modules/next/dist/bin/next", production ? "start" : "dev", "--hostname", "127.0.0.1", "--port", "3000"],
    ["--import", "tsx", "workers/index.ts"],
  ]) {
    const child = spawn(process.execPath, args, { stdio: "inherit", env: { ...process.env, NEXT_TELEMETRY_DISABLED: "1" } });
    children.push(child);
    child.on("exit", () => { if (!stopping) void stop(); });
  }
  console.log("CrowdShield local demo: http://localhost:3000 — data persists in .test-runtime/local-demo.");
} catch (error) {
  console.error(error);
  await stop();
  process.exitCode = 1;
}
