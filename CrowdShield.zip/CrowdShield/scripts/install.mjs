// Cross-platform, reproducible CPU-only dependency installation.
import { spawnSync } from "node:child_process";
const command = process.platform === "win32" ? "npm.cmd" : "npm";
const result = spawnSync(command, ["ci", "--prefer-offline", "--no-audit", "--no-fund"], {
  stdio: "inherit",
  shell: process.platform === "win32",
  env: {
    ...process.env,
    ONNXRUNTIME_NODE_INSTALL_CUDA: "skip",
    MONGOMS_DISABLE_POSTINSTALL: "1",
  },
});
process.exit(result.status ?? 1);
