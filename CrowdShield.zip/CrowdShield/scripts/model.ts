import "dotenv/config";
import { embedChunks } from "../lib/server/embedding";
const result = await embedChunks(
  "Parcel redelivery fee requested through an unfamiliar payment link.",
);
console.log(
  `Model ready: ${result[0].vector.length} real dimensions; ${result.length} chunk.`,
);
