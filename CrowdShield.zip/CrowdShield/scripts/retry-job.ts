import "dotenv/config";
import { tx, closeDb } from "../lib/server/db";
import { uuid } from "../lib/server/validation";
import { config } from "../lib/server/config";
try {
  if (!config.localDemo) throw new Error("Operator retry is local-demo only");
  const id = uuid.parse(process.argv[2]);
  await tx(async (db) => {
    const { rows } = await db.query(
      `UPDATE outbox_events SET status='pending',attempts=0,available_at=now(),locked_at=NULL,lease_token=NULL,last_error=NULL WHERE event_id=$1 AND status='failed' RETURNING *`,
      [id],
    );
    if (!rows.length)
      throw new Error(
        "No parked job found. Only failed jobs can be manually requeued.",
      );
    if (rows[0].event_type.startsWith("report."))
      await db.query(
        `UPDATE report_refs SET sync_status='pending' WHERE report_id=$1 AND content_version=$2`,
        [rows[0].aggregate_id, rows[0].aggregate_version],
      );
    await db.query(
      `INSERT INTO audit_logs(action,entity_type,entity_id,details) VALUES('operator.retry','outbox',$1,'{"source":"local CLI"}')`,
      [id],
    );
  });
  console.log("Job returned to the queue. Start the worker to retry.");
} finally {
  await closeDb();
}
