import "dotenv/config";
import { query, tx, closeDb } from "../lib/server/db";
import { verificationToken, deliverVerification } from "../lib/server/auth";
import { config } from "../lib/server/config";
const email = process.argv[2]?.trim().toLowerCase();
try {
  if (!config.localDemo) throw new Error("Available only in local-demo mode");
  if (!email)
    throw new Error("Usage: npm run account:verify -- user@example.test");
  const [u] = await query(
    "SELECT user_id FROM users WHERE email=$1 AND status='active'",
    [email],
  );
  if (!u) throw new Error("Active demo account not found");
  const token = await tx((db) => verificationToken(db, u.user_id));
  await deliverVerification(u.user_id, token);
  console.log(
    `Local operator verification token (30 minutes, single use):\n${token}\nPaste on ${config.origin}/verify. This activates the demo account; it does not prove mailbox ownership.`,
  );
} finally {
  await closeDb();
}
