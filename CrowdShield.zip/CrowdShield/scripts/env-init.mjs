import { randomBytes } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
const secret = () => randomBytes(24).toString("hex");
const pg = secret(),
  app = secret(),
  mr = secret(),
  ma = secret();
let text = await readFile(".env.example", "utf8");
const values = {
  POSTGRES_PASSWORD: pg,
  POSTGRES_APP_PASSWORD: app,
  DATABASE_ADMIN_URL: `postgresql://crowdshield_owner:${pg}@127.0.0.1:5432/crowdshield`,
  DATABASE_URL: `postgresql://crowdshield_app:${app}@127.0.0.1:5432/crowdshield`,
  MONGO_ROOT_PASSWORD: mr,
  MONGO_APP_PASSWORD: ma,
  MONGODB_URI: `mongodb://crowdshield_app:${ma}@127.0.0.1:27017/crowdshield?authSource=crowdshield`,
  SEED_USER_PASSWORD: secret(),
  SEED_MODERATOR_PASSWORD: secret(),
  SEED_ADMIN_PASSWORD: secret(),
};
for (const [k, v] of Object.entries(values))
  text = text.replace(new RegExp(`^${k}=.*$`, "m"), `${k}=${v}`);
try {
  await writeFile(".env", text, { flag: "wx", mode: 0o600 });
  console.log(
    "Created private .env. Read its SEED_*_PASSWORD values locally to sign in.",
  );
} catch (e) {
  if (e.code === "EEXIST") console.log(".env already exists; preserved.");
  else throw e;
}
