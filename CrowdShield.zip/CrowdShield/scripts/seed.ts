import "dotenv/config";
import { query, tx, closeDb } from "../lib/server/db";
import { passwordHash, type Actor } from "../lib/server/auth";
import { normalizeUrl, sha } from "../lib/server/validation";
import {
  reviewReport,
  setVerdict,
  lockDomain,
  refreshRisk,
} from "../lib/server/domain";
import { runOnce } from "../workers/processor";
const uid = (n: number) =>
  `00000000-0000-4000-8000-${String(n).padStart(12, "0")}`;
export async function seed() {
  const passwords = [
    process.env.SEED_USER_PASSWORD,
    process.env.SEED_MODERATOR_PASSWORD,
    process.env.SEED_ADMIN_PASSWORD,
  ];
  if (
    passwords.some(
      (p) => !p || p.length < 12 || p.length > 72 || p.startsWith("REPLACE_"),
    )
  )
    throw new Error(
      "Set private 12–72 character SEED_*_PASSWORD values in .env before seeding.",
    );
  const hashes = await Promise.all(passwords.map((p) => passwordHash(p!)));
  await tx(async (db) => {
    await lockDomain(db);
    const names = ["Alice", "Bob", "Carol", "Reviewer", "Administrator"],
      emails = [
        "alice@example.test",
        "bob@example.test",
        "carol@example.test",
        "mod@example.test",
        "admin@example.test",
      ];
    for (let i = 0; i < 5; i++) {
      await db.query(
        `INSERT INTO users(user_id,email,display_name,password_hash,email_verified_at) VALUES($1,$2,$3,$4,now()) ON CONFLICT(user_id) DO NOTHING`,
        [
          uid(i + 1),
          emails[i],
          names[i],
          hashes[i === 3 ? 1 : i === 4 ? 2 : 0],
        ],
      );
      await db.query(
        `INSERT INTO user_roles(user_id,role_id) SELECT $1,role_id FROM roles WHERE name='user' ON CONFLICT DO NOTHING`,
        [uid(i + 1)],
      );
    }
    for (const [n, role] of [
      [4, "moderator"],
      [5, "admin"],
    ] as const)
      await db.query(
        `INSERT INTO user_roles(user_id,role_id) SELECT $1,role_id FROM roles WHERE name=$2 ON CONFLICT DO NOTHING`,
        [uid(n), role],
      );
    await db.query(
      `INSERT INTO url_categories(name,description) VALUES('Parcel scam','Delivery fee impersonation'),('Credential phishing','Requests for account credentials'),('Financial scam','Misleading payments') ON CONFLICT(name) DO NOTHING`,
    );
    const urls = [
      "https://parcel-check.example/verify",
      "https://parcel-check.example/pay",
      "https://college.example/help",
      "https://new-site.example/",
    ];
    for (let i = 0; i < 4; i++) {
      const u = normalizeUrl(urls[i]);
      await db.query(
        `INSERT INTO urls(url_id,canonical_url,hostname,display_url,submitted_by) VALUES($1,$2,$3,$4,$5) ON CONFLICT(url_id) DO NOTHING`,
        [
          uid(101 + i),
          u.canonical_url,
          u.hostname,
          u.display_url,
          uid((i % 3) + 1),
        ],
      );
    }
    for (const [user, url, verdict] of [
      [1, 101, 1],
      [2, 101, 1],
      [3, 101, -1],
      [1, 102, 1],
    ])
      await db.query(
        `INSERT INTO votes(user_id,url_id,verdict) VALUES($1,$2,$3) ON CONFLICT DO NOTHING`,
        [uid(user), uid(url), verdict],
      );
    const messages = [
      "An invented parcel delivery text demands a small redelivery fee. The unfamiliar verification page asks for card details and creates a false sense of urgency.",
      "This invented delivery notification says a parcel is on hold and asks for card payment to arrange redelivery. The domain does not match the claimed courier.",
      "A fictional parcel redelivery payment page requests a card number for a small handling fee. The message threatens to return the package unless payment is immediate.",
    ];
    for (let i = 0; i < 3; i++) {
      const id = uid(201 + i),
        url = uid(i < 2 ? 101 : 102),
        user = uid(i + 1);
      const { rows } = await db.query(
        `INSERT INTO report_refs(report_id,url_id,reporter_id,report_type,idempotency_key,request_hash) VALUES($1,$2,$3,'scam_message',$4,$5) ON CONFLICT(report_id) DO NOTHING RETURNING created_at`,
        [id, url, user, uid(901 + i), sha(messages[i])],
      );
      if (rows.length)
        await db.query(
          `INSERT INTO outbox_events(event_type,aggregate_id,aggregate_version,payload) VALUES('report.created',$1,1,$2)`,
          [
            id,
            JSON.stringify({
              _id: id,
              url_id: url,
              reporter_id: user,
              report_type: "scam_message",
              workflow_status: "pending",
              content_version: 1,
              message_text: messages[i],
              narrative: messages[i],
              channel: "sms",
              created_at: rows[0].created_at,
              updated_at: rows[0].created_at,
            }),
          ],
        );
    }
    await refreshRisk(db, [101, 102, 103, 104].map(uid));
  });
  await runOnce(100);
  const moderator: Actor = {
    user_id: uid(4),
    email: "mod@example.test",
    display_name: "Reviewer",
    email_verified_at: new Date().toISOString(),
    roles: ["user", "moderator"],
  };
  for (const n of [201, 202]) {
    const [r] = await query("SELECT * FROM report_refs WHERE report_id=$1", [
      uid(n),
    ]);
    if (r.workflow_status === "pending" && r.sync_status === "synced")
      await reviewReport(
        uid(n),
        true,
        "Reviewed invented parcel impersonation evidence for the classroom dataset.",
        moderator,
      );
  }
  const [existing] = await query(
    `SELECT action_id FROM moderator_actions WHERE url_id=$1`,
    [uid(102)],
  );
  if (!existing) {
    await setVerdict(
      uid(102),
      "malicious",
      "Reviewed invented parcel impersonation evidence.",
      30,
      moderator,
    );
    await setVerdict(
      uid(103),
      "safe",
      "Reviewed invented college information ownership evidence.",
      30,
      moderator,
    );
  }
  await runOnce(100);
  const [state] = await query(
    `SELECT count(*) FILTER(WHERE sync_status<>'synced')::int pending FROM report_refs WHERE report_id=ANY($1::uuid[])`,
    [[201, 202, 203].map(uid)],
  );
  console.log(
    `Seed completed. Invented .example URLs only. Unsynchronized demo reports: ${state.pending}.`,
  );
  console.log(
    "Accounts: alice@example.test, mod@example.test, admin@example.test. Passwords are the private SEED_* values in your .env.",
  );
}
if (process.argv[1]?.endsWith("seed.ts"))
  try {
    await seed();
  } finally {
    await closeDb();
  }
