import "dotenv/config";
import fs from "node:fs/promises";
import pg from "pg";
const client = new pg.Client({
  connectionString: process.env.DATABASE_ADMIN_URL || process.env.DATABASE_URL,
});
await client.connect();
const query = async (sql: string) => (await client.query(sql)).rows;
try {
  const before = await query("SELECT count(*)::int n FROM urls");
  await query(`BEGIN;
 CREATE TABLE crowdshield_ddl_demo(id integer PRIMARY KEY,label text NOT NULL);
 ALTER TABLE crowdshield_ddl_demo ADD COLUMN created_at timestamptz NOT NULL DEFAULT now();
 ALTER TABLE crowdshield_ddl_demo ADD CONSTRAINT label_present CHECK(length(trim(label))>0);
 INSERT INTO crowdshield_ddl_demo(id,label) VALUES(1,'temporary fixture');
 UPDATE crowdshield_ddl_demo SET label='updated fixture' WHERE id=1;
 SELECT * FROM crowdshield_ddl_demo;
 DELETE FROM crowdshield_ddl_demo WHERE id=1;
 DROP TABLE crowdshield_ddl_demo;
 ROLLBACK;`);
  await query(await fs.readFile("database/04_queries.sql", "utf8"));
  const joins = await query(
    `SELECT u.display_name,count(r.report_id)::int reports FROM users u LEFT JOIN report_refs r ON r.reporter_id=u.user_id GROUP BY u.user_id HAVING count(r.report_id)>0 ORDER BY reports DESC`,
  );
  const aggregates = await query(
    `SELECT label,count(*)::int urls,round(avg(score),2) average_score FROM v_current_risk GROUP BY label ORDER BY label`,
  );
  const subquery = await query(
    `SELECT display_url FROM urls WHERE url_id IN(SELECT url_id FROM votes GROUP BY url_id HAVING count(*)>=2)`,
  );
  console.table(joins);
  console.table(aggregates);
  console.table(subquery);
  const after = await query("SELECT count(*)::int n FROM urls");
  if (before[0].n !== after[0].n)
    throw new Error("Demonstration altered application URL history");
  console.log(
    "Executed CREATE/ALTER/DROP and INSERT/UPDATE/DELETE/SELECT inside a rolled-back fixture. All 35 reference queries executed. Application URL history preserved.",
  );
} finally {
  await client.end();
}
