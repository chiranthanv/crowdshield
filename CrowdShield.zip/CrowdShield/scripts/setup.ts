import "dotenv/config";
import fs from "node:fs/promises";
import vm from "node:vm";
import pg from "pg";
import { MongoClient } from "mongodb";
export async function setupMongo(uri: string) {
  const c = new MongoClient(uri, { serverSelectionTimeoutMS: 5000 });
  await c.connect();
  const db = c.db(process.env.MONGODB_DATABASE || "crowdshield");
  // Execute the original validator/index definitions through the Node driver.
  const work: { kind: string; args: any[] }[] = [];
  const proxy = new Proxy(
    {},
    {
      get: (_, key) =>
        key === "createCollection"
          ? (...args: any[]) => {
              work.push({ kind: "collection", args });
            }
          : {
              createIndex: (...args: any[]) => {
                work.push({ kind: "index", args: [key, ...args] });
              },
            },
    },
  );
  vm.runInNewContext(await fs.readFile("mongodb/01_collections.js", "utf8"), {
    db: proxy,
  });
  for (const job of work) {
    if (job.kind === "collection") {
      const [name, opts] = job.args;
      if ((await db.listCollections({ name }).toArray()).length)
        await db.command({ collMod: name, ...opts });
      else await db.createCollection(name, opts);
    } else {
      const [name, keys, opts] = job.args;
      await db.collection(name).createIndex(keys, opts);
    }
  }
  await c.close();
  console.log("MongoDB validators and indexes ready.");
}
export async function setupSql(client: pg.Client | any) {
  const existing = await client.query(
    `SELECT to_regclass('public.users') name`,
  );
  if (!existing.rows[0].name) {
    for (const file of ["database/01_schema.sql", "database/02_features.sql"])
      await client.query(await fs.readFile(file, "utf8"));
    console.log("Original PostgreSQL schema and features applied.");
  } else {
    const fields = await client.query(
      `SELECT column_name FROM information_schema.columns WHERE table_name='risk_scores' AND column_name='coverage'`,
    );
    if (!fields.rows.length)
      throw new Error(
        "Apply database/07_coverage_migration.sql to the previous schema first.",
      );
    console.log("Existing schema preserved.");
  }
  await client.query(
    `INSERT INTO roles(name,description) VALUES('user','Community participant'),('moderator','Evidence reviewer'),('admin','Account administrator') ON CONFLICT(name) DO NOTHING`,
  );
}
export async function setupAppRole(c: pg.Client, password: string) {
  const { rows } = await c.query(
    `SELECT format('CREATE ROLE crowdshield_app LOGIN PASSWORD %L',$1::text) command`,
    [password],
  );
  if (
    !(await c.query(`SELECT 1 FROM pg_roles WHERE rolname='crowdshield_app'`))
      .rows.length
  )
    await c.query(rows[0].command);
  await c.query(`GRANT USAGE ON SCHEMA public TO crowdshield_app; GRANT SELECT ON ALL TABLES IN SCHEMA public TO crowdshield_app; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO crowdshield_app;
   GRANT INSERT,UPDATE ON users,urls,refresh_sessions,auth_tokens,report_refs,outbox_events,alerts TO crowdshield_app;
   GRANT INSERT,UPDATE,DELETE ON votes,user_roles,embeddings,similarity_edges TO crowdshield_app;
   GRANT INSERT ON url_categories TO crowdshield_app;
   GRANT INSERT ON audit_logs,risk_scores,reputation_events,moderator_actions,notifications TO crowdshield_app;
   REVOKE CREATE ON SCHEMA public FROM PUBLIC;
   REVOKE EXECUTE ON PROCEDURE recalculate_risk(uuid),moderate_report(uuid,uuid,boolean,text) FROM PUBLIC;
   GRANT EXECUTE ON PROCEDURE recalculate_risk(uuid),moderate_report(uuid,uuid,boolean,text) TO crowdshield_app;`);
}
async function main() {
  const c = new pg.Client({
    connectionString:
      process.env.DATABASE_ADMIN_URL || process.env.DATABASE_URL,
  });
  await c.connect();
  try {
    await setupSql(c);
    if (process.env.POSTGRES_APP_PASSWORD)
      await setupAppRole(c, process.env.POSTGRES_APP_PASSWORD);
  } finally {
    await c.end();
  }
  await setupMongo(process.env.MONGODB_URI || "");
}
if (process.argv[1]?.endsWith("setup.ts")) await main();
