// Core demonstration: A01-A03. Enhanced reference: A04 campaign growth.
// Read-only mongosh examples. Counts reflect Mongo's projected state;
// reconcile permissions and current report state with SQL before public display.
const since7 = new Date(Date.now()-7*86400000);
const since14 = new Date(Date.now()-14*86400000);

// A01 Top reported URLs: rank by distinct reporters, then raw report count.
printjson(db.scam_reports.aggregate([
 {$match:{workflow_status:'accepted'}},
 {$group:{_id:'$url_id',report_count:{$sum:1},reporters:{$addToSet:'$reporter_id'}}},
 {$project:{_id:1,report_count:1,unique_reporters:{$size:'$reporters'}}},
 {$sort:{unique_reporters:-1,report_count:-1,_id:1}},{$limit:10}
]).toArray());

// A02 Daily accepted phishing reports in UTC buckets.
printjson(db.scam_reports.aggregate([
 {$match:{workflow_status:'accepted',report_type:'phishing',created_at:{$gte:since14}}},
 {$group:{_id:{$dateTrunc:{date:'$created_at',unit:'day',timezone:'UTC'}},count:{$sum:1}}},
 {$sort:{_id:1}}
]).toArray());
// Days with zero reports are filled by the API calendar series, not fabricated.

// A03 Most active users, measured as accepted reports in the last seven days.
printjson(db.scam_reports.aggregate([
 {$match:{workflow_status:'accepted',created_at:{$gte:since7}}},
 {$group:{_id:'$reporter_id',accepted_reports:{$sum:1},urls:{$addToSet:'$url_id'}}},
 {$project:{accepted_reports:1,distinct_urls:{$size:'$urls'}}},
 {$sort:{accepted_reports:-1,_id:1}},{$limit:10}
]).toArray());
// Resolve public display names through the backend; never publish account email.

// A04 Trending campaigns: compare equal seven-day windows.
printjson(db.scam_reports.aggregate([
 {$match:{workflow_status:'accepted',created_at:{$gte:since14}}},
 {$unwind:'$campaign_ids'},
 {$group:{_id:{campaign:'$campaign_ids',report:'$_id'},
   reporter:{$first:'$reporter_id'},created_at:{$first:'$created_at'}}},
 {$group:{_id:'$_id.campaign',
   recent:{$sum:{$cond:[{$gte:['$created_at',since7]},1,0]}},
   previous:{$sum:{$cond:[{$lt:['$created_at',since7]},1,0]}}}},
 {$match:{recent:{$gte:2}}},
 {$set:{growth:{$divide:[{$subtract:['$recent','$previous']},{$max:['$previous',1]}]}}},
 {$sort:{growth:-1,recent:-1,_id:1}},{$limit:10}
]).toArray());
// campaign_ids is a cached SQL-membership projection. A report in two campaigns
// counts in each campaign; the sum across campaigns is not a global report count.
