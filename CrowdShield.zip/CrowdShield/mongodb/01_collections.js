// Core: scam_reports. Other four collections are enhanced reference models.
// mongosh "$MONGODB_URI" --file mongodb/01_collections.js
// URI must select the crowdshield database. Run once in an empty database.
const uuid = {bsonType:'string',pattern:'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'};
const text = n => ({bsonType:'string',maxLength:n});
const version = {bsonType:'int',minimum:1};
function collection(name,required,properties) {
  db.createCollection(name, {validator:{$jsonSchema:{bsonType:'object',required,properties}},
    validationLevel:'strict',validationAction:'error'});
}
collection('scam_reports',
 ['_id','url_id','reporter_id','report_type','workflow_status','content_version','message_text','created_at'],
 {_id:uuid,url_id:uuid,reporter_id:uuid,
  report_type:{enum:['phishing','scam_message','other']},
  workflow_status:{enum:['pending','accepted','rejected','withdrawn']},
  content_version:version,message_text:text(12000),narrative:text(12000),
  channel:{enum:['sms','email','social','website','other']},
  language:text(20),claimed_brand:text(100),
  campaign_ids:{bsonType:'array',maxItems:20,uniqueItems:true,items:uuid},
  redactions:{bsonType:'array',items:text(80)},
  created_at:{bsonType:'date'},updated_at:{bsonType:'date'}});
collection('discussions',['_id','url_id','author_id','title','body','status','content_version','created_at'],
 {_id:uuid,url_id:uuid,author_id:uuid,title:text(160),body:text(12000),content_version:version,
  status:{enum:['open','locked','hidden']},created_at:{bsonType:'date'},updated_at:{bsonType:'date'}});
collection('comments',['_id','discussion_id','author_id','body','status','content_version','created_at'],
 {_id:uuid,discussion_id:uuid,author_id:uuid,parent_comment_id:{anyOf:[uuid,{bsonType:'null'}]},
  body:text(4000),content_version:version,status:{enum:['visible','hidden','deleted']},
  created_at:{bsonType:'date'},edited_at:{bsonType:'date'}});
collection('evidence_files',['_id','report_id','owner_id','object_key','mime_type','size_bytes','sha256','scan_status','created_at'],
 {_id:uuid,report_id:uuid,owner_id:uuid,object_key:text(300),
  mime_type:{enum:['image/png','image/jpeg','application/pdf','text/plain']},
  size_bytes:{bsonType:['int','long'],minimum:1,maximum:5242880},
  sha256:{bsonType:'string',pattern:'^[0-9a-f]{64}$'},
  scan_status:{enum:['quarantined','clean','rejected']},
  caption:text(500),created_at:{bsonType:'date'},deleted_at:{bsonType:'date'}});
collection('phishing_campaigns',['_id','description','content_version','updated_by','updated_at'],
 {_id:uuid,description:text(16000),content_version:version,updated_by:uuid,
  indicators:{bsonType:'array',maxItems:100,items:{bsonType:'object',
   required:['type','value'],properties:{type:text(40),value:text(300)}}},
  analyst_notes:{bsonType:'array',maxItems:50,items:text(1000)},
  updated_at:{bsonType:'date'}});

db.scam_reports.createIndex({url_id:1,workflow_status:1,created_at:-1});
db.scam_reports.createIndex({reporter_id:1,created_at:-1});
db.scam_reports.createIndex({workflow_status:1,created_at:-1});
db.scam_reports.createIndex({campaign_ids:1,created_at:-1});
db.discussions.createIndex({url_id:1,status:1,created_at:-1});
db.comments.createIndex({discussion_id:1,status:1,created_at:1,_id:1});
db.evidence_files.createIndex({report_id:1,created_at:-1});
db.evidence_files.createIndex({object_key:1},{unique:true});
// _id is already uniquely indexed for every collection.
