// Full-reference invented fixtures, including optional modules.
// Invented fixtures aligned with database/03_seed.sql.
// Run only in the project demonstration database.
{
 const d = EJSON.parse("{\"_id\": \"00000000-0000-4000-8000-000000000201\", \"url_id\": \"00000000-0000-4000-8000-000000000101\", \"reporter_id\": \"00000000-0000-4000-8000-000000000001\", \"report_type\": \"scam_message\", \"workflow_status\": \"accepted\", \"content_version\": 1, \"message_text\": \"Your parcel is on hold. Pay a small redelivery fee at the linked page.\", \"narrative\": \"The message claims to be a delivery service and requests payment. Personal contact details were removed.\", \"channel\": \"sms\", \"language\": \"en\", \"claimed_brand\": \"Example Parcel Service\", \"campaign_ids\": [\"00000000-0000-4000-8000-000000000301\"], \"redactions\": [\"phone_number\"], \"created_at\": {\"$date\": \"2026-09-29T05:30:00Z\"}, \"updated_at\": {\"$date\": \"2026-09-29T05:30:00Z\"}}");
 d.content_version=NumberInt(d.content_version);
 db.scam_reports.replaceOne({_id:d._id},d,{upsert:true});
}
{
 const d = EJSON.parse("{\"_id\": \"00000000-0000-4000-8000-000000000202\", \"url_id\": \"00000000-0000-4000-8000-000000000101\", \"reporter_id\": \"00000000-0000-4000-8000-000000000002\", \"report_type\": \"phishing\", \"workflow_status\": \"accepted\", \"content_version\": 1, \"message_text\": \"Your parcel is on hold. Pay a small redelivery fee at the linked page.\", \"narrative\": \"The message claims to be a delivery service and requests payment. Personal contact details were removed.\", \"channel\": \"website\", \"language\": \"en\", \"claimed_brand\": \"Example Parcel Service\", \"campaign_ids\": [\"00000000-0000-4000-8000-000000000301\"], \"redactions\": [\"phone_number\"], \"created_at\": {\"$date\": \"2026-09-29T05:30:00Z\"}, \"updated_at\": {\"$date\": \"2026-09-29T05:30:00Z\"}}");
 d.content_version=NumberInt(d.content_version);
 db.scam_reports.replaceOne({_id:d._id},d,{upsert:true});
}
{
 const d = EJSON.parse("{\"_id\": \"00000000-0000-4000-8000-000000000203\", \"url_id\": \"00000000-0000-4000-8000-000000000102\", \"reporter_id\": \"00000000-0000-4000-8000-000000000003\", \"report_type\": \"scam_message\", \"workflow_status\": \"pending\", \"content_version\": 1, \"message_text\": \"Your parcel is on hold. Pay a small redelivery fee at the linked page.\", \"narrative\": \"The message claims to be a delivery service and requests payment. Personal contact details were removed.\", \"channel\": \"sms\", \"language\": \"en\", \"claimed_brand\": \"Example Parcel Service\", \"campaign_ids\": [\"00000000-0000-4000-8000-000000000301\"], \"redactions\": [\"phone_number\"], \"created_at\": {\"$date\": \"2026-09-29T05:30:00Z\"}, \"updated_at\": {\"$date\": \"2026-09-29T05:30:00Z\"}}");
 d.content_version=NumberInt(d.content_version);
 db.scam_reports.replaceOne({_id:d._id},d,{upsert:true});
}
{
 const d = EJSON.parse("{\"_id\": \"00000000-0000-4000-8000-000000000401\", \"url_id\": \"00000000-0000-4000-8000-000000000101\", \"author_id\": \"00000000-0000-4000-8000-000000000002\", \"title\": \"Similar parcel fee messages\", \"body\": \"Has anyone received the same wording? Please remove personal details.\", \"status\": \"open\", \"created_at\": {\"$date\": \"2026-09-29T05:30:00Z\"}, \"updated_at\": {\"$date\": \"2026-09-29T05:30:00Z\"}, \"content_version\": 1}");
 d.content_version=NumberInt(d.content_version);
 db.discussions.replaceOne({_id:d._id},d,{upsert:true});
}
{
 const d = EJSON.parse("{\"_id\": \"00000000-0000-4000-8000-000000000501\", \"discussion_id\": \"00000000-0000-4000-8000-000000000401\", \"author_id\": \"00000000-0000-4000-8000-000000000003\", \"parent_comment_id\": null, \"body\": \"I saw a similar message; the attached URL used a different path.\", \"status\": \"visible\", \"created_at\": {\"$date\": \"2026-09-29T05:30:00Z\"}, \"content_version\": 1}");
 d.content_version=NumberInt(d.content_version);
 db.comments.replaceOne({_id:d._id},d,{upsert:true});
}
{
 const d = EJSON.parse("{\"_id\": \"00000000-0000-4000-8000-000000000601\", \"report_id\": \"00000000-0000-4000-8000-000000000201\", \"owner_id\": \"00000000-0000-4000-8000-000000000001\", \"object_key\": \"evidence/00000000-0000-4000-8000-000000000601.png\", \"mime_type\": \"image/png\", \"size_bytes\": 248120, \"sha256\": \"0000000000000000000000000000000000000000000000000000000000000000\", \"scan_status\": \"quarantined\", \"caption\": \"Invented evidence metadata only; no image file is supplied.\", \"created_at\": {\"$date\": \"2026-09-29T05:30:00Z\"}}");
 db.evidence_files.replaceOne({_id:d._id},d,{upsert:true});
}
{
 const d = EJSON.parse("{\"_id\": \"00000000-0000-4000-8000-000000000301\", \"description\": \"Invented parcel redelivery messages with a repeated payment request.\", \"content_version\": 1, \"updated_by\": \"00000000-0000-4000-8000-000000000004\", \"indicators\": [{\"type\": \"message_theme\", \"value\": \"parcel redelivery fee\"}, {\"type\": \"hostname\", \"value\": \"parcel-check.example\"}], \"analyst_notes\": [\"Campaign links must be reviewed against evidence.\"], \"updated_at\": {\"$date\": \"2026-09-29T05:30:00Z\"}}");
 d.content_version=NumberInt(d.content_version);
 db.phishing_campaigns.replaceOne({_id:d._id},d,{upsert:true});
}
