// Docker initialization only. Password comes from the private environment.
const projectDb=db.getSiblingDB('crowdshield');
projectDb.createUser({user:'crowdshield_app',pwd:process.env.MONGO_APP_PASSWORD,roles:[{role:'readWrite',db:'crowdshield'}]});
