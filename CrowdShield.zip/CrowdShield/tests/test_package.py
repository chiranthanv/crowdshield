"""Static package checks only: not a PostgreSQL/MongoDB parser or integration test."""
from pathlib import Path
import json,re,unittest
ROOT=Path(__file__).resolve().parents[1]

class PackageTests(unittest.TestCase):
    def test_schema_table_count(self):
        names=re.findall(r'CREATE TABLE (\w+)',(ROOT/'database/01_schema.sql').read_text())
        self.assertEqual(len(names),22)
        self.assertEqual(len(set(names)),22)
    def test_referenced_tables_exist(self):
        sql=(ROOT/'database/01_schema.sql').read_text()
        names=set(re.findall(r'CREATE TABLE (\w+)',sql))
        self.assertTrue(set(re.findall(r'REFERENCES (\w+)',sql)) <= names)
    def test_er_includes_every_table(self):
        sql=(ROOT/'database/01_schema.sql').read_text()
        er=(ROOT/'diagrams/er.mmd').read_text()
        for name in re.findall(r'CREATE TABLE (\w+)',sql):
            self.assertIn('  '+name+' {',er)
    def test_query_counts(self):
        sql=(ROOT/'database/04_queries.sql').read_text()
        for prefix,count in [('S',15),('J',5),('G',5),('H',5),('Q',5)]:
            self.assertEqual(len(re.findall(r'^-- '+prefix+r'\d{2}:',sql,re.M)),count)
    def test_api_unique(self):
        api=json.loads((ROOT/'api_endpoints.json').read_text())
        self.assertEqual(len(api),68)
        self.assertEqual(len({(x['method'],x['route']) for x in api}),68)
    def test_planned_tests(self):
        cases=json.loads((ROOT/'tests/test_plan.json').read_text())
        self.assertEqual(len(cases),45)
        self.assertEqual(len({x['id'] for x in cases}),45)
    def test_document_sections(self):
        text=(ROOT/'CrowdShield_Complete_Design.md').read_text()
        self.assertEqual(re.findall(r'^## (\d+) ',text,re.M),[str(i) for i in range(1,25)])
        self.assertNotIn('{{',text)
    def test_mongo_models(self):
        docs=json.loads((ROOT/'mongodb/sample_documents.json').read_text())
        self.assertEqual(set(docs),{'scam_reports','discussions','comments','evidence_files','phishing_campaigns'})
        for name in ['scam_reports','discussions','comments','phishing_campaigns']:
            self.assertIsInstance(docs[name]['content_version'],int)
        self.assertEqual(docs['comments']['discussion_id'],docs['discussions']['_id'])
        self.assertEqual(docs['evidence_files']['report_id'],docs['scam_reports']['_id'])
    def test_vector_contract(self):
        sql=(ROOT/'database/01_schema.sql').read_text()
        self.assertIn('vector(384)',sql)
        self.assertIn('vector_cosine_ops',sql)
        self.assertIn('minilm-l6-v2:project-v1',(ROOT/'database/02_features.sql').read_text())
    def test_idempotency_and_versions(self):
        sql=(ROOT/'database/01_schema.sql').read_text()
        for field in ['request_hash','family_id','evidence_version','lease_token','last_evaluated_score_id']:
            self.assertIn(field,sql)

if __name__=='__main__':unittest.main()
