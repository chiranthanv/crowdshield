-- Integration assertions. Run after 01,02,03 with psql -v ON_ERROR_STOP=1.
-- No claim is made that these ran until you execute them on PostgreSQL+pgvector.
BEGIN;
DO $$
BEGIN
  BEGIN
    INSERT INTO votes(user_id,url_id,verdict)
    VALUES('00000000-0000-4000-8000-000000000001',
           '00000000-0000-4000-8000-000000000101',1);
    RAISE EXCEPTION 'FAIL: duplicate vote accepted';
  EXCEPTION WHEN unique_violation THEN NULL;
  END;
  BEGIN
    INSERT INTO votes(user_id,url_id,verdict)
    VALUES('00000000-0000-4000-8000-000000000002',
           '00000000-0000-4000-8000-000000000104',0);
    RAISE EXCEPTION 'FAIL: invalid verdict accepted';
  EXCEPTION WHEN check_violation THEN NULL;
  END;
  BEGIN
    INSERT INTO votes(user_id,url_id,verdict)
    VALUES('00000000-0000-4000-8000-000000009999',
           '00000000-0000-4000-8000-000000000101',1);
    RAISE EXCEPTION 'FAIL: missing user FK accepted';
  EXCEPTION WHEN foreign_key_violation THEN NULL;
  END;
END $$;

CALL recalculate_risk('00000000-0000-4000-8000-000000000104');
DO $$
DECLARE n integer; x v_current_risk%ROWTYPE;
BEGIN
  SELECT * INTO STRICT x FROM v_current_risk
  WHERE url_id='00000000-0000-4000-8000-000000000104';
  IF x.score<>37.5 OR x.coverage<>0 OR x.label<>'insufficient_evidence' THEN
    RAISE EXCEPTION 'FAIL: unknown URL mislabeled';
  END IF;
  SELECT vote_count INTO n FROM v_url_summary
  WHERE url_id='00000000-0000-4000-8000-000000000101';
  IF n<>3 THEN RAISE EXCEPTION 'FAIL: multiplied vote count'; END IF;
  SELECT accepted_reports INTO n FROM v_url_summary
  WHERE url_id='00000000-0000-4000-8000-000000000101';
  IF n<>2 THEN RAISE EXCEPTION 'FAIL: multiplied report count'; END IF;
END $$;

-- Verify a clear action supersedes prior confirmed-safe decision.
INSERT INTO moderator_actions(moderator_id,url_id,action_kind,verdict,reason)
VALUES('00000000-0000-4000-8000-000000000004',
 '00000000-0000-4000-8000-000000000103','set_verdict','clear','Test clearing a prior reviewed decision');
CALL recalculate_risk('00000000-0000-4000-8000-000000000103');
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM v_effective_verdict
    WHERE url_id='00000000-0000-4000-8000-000000000103' AND verdict IS NOT NULL) THEN
    RAISE EXCEPTION 'FAIL: old decision revived';
  END IF;
  IF NOT EXISTS(SELECT 1 FROM v_current_risk
    WHERE url_id='00000000-0000-4000-8000-000000000103' AND label='insufficient_evidence') THEN
    RAISE EXCEPTION 'FAIL: score not cleared';
  END IF;
END $$;
ROLLBACK;
-- A successful script finishes without errors and leaves fixtures unchanged.
