"""Pure arithmetic checks. These do not execute PostgreSQL or test model accuracy."""
import math
import unittest

def reputation(deltas):
    return max(0, min(100, 20 + sum(deltas)))

def calculate(malicious_weight, safe_weight, report_contribution,
              similarity=0.5, contributors=0, anchors=0, verdict=None):
    if min(malicious_weight, safe_weight, report_contribution, contributors, anchors) < 0:
        raise ValueError('Negative evidence counts or weights')
    if not 0 <= similarity <= 1:
        raise ValueError('Similarity component outside [0,1]')
    community=(1+malicious_weight)/(2+malicious_weight+safe_weight)
    reports=1-math.exp(-report_contribution/5)
    score=round(100*(.55*community+.25*reports+.20*similarity),2)
    coverage=min(1,(contributors+2*anchors)/10)
    if verdict == 'malicious': score,coverage=95,1
    elif verdict == 'safe': score,coverage=5,1
    label=('insufficient_evidence' if coverage<.3 else
           'high' if score>=70 else 'medium' if score>=40 else 'low')
    return score,coverage,label

class ScoringTests(unittest.TestCase):
    def test_unknown(self):
        self.assertEqual(calculate(0,0,0),(37.5,0,'insufficient_evidence'))
    def test_worked_example(self):
        score,_,label=calculate(4,1,3,.85,5,2)
        self.assertAlmostEqual(score,67.57,places=2)
        self.assertEqual(label,'medium')
    def test_malicious_override(self):
        self.assertEqual(calculate(0,10,0,verdict='malicious'),(95,1,'high'))
    def test_safe_override(self):
        self.assertEqual(calculate(10,0,10,verdict='safe'),(5,1,'low'))
    def test_clear_has_no_override(self):
        self.assertEqual(calculate(0,0,0,verdict='clear'),calculate(0,0,0))
    def test_bounds(self):
        for m in [0,1,1000]:
            for s in [0,1,1000]:
                score,coverage,_=calculate(m,s,1000,1,100,5)
                self.assertTrue(0 <= score <= 100 and 0 <= coverage <= 1)
    def test_reputation_clamps(self):
        self.assertEqual(reputation([]),20)
        self.assertEqual(reputation([-100]),0)
        self.assertEqual(reputation([100]),100)
    def test_independent_report_cap(self):
        reports={'alice':[.8,.7,.6],'bob':[.7]}
        contribution=sum(max(values) for values in reports.values())
        self.assertAlmostEqual(contribution,1.5)
    def test_malicious_votes_raise_score(self):
        self.assertGreater(calculate(2,1,0)[0],calculate(1,1,0)[0])
    def test_safe_votes_lower_score(self):
        self.assertLess(calculate(1,2,0)[0],calculate(1,1,0)[0])

if __name__ == '__main__': unittest.main()
