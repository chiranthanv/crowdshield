"""Offline document/contract audit; these checks never execute a database or API."""
from pathlib import Path
import json
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
REPORT = (ROOT / 'CrowdShield_Complete_Design.md').read_text()
SCHEMA = (ROOT / 'database/01_schema.sql').read_text()
SCOPE = json.loads((ROOT / 'scope_manifest.json').read_text())
TYPES = r'(?:uuid|smallint|bigint|integer|text|bytea|boolean|timestamptz|tsvector|jsonb|varchar\(\d+\)|numeric\(\d+,\d+\)|vector\(\d+\))'


def sql_models():
    return {name: dict(re.findall(r'^  (\w+) (' + TYPES + r')', body, re.M))
            for name, body in re.findall(r'CREATE TABLE (\w+) \(\n(.*?)\n\);', SCHEMA, re.S)}


def section(number):
    return re.search(r'(?ms)^## ' + str(number) + r' .*?(?=^## |\Z)', REPORT).group(0)


class RevisionConsistencyTests(unittest.TestCase):
    def test_all_schema_attributes_and_types_match_report(self):
        models = sql_models()
        documented = {name.lower(): dict(re.findall(r'^  (\w+) (' + TYPES + r')', body, re.M))
                      for name, body in re.findall(r'```text\n(\w+)\(\n(.*?)\n\)\n```', section(9), re.S)}
        self.assertEqual(len(models), 22)
        self.assertEqual(models, documented)

    def test_all_er_attributes_and_types_match_sql(self):
        er = (ROOT / 'diagrams/er.mmd').read_text()
        er_models = {name: {field: typ for typ, field in re.findall(r'^    (\w+) (\w+)', body, re.M)}
                     for name, body in re.findall(r'^  (\w+) \{\n(.*?)\n  \}', er, re.M | re.S)}
        simplified = {table: {field: re.sub(r'[^a-zA-Z0-9]', '', typ) for field, typ in fields.items()}
                      for table, fields in sql_models().items()}
        self.assertEqual(simplified, er_models)

    def test_scope_covers_existing_tables_and_collections(self):
        self.assertEqual(set(sql_models()), set(SCOPE['core_tables'] + SCOPE['enhanced_tables']))
        self.assertEqual(len(SCOPE['core_tables']), 17)
        self.assertEqual(len(SCOPE['enhanced_tables']), 5)
        samples = json.loads((ROOT / 'mongodb/sample_documents.json').read_text())
        self.assertEqual(set(samples), set(SCOPE['core_mongo_collections'] + SCOPE['enhanced_mongo_collections']))

    def test_api_catalog_matches_both_report_scope_tables(self):
        api = json.loads((ROOT / 'api_endpoints.json').read_text())
        api_section = section(19)
        for scope in ['Core', 'Enhanced']:
            begin = api_section.index('### ' + ('Core API' if scope == 'Core' else 'Enhanced optional API'))
            tail = api_section[begin:]
            block = tail.split('\n### ', 1)[0]
            rows = re.findall(r'^\| (GET|POST|PUT|PATCH|DELETE) \| ([^|]+) \| ([^|]+) \| ([^|]+) \|$', block, re.M)
            actual = [(x['method'], x['route'], x['access'], x['description']) for x in api if x['scope'] == scope]
            self.assertEqual(actual, [tuple(cell.strip() for cell in row) for row in rows])
            self.assertEqual(len(actual), SCOPE[scope.lower() + '_api_count'])
        implemented = json.loads((ROOT / 'docs/implemented-api.json').read_text())
        implemented_keys = {(x['method'], x['route'].removeprefix('/api/v1')) for x in implemented}
        for endpoint in api:
            expected_status = 'implemented' if (endpoint['method'], endpoint['route']) in implemented_keys else 'planned'
            self.assertEqual(endpoint['status'], expected_status)

    def test_all_45_test_cases_match_report_and_remain_planned(self):
        cases = json.loads((ROOT / 'tests/test_plan.json').read_text())
        rows = re.findall(r'^\| (T\d\d) \| (.*?) \| (.*?) \| (.*?) \| (.*?) \| (.*?) \|$', section(22), re.M)
        expected = {x['id']: tuple(x[k] for k in ['area', 'action', 'expected', 'requirements', 'owner']) for x in cases}
        self.assertEqual({row[0]: row[1:] for row in rows}, expected)
        self.assertEqual(sum(x['scope'] == 'Core' for x in cases), 25)
        self.assertEqual(sum(x['scope'] == 'Enhanced' for x in cases), 20)
        self.assertTrue(all(x['status'] == 'planned' and x['actual_result'] is None and x['evidence'] is None for x in cases))

    def test_mongo_samples_and_workflow_names_match(self):
        samples = json.loads((ROOT / 'mongodb/sample_documents.json').read_text())
        blocks = re.findall(r'### (\w+)\n\n```json\n(.*?)\n```', section(10), re.S)
        self.assertEqual({name: json.loads(content) for name, content in blocks}, samples)
        report = samples['scam_reports']
        self.assertIn('workflow_status', report)
        self.assertIn('content_version', report)
        self.assertNotIn('status', report)
        self.assertIn('same workflow_status and content_version names', section(19))

    def test_coverage_contract_and_risk_example(self):
        risk = sql_models()['risk_scores']
        self.assertEqual(risk['coverage'], 'numeric(5,4)')
        self.assertNotIn('confidence', risk)
        for name in ['database/01_schema.sql', 'database/02_features.sql', 'tests/constraints.sql', 'diagrams/er.mmd']:
            text = (ROOT / name).read_text()
            self.assertNotRegex(text, r'\bconfidence\b|\bv_conf\b')
        payload = json.loads(re.search(r'```json\n(.*?)\n```', section(19), re.S).group(1))
        self.assertTrue(set(SCOPE['risk_fields']) <= set(payload))
        self.assertEqual((payload['score'], payload['coverage'], payload['label'], payload['moderator_verdict']), (67.57, .9, 'medium', None))
        self.assertEqual(payload['algorithm_version'], SCOPE['risk_algorithm_version'])
        self.assertEqual(payload['community_component'], .71429)
        self.assertIn('0.55*v_community+0.25*v_reports+0.20*v_similarity', (ROOT / 'database/02_features.sql').read_text())

    def test_seven_core_pages_and_eight_preserved_concepts(self):
        frontend = section(20).split('### Core Pages', 1)[1].split('### Enhanced Pages', 1)[0]
        rows = re.findall(r'^\| (.*?) \| (.*?) \| (.*?) \|$', frontend, re.M)
        rows = [row for row in rows if row[0] not in ['Page and route', '---']]
        self.assertEqual(len(rows), 7)
        for title in SCOPE['core_pages']:
            self.assertTrue(any(row[0].startswith(title) for row in rows), title)
        self.assertEqual(len(SCOPE['core_advanced_concepts']), 7)
        self.assertEqual(len(SCOPE['additional_demonstration_concepts']), 1)

    def test_local_verification_and_enhanced_api_boundaries(self):
        security = section(21)
        for phrase in ['purpose=verify_email', '15-minute expiry', 'mode 0600', 'APP_MODE=local-demo', 'VERIFICATION_DELIVERY=local-file', 'does not establish real email ownership']:
            self.assertIn(phrase, security)
        api = json.loads((ROOT / 'api_endpoints.json').read_text())
        for endpoint in api:
            if any(part in endpoint['route'] for part in ['/discussions', '/comments', '/campaigns', '/analyses', '/alerts', '/notifications', '/evidence', '/export']):
                self.assertEqual(endpoint['scope'], 'Enhanced', endpoint['route'])

    def test_vector_versions_and_sql_authorization_contract(self):
        self.assertEqual(SCOPE['embedding_dimension'], 384)
        self.assertEqual(SCOPE['core_embedding_source_kind'], 'report')
        query = (ROOT / 'vector/search.sql').read_text()
        for predicate in ["e.model_version=$2", "r.workflow_status='accepted'", "r.sync_status='synced'", 'e.content_version=r.content_version']:
            self.assertIn(predicate, query)
        self.assertIn(SCOPE['model_version'], (ROOT / 'database/02_features.sql').read_text())
        self.assertIn(SCOPE['model_version'], section(11))


if __name__ == '__main__':
    unittest.main()
