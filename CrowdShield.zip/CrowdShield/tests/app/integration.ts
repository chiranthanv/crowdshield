/** Runs against dedicated real services. Refuses databases not explicitly approved as disposable.
 * For the packaged repeatable test harness use npm run test:full (WASM PostgreSQL + native MongoDB).
 */
import "dotenv/config";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import fs from "node:fs/promises";
import vm from "node:vm";
export async function integration(control?: {
  stopMongo: () => Promise<void>;
  startMongo: () => Promise<void>;
}) {
  const { query, tx, reportCollection, mongo } =
    await import("../../lib/server/db");
  const { runOnce, claim, processJob, deliverReport } =
    await import("../../workers/processor");
  const base =
    process.env.TEST_BASE_URL ||
    process.env.APP_ORIGIN ||
    "http://localhost:3000";
  const results: { test: string; status: string; detail?: string }[] = [];
  const check = async (name: string, fn: () => Promise<void>) => {
    try {
      await fn();
      results.push({ test: name, status: "passed" });
      console.log("PASS", name);
    } catch (e) {
      results.push({
        test: name,
        status: "failed",
        detail: (e as Error).message,
      });
      throw e;
    } finally {
      await fs.mkdir("docs", { recursive: true });
      await fs.writeFile(
        "docs/integration-results.json",
        JSON.stringify(
          {
            executed_at: new Date().toISOString(),
            engine: control
              ? "PostgreSQL 18.6 WASM (PGlite); native MongoDB 8.0.16"
              : "External configured services",
            results,
          },
          null,
          2,
        ),
      );
    }
  };
  async function req(
    route: string,
    method = "GET",
    data?: unknown,
    cookie = "",
    origin = base,
  ) {
    const r = await fetch(base + "/api/v1" + route, {
      method,
      headers: {
        origin,
        "Content-Type": "application/json",
        ...(cookie ? { cookie } : {}),
      },
      ...(data ? { body: JSON.stringify(data) } : {}),
    });
    return {
      status: r.status,
      data: await r.json(),
      cookie: r.headers.get("set-cookie")?.split(";")[0] || "",
    };
  }
  async function login(email: string, password: string) {
    const r = await req("/auth/login", "POST", { email, password });
    assert.equal(r.status, 200, JSON.stringify(r.data));
    return r.cookie;
  }
  const uid = (n: number) =>
    `00000000-0000-4000-8000-${String(n).padStart(12, "0")}`;
  let alice = "",
    mod = "",
    admin = "",
    newUser = "",
    newId = "",
    newUrl = "",
    newReport = "",
    token = "",
    password = "";
  await check(
    "Original schema constraints and SQL scoring assertions",
    async () => {
      await query(await fs.readFile("tests/constraints.sql", "utf8"));
    },
  );
  await check(
    "35 supplied SELECT/JOIN/GROUP BY/HAVING/subquery examples execute",
    async () => {
      await query(await fs.readFile("database/04_queries.sql", "utf8"));
    },
  );
  await check(
    "Rolled-back DML and CREATE/ALTER/DROP demonstrations execute",
    async () => {
      await query(await fs.readFile("database/05_dml.sql", "utf8"));
      const sql = await fs.readFile(
        "database/06_ddl_and_transactions.sql",
        "utf8",
      );
      await query(sql.slice(0, sql.indexOf("-- Run after seed.")));
    },
  );
  await check(
    "Four supplied MongoDB aggregation pipelines execute",
    async () => {
      const database = await mongo();
      const outputs: any[] = [];
      const tasks: Promise<unknown>[] = [];
      const proxy = new Proxy(
        {},
        {
          get: (_, name) => ({
            aggregate: (pipeline: any[]) => ({
              toArray: () => {
                const task = database
                  .collection(String(name))
                  .aggregate(pipeline)
                  .toArray();
                tasks.push(task);
                return task;
              },
            }),
          }),
        },
      );
      vm.runInNewContext(
        await fs.readFile("mongodb/03_aggregations.js", "utf8"),
        { db: proxy, printjson: (v: any) => outputs.push(v), Date },
      );
      await Promise.all(tasks);
      assert.equal(outputs.length, 4);
    },
  );
  await check(
    "Registration hashes passwords, creates role/session and normalizes email",
    async () => {
      password = "Demo-" + randomUUID();
      const r = await req("/auth/register", "POST", {
        email: " NewUser@Example.test ",
        display_name: "Integration Contributor",
        password,
      });
      assert.equal(r.status, 201, JSON.stringify(r.data));
      newUser = r.cookie;
      newId = r.data.user.user_id;
      const [u] = await query("SELECT * FROM users WHERE user_id=$1", [newId]);
      assert.notEqual(u.password_hash, password);
      assert.equal(u.email, "newuser@example.test");
      assert.equal(u.email_verified_at, null);
    },
  );
  await check("Unactivated accounts cannot vote", async () => {
    assert.equal(
      (await req("/urls/" + uid(101) + "/vote", "PUT", { verdict: 1 }, newUser))
        .status,
      403,
    );
  });
  await check(
    "Local verification is single-use and does not expose token via API",
    async () => {
      const path = await import("node:path");
      const os = await import("node:os");
      token = await fs.readFile(
        path.join(
          process.env.LOCAL_VERIFICATION_OUTBOX ||
            path.join(os.tmpdir(), "crowdshield-verification"),
          newId + ".txt",
        ),
        "utf8",
      );
      assert.equal(
        (await req("/auth/verify-email", "POST", { token })).status,
        200,
      );
      assert.equal(
        (await req("/auth/verify-email", "POST", { token })).status,
        400,
      );
    },
  );
  await check(
    "Invalid login and duplicate registration are rejected",
    async () => {
      assert.equal(
        (
          await req("/auth/login", "POST", {
            email: "newuser@example.test",
            password: "wrong",
          })
        ).status,
        401,
      );
      assert.equal(
        (
          await req("/auth/register", "POST", {
            email: "newuser@example.test",
            display_name: "Duplicate",
            password,
          })
        ).status,
        409,
      );
    },
  );
  await check(
    "Development user, moderator and admin sign in with private seeded passwords",
    async () => {
      alice = await login(
        "alice@example.test",
        process.env.SEED_USER_PASSWORD!,
      );
      mod = await login(
        "mod@example.test",
        process.env.SEED_MODERATOR_PASSWORD!,
      );
      admin = await login(
        "admin@example.test",
        process.env.SEED_ADMIN_PASSWORD!,
      );
    },
  );
  await check(
    "Anonymous and ordinary users cannot read administrative data",
    async () => {
      assert.equal((await req("/admin/users")).status, 401);
      assert.equal(
        (await req("/admin/users", "GET", undefined, alice)).status,
        403,
      );
      assert.equal(
        (await req("/moderation/reports", "GET", undefined, alice)).status,
        403,
      );
    },
  );
  await check("Cross-origin mutation is rejected", async () => {
    assert.equal(
      (
        await req(
          "/urls",
          "POST",
          { url: "https://csrf.example" },
          alice,
          "https://attacker.example",
        )
      ).status,
      403,
    );
  });
  await check(
    "URL normalization reuses exact URL identity and preserves query/path differences",
    async () => {
      const a = await req(
        "/urls",
        "POST",
        { url: "HTTPS://Test.Example:443/Path?A=1#fragment" },
        newUser,
      );
      newUrl = a.data.url.url_id;
      assert.equal(a.status, 201);
      const b = await req(
        "/urls",
        "POST",
        { url: "https://test.example/Path?A=1" },
        newUser,
      );
      assert.equal(a.data.url.url_id, b.data.url.url_id);
      const c = await req(
        "/urls",
        "POST",
        { url: "https://test.example/path?A=1" },
        newUser,
      );
      assert.notEqual(c.data.url.url_id, newUrl);
      assert.equal(
        (await req("/urls", "POST", { url: "javascript:alert(1)" }, newUser))
          .status,
        400,
      );
    },
  );
  await check(
    "No evidence is insufficient evidence with score 37.5 and coverage zero",
    async () => {
      const r = await req("/urls/" + newUrl + "/risk");
      assert.equal(r.data.risk.label, "insufficient_evidence");
      assert.equal(Number(r.data.risk.score), 37.5);
      assert.equal(Number(r.data.risk.coverage), 0);
    },
  );
  await check(
    "Report submission and idempotent replay produce one SQL/outbox identity",
    async () => {
      const input = {
        url: "https://test.example/Path?A=1",
        report_type: "scam_message",
        channel: "sms",
        message_text:
          "A parcel delivery message requests a redelivery fee. Email fake@example.test and number 9876543210 appear in the invented message.",
        idempotency_key: randomUUID(),
      };
      const a = await req("/reports", "POST", input, newUser);
      assert.equal(a.status, 202, JSON.stringify(a.data));
      newReport = a.data.report.report_id;
      assert.equal(a.data.report.sync_status, "pending");
      const b = await req("/reports", "POST", input, newUser);
      assert.equal(b.data.report.report_id, newReport);
      assert.equal(b.data.report.replayed, true);
      assert.equal(
        (
          await req(
            "/reports",
            "POST",
            {
              ...input,
              message_text: "A different report body for the same request key.",
            },
            newUser,
          )
        ).status,
        409,
      );
      const [count] = await query(
        "SELECT count(*)::int n FROM outbox_events WHERE aggregate_id=$1 AND event_type='report.created'",
        [newReport],
      );
      assert.equal(count.n, 1);
    },
  );
  await check(
    "Pending evidence is private and ownership checks reject withdrawal by another user",
    async () => {
      assert.equal((await req("/reports/" + newReport)).status, 404);
      assert.equal(
        (await req("/reports/" + newReport, "DELETE", undefined, alice)).status,
        403,
      );
    },
  );
  await check(
    control
      ? "MongoDB outage leaves a retryable outbox record; recovery delivers exactly once"
      : "MongoDB delivery synchronizes one document (controlled outage not exercised)",
    async () => {
      if (control) {
        await control.stopMongo();
        await runOnce(100);
        const [job] = await query(
          `SELECT * FROM outbox_events WHERE aggregate_id=$1 AND event_type='report.created'`,
          [newReport],
        );
        assert.equal(job.status, "pending");
        assert(job.attempts >= 1);
        assert(job.last_error);
        const [r] = await query(
          "SELECT sync_status FROM report_refs WHERE report_id=$1",
          [newReport],
        );
        assert.equal(r.sync_status, "pending");
        await control.startMongo();
      }
      await query(
        `UPDATE outbox_events SET available_at=now() WHERE status='pending'`,
      );
      await runOnce(100);
      const col = await reportCollection();
      assert.equal(await col.countDocuments({ _id: newReport }), 1);
      assert.equal(
        (
          await query(
            "SELECT sync_status FROM report_refs WHERE report_id=$1",
            [newReport],
          )
        )[0].sync_status,
        "synced",
      );
      const doc = await col.findOne({ _id: newReport });
      assert(!doc!.message_text.includes("fake@example.test"));
      assert(!doc!.message_text.includes("9876543210"));
    },
  );
  await check(
    "Vote insert, change and withdrawal retain one DB row and trigger audit entries",
    async () => {
      assert.equal(
        (await req("/urls/" + newUrl + "/vote", "PUT", { verdict: 1 }, newUser))
          .status,
        200,
      );
      assert.equal(
        (
          await req(
            "/urls/" + newUrl + "/vote",
            "PUT",
            { verdict: -1 },
            newUser,
          )
        ).status,
        200,
      );
      const [stats] = await query(
        "SELECT count(*)::int n,min(verdict) verdict FROM votes WHERE user_id=$1 AND url_id=$2",
        [newId, newUrl],
      );
      assert.equal(stats.n, 1);
      assert.equal(stats.verdict, -1);
      assert.equal(
        (await req("/urls/" + newUrl + "/vote", "DELETE", undefined, newUser))
          .status,
        200,
      );
      const [a] = await query(
        `SELECT count(*)::int n FROM audit_logs WHERE actor_id=$1 AND entity_id=$2 AND action LIKE 'vote.%'`,
        [newId, newUrl],
      );
      assert.equal(a.n, 3);
    },
  );
  await check(
    "Moderator can accept only synchronized pending reports and cannot self-review",
    async () => {
      const r = await req(
        "/moderation/reports/" + newReport + "/decision",
        "POST",
        {
          accept: true,
          reason: "Reviewed invented delivery payment impersonation evidence.",
        },
        mod,
      );
      assert.equal(r.status, 200, JSON.stringify(r.data));
      assert.equal(
        (
          await req(
            "/moderation/reports/" + newReport + "/decision",
            "POST",
            { accept: true, reason: "Second decision should be rejected." },
            mod,
          )
        ).status,
        409,
      );
      await runOnce(100);
      const own = await req(
        "/reports",
        "POST",
        {
          url: "https://mod-report.example/",
          report_type: "phishing",
          message_text:
            "An invented test report submitted by its own moderator.",
          idempotency_key: randomUUID(),
        },
        mod,
      );
      await runOnce(100);
      assert.equal(
        (
          await req(
            "/moderation/reports/" + own.data.report.report_id + "/decision",
            "POST",
            { accept: true, reason: "This is a self review attempt." },
            mod,
          )
        ).status,
        403,
      );
    },
  );
  await check(
    "Human malicious/safe/clear verdicts preserve risk history and formula",
    async () => {
      for (const [verdict, expected] of [
        ["malicious", 95],
        ["safe", 5],
      ] as const) {
        const r = await req(
          "/moderation/urls/" + newUrl + "/verdict",
          "POST",
          {
            verdict,
            reason: "Reviewed evidence for a temporary test decision.",
            valid_days: 1,
          },
          mod,
        );
        assert.equal(r.status, 200);
        const current = await req("/urls/" + newUrl + "/risk");
        assert.equal(Number(current.data.risk.score), expected);
        assert.equal(Number(current.data.risk.coverage), 1);
        assert.equal(current.data.risk.moderator_verdict, verdict);
      }
      await req(
        "/moderation/urls/" + newUrl + "/verdict",
        "POST",
        {
          verdict: "clear",
          reason: "Clear the previous reviewed decision.",
          valid_days: null,
        },
        mod,
      );
      assert.equal(
        (await req("/urls/" + newUrl + "/risk")).data.risk.moderator_verdict,
        null,
      );
    },
  );
  await check(
    "Real embeddings are normalized, 384-dimensional and content-versioned",
    async () => {
      await runOnce(100);
      const [r] = await query(
        "SELECT vector_dims(embedding) dims,vector_norm(embedding) norm,content_version,metadata FROM embeddings WHERE report_id=$1",
        [newReport],
      );
      assert(r);
      assert.equal(r.dims, 384);
      assert(Math.abs(r.norm - 1) < 0.001);
      assert.equal(r.content_version, 2);
      assert.equal(
        r.metadata.model_revision,
        process.env.EMBEDDING_MODEL_REVISION,
      );
    },
  );
  await check(
    "Semantic and full-text search return accepted report evidence",
    async () => {
      const s = await req("/search/semantic", "POST", {
        q: "parcel redelivery payment fee",
      });
      assert.equal(s.status, 200, JSON.stringify(s.data));
      assert(s.data.items.some((r: any) => r.report_id === newReport));
      assert(
        s.data.items.every((r: any) =>
          Number.isFinite(Number(r.cosine_similarity)),
        ),
      );
      const t = await req("/search/text?q=redelivery");
      assert.equal(t.status, 200);
      assert(t.data.items.length > 0);
    },
  );
  await check(
    "Late old delivery cannot overwrite newer document content",
    async () => {
      const [old] = await query(
        `SELECT * FROM outbox_events WHERE aggregate_id=$1 AND event_type='report.created'`,
        [newReport],
      );
      await deliverReport({ ...old, lease_token: randomUUID() });
      const doc = await (await reportCollection()).findOne({ _id: newReport });
      assert.equal(doc!.content_version, 2);
      assert.equal(doc!.workflow_status, "accepted");
    },
  );
  await check(
    "Lease token prevents stale completion from acknowledging a job",
    async () => {
      await query(
        `INSERT INTO outbox_events(event_type,aggregate_id,aggregate_version,payload) VALUES('risk.refresh',$1,999999,'{}')`,
        [newUrl],
      );
      await runOnce(100);
      await query(
        `UPDATE outbox_events SET status='pending',attempts=0 WHERE aggregate_id=$1 AND aggregate_version=999999`,
        [newUrl],
      );
      const job = await claim();
      assert(job);
      const replacement = randomUUID();
      await query("UPDATE outbox_events SET lease_token=$2 WHERE event_id=$1", [
        job.event_id,
        replacement,
      ]);
      await processJob(job);
      assert.equal(
        (
          await query("SELECT status FROM outbox_events WHERE event_id=$1", [
            job.event_id,
          ])
        )[0].status,
        "processing",
      );
      await query(
        "UPDATE outbox_events SET status='pending',lease_token=NULL WHERE event_id=$1",
        [job.event_id],
      );
      await runOnce(100);
    },
  );
  await check(
    "Withdrawn evidence immediately disappears from public reads/search before Mongo sync",
    async () => {
      assert.equal(
        (await req("/reports/" + newReport, "DELETE", undefined, newUser))
          .status,
        200,
      );
      assert.equal((await req("/reports/" + newReport)).status, 404);
      const s = await req("/search/semantic", "POST", {
        q: "parcel redelivery payment fee",
      });
      assert(!s.data.items.some((r: any) => r.report_id === newReport));
      assert.equal(
        (
          await query(
            "SELECT count(*)::int n FROM embeddings WHERE report_id=$1",
            [newReport],
          )
        )[0].n,
        0,
      );
      await runOnce(100);
      assert.equal(
        (await (await reportCollection()).findOne({ _id: newReport }))!
          .workflow_status,
        "withdrawn",
      );
    },
  );
  await check(
    "Transaction rollback prevents partial URL/report/outbox persistence",
    async () => {
      const id = randomUUID();
      await assert.rejects(
        tx(async (db) => {
          await db.query(
            `INSERT INTO urls(url_id,canonical_url,hostname,display_url,submitted_by) VALUES($1,'https://rollback.example/','rollback.example','hxxps://rollback[.]example/',$2)`,
            [id, newId],
          );
          await db.query(
            `INSERT INTO report_refs(url_id,reporter_id,report_type,idempotency_key,request_hash) VALUES($1,$2,'invalid',$3,decode(repeat('00',32),'hex'))`,
            [id, newId, randomUUID()],
          );
        }),
      );
      assert.equal(
        (
          await query("SELECT count(*)::int n FROM urls WHERE url_id=$1", [id])
        )[0].n,
        0,
      );
    },
  );
  await check(
    "MongoDB collection validation rejects malformed report documents",
    async () => {
      await assert.rejects(
        (await mongo())
          .collection("scam_reports")
          .insertOne({ _id: "not-a-uuid" } as any),
      );
    },
  );
  await check(
    "Admin role grant/revoke and suspension invalidate existing sessions",
    async () => {
      assert.equal(
        (
          await req(
            "/admin/users/" + newId + "/roles/moderator",
            "PUT",
            undefined,
            admin,
          )
        ).status,
        200,
      );
      assert.equal((await req("/me", "GET", undefined, newUser)).status, 401);
      newUser = await login("newuser@example.test", password);
      assert.equal(
        (await req("/moderation/reports", "GET", undefined, newUser)).status,
        200,
      );
      assert.equal(
        (
          await req(
            "/admin/users/" + newId + "/roles/moderator",
            "DELETE",
            undefined,
            admin,
          )
        ).status,
        200,
      );
      newUser = await login("newuser@example.test", password);
      assert.equal(
        (await req("/moderation/reports", "GET", undefined, newUser)).status,
        403,
      );
      assert.equal(
        (
          await req(
            "/admin/users/" + newId + "/status",
            "PATCH",
            { status: "suspended" },
            admin,
          )
        ).status,
        200,
      );
      assert.equal((await req("/me", "GET", undefined, newUser)).status, 401);
      assert.equal(
        (
          await req("/auth/login", "POST", {
            email: "newuser@example.test",
            password,
          })
        ).status,
        401,
      );
    },
  );
  await check("Last active administrator is protected", async () => {
    assert.equal(
      (
        await req(
          "/admin/users/" + uid(5) + "/roles/admin",
          "DELETE",
          undefined,
          admin,
        )
      ).status,
      409,
    );
  });
  await check(
    "Session renewal and logout invalidate old session cookies",
    async () => {
      const renewed = await req("/auth/refresh", "POST", undefined, alice);
      assert.equal(renewed.status, 200);
      assert.notEqual(renewed.cookie, alice);
      assert.equal((await req("/me", "GET", undefined, alice)).status, 401);
      assert.equal(
        (await req("/auth/logout", "POST", undefined, renewed.cookie)).status,
        200,
      );
      assert.equal(
        (await req("/me", "GET", undefined, renewed.cookie)).status,
        401,
      );
    },
  );
  await check(
    "Analytics and admin jobs use actual data without private outbox payloads",
    async () => {
      const a = await req("/analytics/trends");
      assert.equal(a.status, 200);
      assert.equal(a.data.daily.length, 14);
      assert(a.data.mongo);
      const j = await req("/admin/jobs", "GET", undefined, admin);
      assert.equal(j.status, 200);
      assert(j.data.items.every((r: any) => !("payload" in r)));
    },
  );
  await check("SQL injection text is treated as search data", async () => {
    const r = await req(
      "/search/text?q=" + encodeURIComponent("'; DROP TABLE users; --"),
    );
    assert.equal(r.status, 200);
    assert((await query("SELECT count(*)::int n FROM users"))[0].n >= 5);
  });
  console.log(`Integration: ${results.length} checks passed.`);
  return results;
}
if (process.argv[1]?.replaceAll("\\", "/").endsWith("/integration.ts")) {
  if (process.env.ALLOW_TEST_MUTATIONS !== "yes")
    throw new Error(
      "Tests create and change fixtures. Set ALLOW_TEST_MUTATIONS=yes only for a disposable test database, or run npm run test:full.",
    );
  try {
    await integration();
  } finally {
    const { closeDb } = await import("../../lib/server/db");
    await closeDb();
  }
}
