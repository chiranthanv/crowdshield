import "dotenv/config";
import { chromium, expect } from "@playwright/test";
import fs from "node:fs/promises";
export async function browserChecks() {
  const browser = await chromium.launch({
    headless: true,
    ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE
      ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE }
      : {}),
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  const context = await browser.newContext({
    viewport: { width: 1440, height: 1000 },
  });
  const page = await context.newPage();
  const origin =
    process.env.TEST_BASE_URL ||
    process.env.APP_ORIGIN ||
    "http://localhost:3000";
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await fs.mkdir("screenshots", { recursive: true });
  const capture = async (name: string) => {
    await page.screenshot({ path: `screenshots/${name}.png`, fullPage: true });
  };
  async function login(email: string, password: string) {
    await page.goto(origin + "/login");
    await page.getByLabel("Email address").fill(email);
    await page.getByLabel("Password", { exact: true }).fill(password);
    await page.getByRole("button", { name: "Sign in", exact: true }).click();
    await expect(page).toHaveURL(origin + "/dashboard");
    await expect(
      page.getByText("Your reports", { exact: true }).first(),
    ).toBeVisible();
  }
  try {
    await page.goto(origin);
    await expect(
      page.getByRole("heading", {
        name: "A clearer view of suspicious links.",
      }),
    ).toBeVisible();
    await expect(
      page.getByText("parcel-check.example", { exact: true }).first(),
    ).toBeVisible();
    await capture("01_home");
    await page.getByLabel("Search query").fill("https://new-site.example/");
    await page
      .getByRole("button", { name: "Investigate", exact: true })
      .click();
    await expect(
      page.getByRole("heading", { name: "new-site.example" }),
    ).toBeVisible();
    await expect(
      page.getByText("insufficient evidence", { exact: true }).first(),
    ).toBeVisible();
    await capture("02_unknown_url");
    await login("alice@example.test", process.env.SEED_USER_PASSWORD!);
    await expect(
      page.getByRole("heading", { name: "Your reports", exact: true }),
    ).toBeVisible();
    await capture("03_dashboard");
    await page.goto(origin + "/report");
    await expect(
      page.getByRole("button", { name: "Submit report", exact: true }),
    ).toBeVisible();
    await capture("04_report_form");
    await page
      .getByLabel("Suspicious URL")
      .fill("https://browser-demo.example/verify");
    await page
      .getByLabel("Redacted explanation")
      .fill(
        "An invented parcel redelivery message requests a handling fee through an unfamiliar payment website.",
      );
    await page
      .getByRole("button", { name: "Submit report", exact: true })
      .click();
    await expect(
      page.getByText("Report recorded in PostgreSQL."),
    ).toBeVisible();
    const { runOnce } = await import("../../workers/processor");
    await runOnce(100);
    await page.goto(origin + "/urls/00000000-0000-4000-8000-000000000101");
    await expect(
      page.getByRole("heading", { name: "parcel-check.example" }),
    ).toBeVisible();
    await expect(
      page
        .getByText("An invented parcel delivery text demands", { exact: false })
        .first(),
    ).toBeVisible();
    await capture("05_url_detail");
    await page.goto(origin + "/analytics");
    await expect(
      page.getByRole("heading", { name: "Community analytics" }),
    ).toBeVisible();
    await expect(
      page.getByRole("heading", { name: "Accepted evidence by type" }),
    ).toBeVisible();
    await capture("06_analytics");
    await login("mod@example.test", process.env.SEED_MODERATOR_PASSWORD!);
    await page.goto(origin + "/moderation");
    await expect(
      page.getByRole("heading", { name: "Moderation queue" }),
    ).toBeVisible();
    await expect(
      page.getByRole("button", { name: "Accept report" }).first(),
    ).toBeVisible();
    await expect(
      page.getByText("A fictional parcel redelivery payment page", {
        exact: false,
      }),
    ).toBeVisible();
    await expect(
      page.getByText("An invented parcel redelivery message requests", {
        exact: false,
      }),
    ).toBeVisible();
    await capture("07_moderation");
    const reviewCard = page.locator("section.panel").filter({
      hasText: "A fictional parcel redelivery payment page",
    });
    await expect(reviewCard).toHaveCount(1);
    await reviewCard
      .getByLabel("Review reason (at least 10 characters)")
      .fill("Reviewed the invented parcel fee and impersonation evidence.");
    await reviewCard.getByRole("button", { name: "Accept report" }).click();
    await expect(reviewCard).toHaveCount(0);
    await runOnce(100);
    await page.goto(origin + "/urls/00000000-0000-4000-8000-000000000102");
    await page.getByLabel("Verdict", { exact: true }).selectOption("clear");
    await page
      .getByLabel("Reason", { exact: true })
      .fill(
        "Removing the demo override after reviewing the recorded evidence.",
      );
    await page
      .getByRole("button", { name: "Save verdict", exact: true })
      .click();
    await expect(page.getByText("Reviewed verdict saved.")).toBeVisible();
    await page.goto(origin);
    await page
      .getByRole("button", { name: "Semantic search", exact: true })
      .click();
    await page.getByLabel("Search query").fill("parcel redelivery payment fee");
    await page
      .getByRole("button", { name: "Investigate", exact: true })
      .click();
    await expect(page.getByText(/^Cosine /).first()).toBeVisible({
      timeout: 60000,
    });
    await capture("11_semantic_search");
    await login("admin@example.test", process.env.SEED_ADMIN_PASSWORD!);
    await page.goto(origin + "/admin");
    await expect(
      page.getByText("admin@example.test", { exact: true }),
    ).toBeVisible();
    await capture("08_admin_accounts");
    await page
      .getByRole("button", { name: "Worker jobs", exact: true })
      .click();
    await expect(
      page.getByRole("heading", { name: "Outbox delivery history" }),
    ).toBeVisible();
    await capture("09_admin_jobs");
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto(origin);
    await expect(
      page.getByRole("heading", {
        name: "A clearer view of suspicious links.",
      }),
    ).toBeVisible();
    await expect(
      page.getByText("parcel-check.example", { exact: true }).first(),
    ).toBeVisible();
    await capture("10_mobile_home");
    const overflows = await page.evaluate(
      () => document.documentElement.scrollWidth > window.innerWidth,
    );
    expect(overflows).toBe(false);
    expect(errors).toEqual([]);
    const report = {
      executed_at: new Date().toISOString(),
      status: "passed",
      browser_version: browser.version(),
      screenshots: 11,
      checks: [
        "Home data loaded",
        "Exact lookup navigation",
        "Unknown evidence label",
        "Login form and dashboard",
        "Report submitted through UI",
        "URL evidence rendered",
        "Analytics rendered",
        "Moderator and admin screens",
        "Moderator accepts synchronized evidence through UI",
        "Reviewed verdict changed from URL Detail",
        "Real semantic search results displayed",
        "Worker jobs visible",
        "Mobile viewport has no page overflow",
        "No browser runtime errors",
      ],
    };
    await fs.writeFile(
      "docs/browser-results.json",
      JSON.stringify(report, null, 2),
    );
    console.log("PASS Browser UI workflows; 11 real screenshots saved.");
    return report;
  } finally {
    await context.close();
    await browser.close();
  }
}
if (process.argv[1]?.replaceAll("\\", "/").endsWith("/browser.ts")) await browserChecks();
