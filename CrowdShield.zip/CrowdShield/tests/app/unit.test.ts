import { test } from "node:test";
import assert from "node:assert/strict";
import {
  normalizeUrl,
  redact,
  registerSchema,
  reportSchema,
} from "../../lib/server/validation";
import { NextRequest } from "next/server";
import {
  originCheck,
  passwordHash,
  passwordMatches,
} from "../../lib/server/auth";
import { config } from "../../lib/server/config";
test("URL normalization folds host/scheme/default port and removes fragment", () => {
  assert.equal(
    normalizeUrl("HTTPS://Parcel.Example:443/Verify?B=2&a=1#section")
      .canonical_url,
    "https://parcel.example/Verify?B=2&a=1",
  );
});
test("case-sensitive paths and ordered query parameters retain identity", () => {
  assert.notEqual(
    normalizeUrl("https://a.example/Pay?a=1&b=2").canonical_url,
    normalizeUrl("https://a.example/pay?b=2&a=1").canonical_url,
  );
});
test("unsafe schemes, missing scheme and embedded credentials rejected", () => {
  for (const x of [
    "javascript:alert(1)",
    "ftp://a.example/",
    "a.example",
    "https://a:b@a.example",
  ])
    assert.throws(() => normalizeUrl(x));
});
test("URLs are defanged for display", () => {
  assert.equal(
    normalizeUrl("https://a.example/").display_url,
    "hxxps://a[.]example/",
  );
});
test("redaction removes obvious email, long number and labeled secret", () => {
  const t = redact("Email a@b.example number 9876543210 password=private");
  assert(!t.includes("a@b.example"));
  assert(!t.includes("9876543210"));
  assert(!t.includes("private"));
});
test("registration validates length and normalizes email", () => {
  assert.equal(
    registerSchema.parse({
      email: " A@B.EXAMPLE ",
      display_name: "Alice",
      password: "long-demo-password",
    }).email,
    "a@b.example",
  );
  assert.throws(() =>
    registerSchema.parse({
      email: "a@b.example",
      display_name: "Alice",
      password: "short",
    }),
  );
});
test("report requires idempotency UUID and meaningful message", () => {
  assert.throws(() =>
    reportSchema.parse({
      url: "https://a.example/",
      report_type: "phishing",
      message_text: "short",
    }),
  );
});
test("CSRF origin rejects missing and hostile origin", () => {
  assert.throws(() =>
    originCheck(
      new NextRequest(config.origin + "/api/v1/urls", { method: "POST" }),
    ),
  );
  assert.throws(() =>
    originCheck(
      new NextRequest(config.origin + "/api/v1/urls", {
        method: "POST",
        headers: { origin: "https://attacker.example" },
      }),
    ),
  );
  originCheck(
    new NextRequest(config.origin + "/api/v1/urls", {
      method: "POST",
      headers: { origin: config.origin },
    }),
  );
});
test("password hashes verify correct passwords and reject wrong ones", async () => {
  const h = await passwordHash("A-long-test-password");
  assert.notEqual(h, "A-long-test-password");
  assert(await passwordMatches("A-long-test-password", h));
  assert(!(await passwordMatches("wrong", h)));
});
