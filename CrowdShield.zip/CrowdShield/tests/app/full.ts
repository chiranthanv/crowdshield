import "dotenv/config";
import { PGlite } from "@electric-sql/pglite";
import { vector } from "@electric-sql/pglite-pgvector";
import { pgcrypto } from "@electric-sql/pglite/contrib/pgcrypto";
import { PGLiteSocketServer } from "@electric-sql/pglite-socket";
import { MongoMemoryServer } from "mongodb-memory-server";
import { spawn, type ChildProcess } from "node:child_process";
import { randomBytes } from "node:crypto";
import fs from "node:fs/promises";
import pg from "pg";
const secret = () => randomBytes(18).toString("hex");
process.env.APP_MODE = "local-demo";
process.env.APP_ORIGIN = "http://127.0.0.1:3100";
process.env.TEST_BASE_URL = process.env.APP_ORIGIN;
process.env.DATABASE_URL = "postgresql://postgres@127.0.0.1:5433/postgres";
process.env.DATABASE_ADMIN_URL = process.env.DATABASE_URL;
process.env.PG_POOL_MAX = "1";
process.env.SEED_USER_PASSWORD = secret();
process.env.SEED_MODERATOR_PASSWORD = secret();
process.env.SEED_ADMIN_PASSWORD = secret();
const db = await PGlite.create({ extensions: { vector, pgcrypto } });
const server = new PGLiteSocketServer({
  db,
  host: "127.0.0.1",
  port: 5433,
  maxConnections: 10,
});
let m: MongoMemoryServer | undefined;
let app: ChildProcess | undefined;
let appLog = "";
try {
  await server.start();
  m = await MongoMemoryServer.create({
    binary: { version: "8.0.16" },
    instance: {
      ip: "127.0.0.1",
      port: 27018,
      args: [
        ...(process.platform === "win32" ? [] : ["--nounixsocket"]),
        "--wiredTigerCacheSizeGB", "0.25",
      ],
    },
  });
  process.env.MONGODB_URI = m.getUri("crowdshield");
  const { setupSql, setupMongo, setupAppRole } =
    await import("../../scripts/setup");
  const c = new pg.Client({ connectionString: process.env.DATABASE_URL });
  await c.connect();
  try {
    await setupSql(c);
    await setupAppRole(c, secret());
    await c.query("BEGIN; SET LOCAL ROLE crowdshield_app");
    await c.query(
      "INSERT INTO url_categories(name,description) VALUES('Temporary permission fixture','Rolled back')",
    );
    const {
      rows: [permissions],
    } = await c.query(`SELECT
    has_schema_privilege(current_user,'public','CREATE') can_create,
    has_table_privilege(current_user,'audit_logs','UPDATE') can_change_audit,
    has_table_privilege(current_user,'audit_logs','DELETE') can_delete_audit,
    has_table_privilege(current_user,'url_categories','INSERT') can_seed_categories`);
    if (
      permissions.can_create ||
      permissions.can_change_audit ||
      permissions.can_delete_audit ||
      !permissions.can_seed_categories
    )
      throw new Error("Application role privilege policy is incorrect");
    await c.query("ROLLBACK");
    await fs.writeFile(
      "docs/permissions-results.json",
      JSON.stringify(
        {
          executed_at: new Date().toISOString(),
          status: "passed",
          engine: "PostgreSQL WASM",
          role: "crowdshield_app",
          permissions,
        },
        null,
        2,
      ),
    );
  } finally {
    await c.end();
  }
  await setupMongo(process.env.MONGODB_URI);
  const { seed } = await import("../../scripts/seed");
  await seed();
  // Exercise the documented owner-only DDL/DML demo against this disposable database.
  await import("../../scripts/demo");
  app = spawn(
    process.execPath,
    [
      "node_modules/next/dist/bin/next",
      "start",
      "--hostname",
      "127.0.0.1",
      "--port",
      "3100",
    ],
    {
      stdio: ["ignore", "pipe", "pipe"],
      env: { ...process.env, NEXT_TELEMETRY_DISABLED: "1" },
    },
  );
  app.stdout?.on("data", (d) => {
    appLog += d.toString();
  });
  app.stderr?.on("data", (d) => {
    appLog += d.toString();
  });
  let ready = false;
  for (let i = 0; i < 80; i++) {
    try {
      const r = await fetch(process.env.APP_ORIGIN + "/api/v1/health");
      if (r.ok) {
        ready = true;
        break;
      }
    } catch {}
    await new Promise((r) => setTimeout(r, 250));
  }
  if (!ready) throw new Error("Next.js did not start. " + appLog.slice(-1500));
  console.log("Production Next.js server ready for HTTP/browser tests.");
  const { integration } = await import("./integration");
  if (!process.argv.includes("--browser-only"))
    await integration({
      stopMongo: async () => {
        await m!.stop({ doCleanup: false, force: false });
      },
      startMongo: async () => {
        await m!.start(true);
      },
    });
  if (!process.argv.includes("--no-browser")) {
    const { browserChecks } = await import("./browser");
    await browserChecks();
  }
  await fs.writeFile("docs/test-server.log", appLog);
  console.log("FULL VERIFICATION COMPLETE");
} catch (e) {
  console.error(e);
  console.error(appLog.slice(-2000));
  await fs.writeFile("docs/test-server.log", appLog);
  process.exitCode = 1;
} finally {
  app?.kill("SIGTERM");
  const { closeDb } = await import("../../lib/server/db");
  await closeDb();
  await m?.stop();
  await server.stop();
  await db.close();
}
