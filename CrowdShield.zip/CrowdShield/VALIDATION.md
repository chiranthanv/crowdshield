# Current validation status 2 November 2026

The final Windows run passed against the patched application. The [requirements audit](docs/REQUIREMENTS_AUDIT.md) maps the supplied assignment to implementation and evidence. The [verification ledger](docs/windows-verification.json) records timestamps, source hashes and the corrected browser-test retry.

| Executed check | Actual result | Evidence |
| --- | --- | --- |
| Python schema, dictionary, ER and scoring checks | 30 passed | [Log](docs/windows-python-tests.log) |
| Node unit checks | 9 passed | [Log](docs/windows-unit-tests.log) |
| TypeScript and ESLint | Passed, including the final browser-test fix | [TypeScript](docs/windows-typecheck.log), [ESLint](docs/windows-lint.log), [browser-test lint](docs/windows-browser-test-lint.log) |
| Production Next.js 16.4.1 build | Passed | [Build log](docs/windows-build.log) |
| HTTP/database scenarios | 31 passed, including real MongoDB outage/recovery | [Results](docs/integration-results.json) |
| Restricted application role | Passed under SET LOCAL ROLE | [Results](docs/permissions-results.json) |
| Browser workflows | Passed on Chrome 156.0.8078.76; 11 fresh screenshots reviewed | [Results](docs/browser-results.json), [screenshots](screenshots/) |
| ER diagram | All 22 entities parsed and rendered | [SVG](diagrams/er.svg), [source](diagrams/er.mmd) |
| Production dependency audit | 0 reported vulnerabilities | [Audit](docs/windows-dependency-audit.json) |

SQL execution used PostgreSQL 18.6 WASM (PGlite 0.5.9) with pgvector, alongside native MongoDB 8.0.16. The app ran on Windows with Node 24.11.1. Real normalized 384-dimensional embeddings still work after the security updates. All 35 reference SQL queries, four MongoDB aggregation scripts, constraint assertions, and the rolled-back DDL/DML demonstration executed in the combined run.

The browser test now identifies the report it reviews and verifies that report leaves the queue. It passes alongside API fixtures that add other pending reports. The ledger preserves the original failed queue-count assertion and the successful retry.

Docker/native PostgreSQL deployment and native database authentication remain untested; Docker/PostgreSQL services are unavailable here. The portable trusted-loopback demo is documented separately. Instructor approval, section-title uniqueness, genuine individual GitHub contributions, and the students' oral demonstration require their own evidence.

## Historical verification 13 October 2026

The working application's authoritative execution record is `IMPLEMENTATION_REPORT.md` and the files in `docs/`. The earlier design-only assessment is preserved in `docs/DESIGN_VALIDATION_ARCHIVE.md`.

| Executed check | Actual result | Evidence |
|---|---|---|
| Original Python checks | 30 passed | docs/static-checks.log |
| Node unit checks | 9 passed | docs/static-checks.log |
| TypeScript / ESLint | Passed | docs/static-checks.log |
| Production build | Passed | docs/build.log |
| HTTP and database scenarios | 31 passed, including actual Mongo outage/recovery | docs/integration-results.json |
| Restricted app role | Passed under SET LOCAL ROLE | docs/permissions-results.json |
| Browser workflows | Passed; 11 real screenshots | docs/browser-results.json and screenshots/ |

SQL execution used PostgreSQL 18.6 WASM (PGlite) with pgvector. MongoDB was a native 8.0.16 process. Native PostgreSQL/Docker installation, native authentication, production concurrency/load, backup restoration and the legacy migration have not been verified. No detection accuracy or production-readiness claim is made.

The original 45-case acceptance plan remains a preserved design artifact. Its planned cases are distinct from the executed implementation tests above. Use README.md for exact commands to reproduce verification on disposable services and to launch the local application.
