-- 35 distinct examples: 15 general SELECT, 5 JOIN, 5 GROUP BY,
-- 5 HAVING and 5 subquery examples. UUIDs refer to 03_seed.sql.

-- S01: newest visible URL submissions, deterministic pagination order.
SELECT url_id,display_url,first_seen_at FROM urls WHERE NOT is_archived
ORDER BY first_seen_at DESC,url_id LIMIT 20;
-- S02: exact normalized URL lookup using a digest index; verify full equality.
SELECT url_id,display_url FROM urls
WHERE canonical_hash=digest('https://parcel-check.example/verify','sha256')
  AND canonical_url='https://parcel-check.example/verify';
-- S03: hostname lookup, returning all observed paths on one host.
SELECT url_id,display_url FROM urls WHERE hostname='parcel-check.example';
-- S04: high-risk results with enough evidence, via the latest-score view.
SELECT * FROM v_current_risk WHERE label='high' ORDER BY score DESC,url_id;
-- S05: URLs first observed in the last week.
SELECT url_id,first_seen_at FROM urls
WHERE first_seen_at>=now()-interval '7 days' ORDER BY first_seen_at DESC;
-- S06: one user's unread notifications.
SELECT notification_id,message FROM notifications
WHERE user_id='00000000-0000-4000-8000-000000000001' AND read_at IS NULL
ORDER BY created_at DESC,notification_id;
-- S07: synchronized reports waiting for review.
SELECT report_id,url_id,created_at FROM report_refs
WHERE workflow_status='pending' AND sync_status='synced'
ORDER BY created_at,report_id;
-- S08: a user's current votes.
SELECT url_id,verdict,updated_at FROM votes
WHERE user_id='00000000-0000-4000-8000-000000000001' ORDER BY updated_at DESC;
-- S09: immutable score timeline for one URL.
SELECT score,label,algorithm_version,computed_at FROM risk_scores
WHERE url_id='00000000-0000-4000-8000-000000000101'
ORDER BY computed_at,risk_score_id;
-- S10: pending outbox deliveries with a recorded retryable error.
SELECT event_id,event_type,attempts,last_error FROM outbox_events
WHERE status='pending' AND last_error IS NOT NULL AND attempts<8
ORDER BY available_at,event_id;
-- S11: full-text search over sanitized public summary and hostname.
SELECT url_id,display_url,
 ts_rank(search_vector,websearch_to_tsquery('simple','parcel payment')) AS rank
FROM urls WHERE search_vector @@ websearch_to_tsquery('simple','parcel payment')
ORDER BY rank DESC,url_id LIMIT 20;
-- S12: enabled alerts above a selected threshold.
SELECT alert_id,url_id,threshold FROM alerts WHERE enabled AND threshold>=70;
-- S13: active verified users, without exposing hashes or email addresses.
SELECT user_id,display_name FROM users
WHERE status='active' AND email_verified_at IS NOT NULL ORDER BY display_name,user_id;
-- S14: one user's reputation event ledger.
SELECT delta,reason,created_at FROM reputation_events
WHERE user_id='00000000-0000-4000-8000-000000000001' ORDER BY created_at,event_id;
-- S15: completed AI analyses, newest first; owner/moderator access only.
SELECT analysis_id,url_id,model_name,completed_at FROM ai_analyses
WHERE status='done' ORDER BY completed_at DESC,analysis_id LIMIT 20;

-- J01: users and their assigned roles (many-to-many bridge).
SELECT u.display_name,r.name AS role FROM users u
JOIN user_roles ur USING(user_id) JOIN roles r USING(role_id)
ORDER BY u.display_name,r.name;
-- J02: visible URLs with optional current risk; unscored URLs remain visible.
SELECT u.display_url,r.score,r.label FROM urls u
LEFT JOIN v_current_risk r USING(url_id) WHERE NOT u.is_archived;
-- J03: report queue showing reporter display name and URL.
SELECT rr.report_id,u.display_name,l.display_url,rr.workflow_status
FROM report_refs rr JOIN users u ON u.user_id=rr.reporter_id
JOIN urls l ON l.url_id=rr.url_id;
-- J04: campaign membership with time of analyst linking.
SELECT c.name,u.display_url,cu.linked_at FROM campaigns c
JOIN campaign_urls cu USING(campaign_id) JOIN urls u USING(url_id);
-- J05: classifications and who assigned them.
SELECT u.display_url,c.name,a.display_name AS assigned_by FROM url_category_map m
JOIN urls u USING(url_id) JOIN url_categories c USING(category_id)
JOIN users a ON a.user_id=m.assigned_by;

-- G01: report count by workflow status.
SELECT workflow_status,count(*) AS reports FROM report_refs GROUP BY workflow_status;
-- G02: distinct reporting users per URL; avoids counting one user repeatedly.
SELECT url_id,count(DISTINCT reporter_id) AS reporters FROM report_refs
WHERE workflow_status='accepted' AND sync_status='synced' GROUP BY url_id;
-- G03: vote distribution by URL and verdict.
SELECT url_id,verdict,count(*) AS votes FROM votes GROUP BY url_id,verdict;
-- G04: daily new URLs using a stated UTC reporting boundary.
SELECT (first_seen_at AT TIME ZONE 'UTC')::date AS day,count(*) AS urls
FROM urls GROUP BY day ORDER BY day;
-- G05: current risk distribution (one current score per URL).
SELECT label,count(*) AS urls,round(avg(score),2) AS average_score
FROM v_current_risk GROUP BY label;

-- H01: URLs with at least two independent accepted reporters.
SELECT url_id,count(DISTINCT reporter_id) AS reporters FROM report_refs
WHERE workflow_status='accepted' AND sync_status='synced'
GROUP BY url_id HAVING count(DISTINCT reporter_id)>=2;
-- H02: users who have voted on at least two URLs.
SELECT user_id,count(*) AS votes FROM votes GROUP BY user_id HAVING count(*)>=2;
-- H03: hostnames associated with at least two distinct stored URLs.
SELECT hostname,count(*) AS urls FROM urls GROUP BY hostname HAVING count(*)>=2;
-- H04: campaigns containing at least two URLs.
SELECT campaign_id,count(*) AS urls FROM campaign_urls
GROUP BY campaign_id HAVING count(*)>=2;
-- H05: contested URLs with both safe and malicious votes.
SELECT url_id,count(*) AS votes FROM votes GROUP BY url_id
HAVING bool_or(verdict=1) AND bool_or(verdict=-1);

-- Q01: URLs with no votes (correlated NOT EXISTS).
SELECT u.url_id,u.display_url FROM urls u
WHERE NOT EXISTS (SELECT 1 FROM votes v WHERE v.url_id=u.url_id);
-- Q02: URLs above the current population mean score (scalar subquery).
SELECT url_id,score FROM v_current_risk
WHERE score>(SELECT avg(score) FROM v_current_risk);
-- Q03: users who have submitted an accepted report (correlated EXISTS).
SELECT u.user_id,u.display_name FROM users u
WHERE EXISTS (SELECT 1 FROM report_refs r
 WHERE r.reporter_id=u.user_id AND r.workflow_status='accepted' AND r.sync_status='synced');
-- Q04: URLs belonging to a confirmed campaign (IN subquery).
SELECT url_id,display_url FROM urls WHERE url_id IN (
 SELECT cu.url_id FROM campaign_urls cu JOIN campaigns c USING(campaign_id)
 WHERE c.status='confirmed');
-- Q05: most recent report time for every URL, including NULL when absent.
SELECT u.url_id,u.display_url,
 (SELECT max(r.created_at) FROM report_refs r WHERE r.url_id=u.url_id) AS last_report
FROM urls u;
