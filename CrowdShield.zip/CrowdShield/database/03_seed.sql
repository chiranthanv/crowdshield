-- Invented full-reference fixtures include optional campaigns/alerts; they do
-- not represent completed application features or real detection results.
-- Small, invented demonstration fixture. All domains use reserved .example.
-- Demo users cannot log in; replace DISABLED hashes only through registration.
BEGIN;
INSERT INTO roles(name,description) VALUES
('user','Community participant'),('moderator','Evidence and content reviewer'),
('admin','Role and operational administrator');
INSERT INTO users(user_id,email,display_name,password_hash,email_verified_at)
VALUES
('00000000-0000-4000-8000-000000000001','alice@example.test','Alice','DISABLED',now()),
('00000000-0000-4000-8000-000000000002','bob@example.test','Bob','DISABLED',now()),
('00000000-0000-4000-8000-000000000003','carol@example.test','Carol','DISABLED',now()),
('00000000-0000-4000-8000-000000000004','mod@example.test','Reviewer','DISABLED',now()),
('00000000-0000-4000-8000-000000000005','admin@example.test','Administrator','DISABLED',now());
INSERT INTO user_roles(user_id,role_id) SELECT u.user_id,r.role_id FROM users u CROSS JOIN roles r WHERE r.name='user';
INSERT INTO user_roles(user_id,role_id) SELECT '00000000-0000-4000-8000-000000000004',role_id FROM roles WHERE name='moderator';
INSERT INTO user_roles(user_id,role_id) SELECT '00000000-0000-4000-8000-000000000005',role_id FROM roles WHERE name='admin';
INSERT INTO url_categories(name,description) VALUES
('Parcel scam','Delivery and redelivery payment impersonation'),
('Credential phishing','Attempts to obtain account credentials'),
('Financial scam','Misleading investment and payment demands');
INSERT INTO urls(url_id,canonical_url,hostname,display_url,public_summary,submitted_by) VALUES
('00000000-0000-4000-8000-000000000101','https://parcel-check.example/verify','parcel-check.example','hxxps://parcel-check[.]example/verify','Parcel payment verification request','00000000-0000-4000-8000-000000000001'),
('00000000-0000-4000-8000-000000000102','https://parcel-check.example/pay','parcel-check.example','hxxps://parcel-check[.]example/pay','Parcel redelivery fee demand','00000000-0000-4000-8000-000000000002'),
('00000000-0000-4000-8000-000000000103','https://college.example/help','college.example','hxxps://college[.]example/help','College help information','00000000-0000-4000-8000-000000000003'),
('00000000-0000-4000-8000-000000000104','https://new-site.example/','new-site.example','hxxps://new-site[.]example/','Recently submitted URL','00000000-0000-4000-8000-000000000001');
INSERT INTO url_category_map(url_id,category_id,assigned_by)
SELECT u.url_id,c.category_id,'00000000-0000-4000-8000-000000000004'
FROM urls u CROSS JOIN url_categories c WHERE u.hostname='parcel-check.example' AND c.name='Parcel scam';
INSERT INTO votes(user_id,url_id,verdict) VALUES
('00000000-0000-4000-8000-000000000001','00000000-0000-4000-8000-000000000101',1),
('00000000-0000-4000-8000-000000000002','00000000-0000-4000-8000-000000000101',1),
('00000000-0000-4000-8000-000000000003','00000000-0000-4000-8000-000000000101',-1),
('00000000-0000-4000-8000-000000000001','00000000-0000-4000-8000-000000000102',1);
INSERT INTO report_refs(report_id,url_id,reporter_id,report_type,workflow_status,sync_status,idempotency_key,request_hash) VALUES
('00000000-0000-4000-8000-000000000201','00000000-0000-4000-8000-000000000101','00000000-0000-4000-8000-000000000001','scam_message','accepted','synced','00000000-0000-4000-8000-000000000901',digest('seed request 901','sha256')),
('00000000-0000-4000-8000-000000000202','00000000-0000-4000-8000-000000000101','00000000-0000-4000-8000-000000000002','phishing','accepted','synced','00000000-0000-4000-8000-000000000902',digest('seed request 902','sha256')),
('00000000-0000-4000-8000-000000000203','00000000-0000-4000-8000-000000000102','00000000-0000-4000-8000-000000000003','scam_message','pending','synced','00000000-0000-4000-8000-000000000903',digest('seed request 903','sha256'));
INSERT INTO reputation_events(user_id,delta,reason,dedupe_key,awarded_by)
VALUES('00000000-0000-4000-8000-000000000001',10,'Verified contribution','demo-reputation-1','00000000-0000-4000-8000-000000000004');
INSERT INTO campaigns(campaign_id,name,status,created_by)
VALUES('00000000-0000-4000-8000-000000000301','Parcel redelivery impersonation','confirmed','00000000-0000-4000-8000-000000000004');
INSERT INTO campaign_urls(campaign_id,url_id,linked_by,link_reason)
SELECT '00000000-0000-4000-8000-000000000301',url_id,'00000000-0000-4000-8000-000000000004','Shared wording and host pattern in demo evidence'
FROM urls WHERE hostname='parcel-check.example';
INSERT INTO moderator_actions(moderator_id,url_id,action_kind,verdict,reason,valid_until) VALUES
('00000000-0000-4000-8000-000000000004','00000000-0000-4000-8000-000000000102','set_verdict','malicious','Reviewed invented parcel impersonation evidence',now()+interval '30 days'),
('00000000-0000-4000-8000-000000000004','00000000-0000-4000-8000-000000000103','set_verdict','safe','Reviewed invented college ownership evidence',now()+interval '30 days');
INSERT INTO similarity_edges(url_id,neighbor_url_id,model_version,similarity)
VALUES('00000000-0000-4000-8000-000000000101','00000000-0000-4000-8000-000000000102','minilm-l6-v2:project-v1',0.84);
-- 0.84 is a made-up fixture for exercising scoring, not a measured embedding result.
INSERT INTO alerts(user_id,url_id,threshold) VALUES
('00000000-0000-4000-8000-000000000001','00000000-0000-4000-8000-000000000101',70);
CALL recalculate_risk('00000000-0000-4000-8000-000000000101');
CALL recalculate_risk('00000000-0000-4000-8000-000000000102');
CALL recalculate_risk('00000000-0000-4000-8000-000000000103');
CALL recalculate_risk('00000000-0000-4000-8000-000000000104');
COMMIT;
