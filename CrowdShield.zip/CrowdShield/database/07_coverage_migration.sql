-- Optional upgrade ONLY for the previous CrowdShield schema with confidence.
-- Fresh installations use 01_schema.sql and do not need this migration.
-- Not executed here. Back up and rehearse on a copy; stop API/worker during change.
-- No score values, algorithm weights or history rows are rewritten.
BEGIN;
ALTER TABLE risk_scores RENAME COLUMN confidence TO coverage;
ALTER TABLE risk_scores RENAME CONSTRAINT risk_scores_confidence_check
  TO risk_scores_coverage_check;
ALTER VIEW v_current_risk RENAME COLUMN confidence TO coverage;
ALTER VIEW v_url_summary RENAME COLUMN confidence TO coverage;
CREATE OR REPLACE PROCEDURE recalculate_risk(p_url uuid) LANGUAGE plpgsql AS $$
DECLARE
  v_community double precision; v_reports double precision;
  v_similarity double precision; v_score numeric; v_coverage numeric;
  v_malicious_weight double precision; v_safe_weight double precision;
  v_report_weight double precision; v_anchor_ids jsonb;
  v_contributors integer; v_anchors integer; v_verdict text;
  v_label text; v_id bigint;
BEGIN
  PERFORM 1 FROM urls WHERE url_id=p_url FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Unknown URL'; END IF;
  SELECT (1.0+coalesce(sum((0.5+r.reputation/100.0)*
           CASE WHEN v.verdict=1 THEN 1 ELSE 0 END),0)) /
         (2.0+coalesce(sum(0.5+r.reputation/100.0),0)),
         coalesce(sum((0.5+r.reputation/100.0)*CASE WHEN v.verdict=1 THEN 1 ELSE 0 END),0),
         coalesce(sum((0.5+r.reputation/100.0)*CASE WHEN v.verdict=-1 THEN 1 ELSE 0 END),0)
  INTO v_community,v_malicious_weight,v_safe_weight
  FROM votes v JOIN users u USING(user_id) JOIN v_user_reputation r USING(user_id)
  WHERE v.url_id=p_url AND u.status='active' AND u.email_verified_at IS NOT NULL;

  SELECT 1.0-exp(-coalesce(sum(contribution),0)/5.0),coalesce(sum(contribution),0)
  INTO v_reports,v_report_weight
  FROM (
    SELECT rr.reporter_id,
      max((0.5+r.reputation/100.0)*exp(-extract(epoch FROM
        (now()-rr.created_at))/86400.0/30.0)) AS contribution
    FROM report_refs rr JOIN users u ON u.user_id=rr.reporter_id
    JOIN v_user_reputation r ON r.user_id=rr.reporter_id
    WHERE rr.url_id=p_url AND rr.workflow_status='accepted' AND rr.sync_status='synced'
      AND rr.created_at BETWEEN now()-interval '30 days' AND now()
      AND u.status='active' AND u.email_verified_at IS NOT NULL
    GROUP BY rr.reporter_id
  ) distinct_reporters;

  WITH anchors AS (
    SELECT e.neighbor_url_id, e.similarity, m.verdict
    FROM similarity_edges e JOIN v_effective_verdict m ON m.url_id=e.neighbor_url_id
    JOIN urls neighbor ON neighbor.url_id=e.neighbor_url_id
    WHERE e.url_id=p_url AND e.similarity >= 0.75
      AND e.model_version='minilm-l6-v2:project-v1'
      AND e.computed_at >= now()-interval '7 days'
      AND m.verdict IN ('safe','malicious') AND NOT neighbor.is_archived
    ORDER BY e.similarity DESC,e.neighbor_url_id LIMIT 5
  )
  SELECT coalesce(sum(similarity*CASE WHEN verdict='malicious' THEN 1 ELSE 0 END)
            /nullif(sum(similarity),0),0.5), count(*),
         coalesce(jsonb_agg(jsonb_build_object('url_id',neighbor_url_id,
           'similarity',similarity,'verdict',verdict)),'[]'::jsonb)
    INTO v_similarity,v_anchors,v_anchor_ids FROM anchors;

  SELECT count(*) INTO v_contributors FROM (
    SELECT v.user_id FROM votes v JOIN users u USING(user_id)
    WHERE v.url_id=p_url AND u.status='active' AND u.email_verified_at IS NOT NULL
    UNION
    SELECT rr.reporter_id FROM report_refs rr JOIN users u ON u.user_id=rr.reporter_id
    WHERE rr.url_id=p_url AND rr.workflow_status='accepted' AND rr.sync_status='synced'
      AND rr.created_at BETWEEN now()-interval '30 days' AND now()
      AND u.status='active' AND u.email_verified_at IS NOT NULL
  ) contributors;
  SELECT verdict INTO v_verdict FROM v_effective_verdict WHERE url_id=p_url;
  v_score:=round((100*(0.55*v_community+0.25*v_reports+0.20*v_similarity))::numeric,2);
  v_coverage:=least(1.0,(v_contributors+2.0*v_anchors)/10.0);
  IF v_verdict='malicious' THEN v_score:=95; v_coverage:=1;
  ELSIF v_verdict='safe' THEN v_score:=5; v_coverage:=1; END IF;
  v_label:=CASE WHEN v_coverage<0.3 THEN 'insufficient_evidence'
    WHEN v_score>=70 THEN 'high' WHEN v_score>=40 THEN 'medium' ELSE 'low' END;
  INSERT INTO risk_scores(url_id,score,coverage,label,community_component,
    report_component,similarity_component,moderator_verdict,algorithm_version,inputs)
  VALUES(p_url,v_score,v_coverage,v_label,v_community,v_reports,v_similarity,v_verdict,
    'crowdshield-v1',jsonb_build_object('distinct_contributors',v_contributors,
      'anchors',v_anchors,'anchor_evidence',v_anchor_ids,
      'malicious_vote_weight',v_malicious_weight,'safe_vote_weight',v_safe_weight,
      'accepted_report_weight',v_report_weight,
      'evidence_version',(SELECT evidence_version FROM urls WHERE url_id=p_url),
      'window_days',30,'model','minilm-l6-v2:project-v1'))
  RETURNING risk_score_id INTO v_id;

  -- Only alert when crossing from below to at/above threshold.
  INSERT INTO notifications(user_id,alert_id,risk_score_id,kind,message)
  SELECT a.user_id,a.alert_id,v_id,'risk_threshold','A watched URL crossed your risk threshold.'
  FROM alerts a LEFT JOIN risk_scores prev ON prev.risk_score_id=a.last_evaluated_score_id
  WHERE a.url_id=p_url AND a.enabled AND v_coverage>=0.3 AND v_score>=a.threshold
    AND (prev.score IS NULL OR prev.score<a.threshold OR prev.coverage<0.3)
  ON CONFLICT(alert_id,risk_score_id) DO NOTHING;
  UPDATE alerts SET last_evaluated_score_id=v_id WHERE url_id=p_url AND enabled;
END $$;
COMMIT;
