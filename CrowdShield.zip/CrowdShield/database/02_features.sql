-- Core views/trigger and reusable procedure helpers. The notification block is
-- enhanced and remains idle when no alerts are enabled. SQL execution is pending.
BEGIN;
CREATE VIEW v_user_reputation AS
SELECT u.user_id,
  greatest(0, least(100, 20 + coalesce(sum(e.delta),0)))::integer AS reputation
FROM users u LEFT JOIN reputation_events e USING (user_id)
GROUP BY u.user_id;

CREATE VIEW v_current_risk AS
SELECT DISTINCT ON (url_id) * FROM risk_scores
ORDER BY url_id, computed_at DESC, risk_score_id DESC;

-- Latest decision wins, including clear; expiry never revives older decisions.
CREATE VIEW v_effective_verdict AS
SELECT url_id,
  CASE WHEN verdict <> 'clear'
       AND (valid_until IS NULL OR valid_until > now())
       THEN verdict END AS verdict,
  action_id, created_at, valid_until
FROM (
  SELECT DISTINCT ON (url_id) * FROM moderator_actions
  WHERE action_kind = 'set_verdict'
  ORDER BY url_id, created_at DESC, action_id DESC
) latest;

CREATE VIEW v_url_summary AS
SELECT u.url_id, u.hostname, u.display_url, u.first_seen_at,
       r.score, r.label, r.coverage, r.computed_at,
       coalesce(v.vote_count,0) AS vote_count,
       coalesce(p.accepted_reports,0) AS accepted_reports
FROM urls u
LEFT JOIN v_current_risk r USING (url_id)
LEFT JOIN (SELECT url_id, count(*) AS vote_count FROM votes GROUP BY url_id) v USING (url_id)
LEFT JOIN (SELECT url_id, count(*) AS accepted_reports FROM report_refs
           WHERE workflow_status='accepted' AND sync_status='synced'
           GROUP BY url_id) p USING (url_id)
WHERE NOT u.is_archived;
-- Aggregate child tables separately to avoid votes x reports multiplication.

CREATE FUNCTION audit_vote_change() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE v_user uuid; v_url uuid; v_verdict smallint; v_version integer;
BEGIN
  IF TG_OP='DELETE' THEN
    v_user:=OLD.user_id; v_url:=OLD.url_id; v_verdict:=OLD.verdict;
  ELSE
    v_user:=NEW.user_id; v_url:=NEW.url_id; v_verdict:=NEW.verdict;
  END IF;
  INSERT INTO audit_logs(actor_id,action,entity_type,entity_id,details)
  VALUES (v_user,'vote.'||lower(TG_OP),'url',v_url::text,
    jsonb_build_object('verdict',v_verdict));
  UPDATE urls SET evidence_version=evidence_version+1
  WHERE url_id=v_url RETURNING evidence_version INTO v_version;
  INSERT INTO outbox_events(event_type,aggregate_id,aggregate_version,payload)
  VALUES('risk.refresh',v_url,v_version,'{}');
  IF TG_OP='DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END $$;

CREATE TRIGGER vote_audit AFTER INSERT OR UPDATE OR DELETE ON votes
FOR EACH ROW EXECUTE FUNCTION audit_vote_change();

CREATE PROCEDURE moderate_report(
  p_report uuid, p_moderator uuid, p_accept boolean, p_reason text
) LANGUAGE plpgsql AS $$
DECLARE r report_refs%ROWTYPE;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM users u
    JOIN user_roles ur USING(user_id) JOIN roles ro USING(role_id)
    WHERE u.user_id=p_moderator AND u.status='active'
      AND ro.name IN ('moderator','admin')) THEN
    RAISE EXCEPTION 'Moderator permission required';
  END IF;
  SELECT * INTO STRICT r FROM report_refs WHERE report_id=p_report FOR UPDATE;
  IF r.sync_status <> 'synced' OR r.workflow_status <> 'pending' THEN
    RAISE EXCEPTION 'Review requires a pending report with synchronized content';
  END IF;
  IF r.reporter_id=p_moderator THEN RAISE EXCEPTION 'Cannot review own report'; END IF;
  INSERT INTO moderator_actions(moderator_id,report_id,action_kind,reason)
  VALUES(p_moderator,p_report,
    CASE WHEN p_accept THEN 'accept_report' ELSE 'reject_report' END,p_reason);
  UPDATE report_refs SET
    workflow_status=CASE WHEN p_accept THEN 'accepted' ELSE 'rejected' END,
    content_version=content_version+1, sync_status='pending', updated_at=now()
  WHERE report_id=p_report;
  INSERT INTO outbox_events(event_type,aggregate_id,aggregate_version,payload)
  SELECT 'report.status',report_id,content_version,
    jsonb_build_object('workflow_status',workflow_status)
  FROM report_refs WHERE report_id=p_report;
  INSERT INTO audit_logs(actor_id,action,entity_type,entity_id)
  VALUES(p_moderator,'report.review','report',p_report::text);
END $$;

CREATE PROCEDURE recalculate_risk(p_url uuid) LANGUAGE plpgsql AS $$
DECLARE
  v_community double precision; v_reports double precision;
  v_similarity double precision; v_score numeric; v_coverage numeric;
  v_malicious_weight double precision; v_safe_weight double precision;
  v_report_weight double precision; v_anchor_ids jsonb;
  v_contributors integer; v_anchors integer; v_verdict text;
  v_label text; v_id bigint;
BEGIN
  PERFORM 1 FROM urls WHERE url_id=p_url FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Unknown URL'; END IF;
  SELECT (1.0+coalesce(sum((0.5+r.reputation/100.0)*
           CASE WHEN v.verdict=1 THEN 1 ELSE 0 END),0)) /
         (2.0+coalesce(sum(0.5+r.reputation/100.0),0)),
         coalesce(sum((0.5+r.reputation/100.0)*CASE WHEN v.verdict=1 THEN 1 ELSE 0 END),0),
         coalesce(sum((0.5+r.reputation/100.0)*CASE WHEN v.verdict=-1 THEN 1 ELSE 0 END),0)
  INTO v_community,v_malicious_weight,v_safe_weight
  FROM votes v JOIN users u USING(user_id) JOIN v_user_reputation r USING(user_id)
  WHERE v.url_id=p_url AND u.status='active' AND u.email_verified_at IS NOT NULL;

  SELECT 1.0-exp(-coalesce(sum(contribution),0)/5.0),coalesce(sum(contribution),0)
  INTO v_reports,v_report_weight
  FROM (
    SELECT rr.reporter_id,
      max((0.5+r.reputation/100.0)*exp(-extract(epoch FROM
        (now()-rr.created_at))/86400.0/30.0)) AS contribution
    FROM report_refs rr JOIN users u ON u.user_id=rr.reporter_id
    JOIN v_user_reputation r ON r.user_id=rr.reporter_id
    WHERE rr.url_id=p_url AND rr.workflow_status='accepted' AND rr.sync_status='synced'
      AND rr.created_at BETWEEN now()-interval '30 days' AND now()
      AND u.status='active' AND u.email_verified_at IS NOT NULL
    GROUP BY rr.reporter_id
  ) distinct_reporters;

  WITH anchors AS (
    SELECT e.neighbor_url_id, e.similarity, m.verdict
    FROM similarity_edges e JOIN v_effective_verdict m ON m.url_id=e.neighbor_url_id
    JOIN urls neighbor ON neighbor.url_id=e.neighbor_url_id
    WHERE e.url_id=p_url AND e.similarity >= 0.75
      AND e.model_version='minilm-l6-v2:project-v1'
      AND e.computed_at >= now()-interval '7 days'
      AND m.verdict IN ('safe','malicious') AND NOT neighbor.is_archived
    ORDER BY e.similarity DESC,e.neighbor_url_id LIMIT 5
  )
  SELECT coalesce(sum(similarity*CASE WHEN verdict='malicious' THEN 1 ELSE 0 END)
            /nullif(sum(similarity),0),0.5), count(*),
         coalesce(jsonb_agg(jsonb_build_object('url_id',neighbor_url_id,
           'similarity',similarity,'verdict',verdict)),'[]'::jsonb)
    INTO v_similarity,v_anchors,v_anchor_ids FROM anchors;

  SELECT count(*) INTO v_contributors FROM (
    SELECT v.user_id FROM votes v JOIN users u USING(user_id)
    WHERE v.url_id=p_url AND u.status='active' AND u.email_verified_at IS NOT NULL
    UNION
    SELECT rr.reporter_id FROM report_refs rr JOIN users u ON u.user_id=rr.reporter_id
    WHERE rr.url_id=p_url AND rr.workflow_status='accepted' AND rr.sync_status='synced'
      AND rr.created_at BETWEEN now()-interval '30 days' AND now()
      AND u.status='active' AND u.email_verified_at IS NOT NULL
  ) contributors;
  SELECT verdict INTO v_verdict FROM v_effective_verdict WHERE url_id=p_url;
  v_score:=round((100*(0.55*v_community+0.25*v_reports+0.20*v_similarity))::numeric,2);
  v_coverage:=least(1.0,(v_contributors+2.0*v_anchors)/10.0);
  IF v_verdict='malicious' THEN v_score:=95; v_coverage:=1;
  ELSIF v_verdict='safe' THEN v_score:=5; v_coverage:=1; END IF;
  v_label:=CASE WHEN v_coverage<0.3 THEN 'insufficient_evidence'
    WHEN v_score>=70 THEN 'high' WHEN v_score>=40 THEN 'medium' ELSE 'low' END;
  INSERT INTO risk_scores(url_id,score,coverage,label,community_component,
    report_component,similarity_component,moderator_verdict,algorithm_version,inputs)
  VALUES(p_url,v_score,v_coverage,v_label,v_community,v_reports,v_similarity,v_verdict,
    'crowdshield-v1',jsonb_build_object('distinct_contributors',v_contributors,
      'anchors',v_anchors,'anchor_evidence',v_anchor_ids,
      'malicious_vote_weight',v_malicious_weight,'safe_vote_weight',v_safe_weight,
      'accepted_report_weight',v_report_weight,
      'evidence_version',(SELECT evidence_version FROM urls WHERE url_id=p_url),
      'window_days',30,'model','minilm-l6-v2:project-v1'))
  RETURNING risk_score_id INTO v_id;

  -- Only alert when crossing from below to at/above threshold.
  INSERT INTO notifications(user_id,alert_id,risk_score_id,kind,message)
  SELECT a.user_id,a.alert_id,v_id,'risk_threshold','A watched URL crossed your risk threshold.'
  FROM alerts a LEFT JOIN risk_scores prev ON prev.risk_score_id=a.last_evaluated_score_id
  WHERE a.url_id=p_url AND a.enabled AND v_coverage>=0.3 AND v_score>=a.threshold
    AND (prev.score IS NULL OR prev.score<a.threshold OR prev.coverage<0.3)
  ON CONFLICT(alert_id,risk_score_id) DO NOTHING;
  UPDATE alerts SET last_evaluated_score_id=v_id WHERE url_id=p_url AND enabled;
END $$;
COMMIT;

-- Deployment privilege policy (DB role names are examples; configure separately):
-- REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC;
-- REVOKE EXECUTE ON PROCEDURE moderate_report(uuid,uuid,boolean,text) FROM PUBLIC;
-- REVOKE EXECUTE ON PROCEDURE recalculate_risk(uuid) FROM PUBLIC;
-- Give the backend only needed table operations, no DDL; use separate worker
-- and migration roles. Revoke UPDATE/DELETE on audit_logs, risk_scores,
-- reputation_events, moderator_actions from app and worker roles.
-- These are SECURITY INVOKER routines: callers need underlying privileges.
-- Backend supplies authenticated actor IDs; a browser cannot call SQL directly.
