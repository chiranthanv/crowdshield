-- Reference schema: 17 core tables plus 5 optional tables. See scope_manifest.json.
-- CrowdShield: PostgreSQL 16+ with pgvector 0.8+.
-- Run once in an empty project database as the migration owner.
BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE roles (
  role_id smallint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name varchar(20) NOT NULL UNIQUE
    CHECK (name IN ('user','moderator','admin')),
  description text NOT NULL
);
CREATE TABLE users (
  user_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email varchar(254) NOT NULL,
  display_name varchar(80) NOT NULL CHECK (length(trim(display_name)) > 0),
  password_hash text NOT NULL,
  status varchar(16) NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','suspended','deleted')),
  email_verified_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (email = lower(trim(email)))
);
CREATE UNIQUE INDEX users_email_uq ON users(email);
CREATE TABLE user_roles (
  user_id uuid REFERENCES users(user_id) ON DELETE CASCADE,
  role_id smallint REFERENCES roles(role_id),
  granted_by uuid REFERENCES users(user_id),
  granted_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, role_id)
);
CREATE TABLE url_categories (
  category_id smallint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name varchar(60) NOT NULL UNIQUE,
  description text NOT NULL
);
CREATE TABLE urls (
  url_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  canonical_url text NOT NULL
    CHECK (length(canonical_url) BETWEEN 8 AND 8192),
  canonical_hash bytea GENERATED ALWAYS AS
    (digest(canonical_url, 'sha256')) STORED UNIQUE,
  hostname varchar(253) NOT NULL,
  display_url text NOT NULL,
  public_summary text NOT NULL DEFAULT '',
  evidence_version integer NOT NULL DEFAULT 1 CHECK (evidence_version > 0),
  submitted_by uuid NOT NULL REFERENCES users(user_id),
  is_archived boolean NOT NULL DEFAULT false,
  first_seen_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  search_vector tsvector GENERATED ALWAYS AS
    (to_tsvector('simple', hostname || ' ' || public_summary)) STORED,
  CHECK (canonical_url ~ '^https?://'),
  CHECK (hostname = lower(hostname)),
  CHECK (last_seen_at >= first_seen_at)
);
CREATE TABLE url_category_map (
  url_id uuid REFERENCES urls(url_id),
  category_id smallint REFERENCES url_categories(category_id),
  assigned_by uuid NOT NULL REFERENCES users(user_id),
  assigned_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (url_id, category_id)
);
CREATE TABLE votes (
  user_id uuid REFERENCES users(user_id),
  url_id uuid REFERENCES urls(url_id),
  verdict smallint NOT NULL CHECK (verdict IN (-1,1)),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, url_id)
);
-- 1 means malicious, -1 means safe. One editable vote per user and URL.
CREATE TABLE report_refs (
  report_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url_id uuid NOT NULL REFERENCES urls(url_id),
  reporter_id uuid NOT NULL REFERENCES users(user_id),
  report_type varchar(24) NOT NULL
    CHECK (report_type IN ('phishing','scam_message','other')),
  workflow_status varchar(16) NOT NULL DEFAULT 'pending'
    CHECK (workflow_status IN ('pending','accepted','rejected','withdrawn')),
  sync_status varchar(16) NOT NULL DEFAULT 'pending'
    CHECK (sync_status IN ('pending','synced','failed')),
  content_version integer NOT NULL DEFAULT 1 CHECK (content_version > 0),
  idempotency_key uuid NOT NULL,
  request_hash bytea NOT NULL CHECK (octet_length(request_hash) = 32),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (reporter_id, idempotency_key),
  UNIQUE (report_id, url_id)
);
-- MongoDB scam_reports._id equals report_id as a UUID string.
CREATE TABLE reputation_events (
  event_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(user_id),
  delta smallint NOT NULL CHECK (delta BETWEEN -20 AND 20 AND delta <> 0),
  reason varchar(100) NOT NULL,
  dedupe_key varchar(120) NOT NULL UNIQUE,
  awarded_by uuid REFERENCES users(user_id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE campaigns (
  campaign_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_version integer NOT NULL DEFAULT 1 CHECK (content_version > 0),
  name varchar(150) NOT NULL,
  status varchar(16) NOT NULL DEFAULT 'suspected'
    CHECK (status IN ('suspected','confirmed','closed')),
  created_by uuid NOT NULL REFERENCES users(user_id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE campaign_urls (
  campaign_id uuid REFERENCES campaigns(campaign_id),
  url_id uuid REFERENCES urls(url_id),
  linked_by uuid NOT NULL REFERENCES users(user_id),
  link_reason text NOT NULL,
  linked_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (campaign_id, url_id)
);
CREATE TABLE moderator_actions (
  action_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  moderator_id uuid NOT NULL REFERENCES users(user_id),
  url_id uuid REFERENCES urls(url_id),
  report_id uuid REFERENCES report_refs(report_id),
  action_kind varchar(24) NOT NULL
    CHECK (action_kind IN ('set_verdict','accept_report','reject_report')),
  verdict varchar(12) CHECK (verdict IN ('safe','malicious','clear')),
  reason text NOT NULL CHECK (length(trim(reason)) >= 10),
  valid_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK ((action_kind = 'set_verdict' AND url_id IS NOT NULL
          AND report_id IS NULL AND verdict IS NOT NULL)
    OR (action_kind IN ('accept_report','reject_report')
        AND report_id IS NOT NULL AND url_id IS NULL
        AND verdict IS NULL AND valid_until IS NULL)),
  CHECK (valid_until IS NULL OR valid_until > created_at)
);
CREATE TABLE risk_scores (
  risk_score_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  url_id uuid NOT NULL REFERENCES urls(url_id),
  score numeric(5,2) NOT NULL CHECK (score BETWEEN 0 AND 100),
  coverage numeric(5,4) NOT NULL CHECK (coverage BETWEEN 0 AND 1),
  label varchar(24) NOT NULL
    CHECK (label IN ('insufficient_evidence','low','medium','high')),
  community_component numeric(6,5) NOT NULL
    CHECK (community_component BETWEEN 0 AND 1),
  report_component numeric(6,5) NOT NULL
    CHECK (report_component BETWEEN 0 AND 1),
  similarity_component numeric(6,5) NOT NULL
    CHECK (similarity_component BETWEEN 0 AND 1),
  moderator_verdict varchar(12)
    CHECK (moderator_verdict IN ('safe','malicious')),
  algorithm_version varchar(30) NOT NULL,
  inputs jsonb NOT NULL CHECK (jsonb_typeof(inputs) = 'object'),
  computed_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE alerts (
  alert_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(user_id),
  url_id uuid NOT NULL REFERENCES urls(url_id),
  threshold smallint NOT NULL DEFAULT 70 CHECK (threshold BETWEEN 1 AND 100),
  enabled boolean NOT NULL DEFAULT true,
  last_evaluated_score_id bigint REFERENCES risk_scores(risk_score_id),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, url_id)
);
CREATE TABLE notifications (
  notification_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(user_id),
  alert_id uuid REFERENCES alerts(alert_id) ON DELETE SET NULL,
  risk_score_id bigint REFERENCES risk_scores(risk_score_id),
  kind varchar(30) NOT NULL,
  message varchar(500) NOT NULL,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (alert_id, risk_score_id)
);
CREATE TABLE audit_logs (
  audit_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  actor_id uuid REFERENCES users(user_id),
  action varchar(60) NOT NULL,
  entity_type varchar(40) NOT NULL,
  entity_id text NOT NULL,
  details jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE refresh_sessions (
  session_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  family_id uuid NOT NULL DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(user_id),
  token_hash bytea NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (expires_at > created_at)
);
CREATE TABLE auth_tokens (
  token_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(user_id),
  purpose varchar(20) NOT NULL
    CHECK (purpose IN ('verify_email','reset_password')),
  token_hash bytea NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  consumed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (expires_at > created_at)
);
CREATE TABLE outbox_events (
  event_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type varchar(50) NOT NULL,
  aggregate_id uuid NOT NULL,
  aggregate_version integer NOT NULL CHECK (aggregate_version > 0),
  payload jsonb NOT NULL CHECK (jsonb_typeof(payload) = 'object'),
  status varchar(16) NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','processing','done','failed')),
  attempts integer NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  available_at timestamptz NOT NULL DEFAULT now(),
  locked_at timestamptz,
  lease_token uuid,
  processed_at timestamptz,
  last_error varchar(300),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (event_type, aggregate_id, aggregate_version)
);
CREATE TABLE ai_analyses (
  analysis_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url_id uuid NOT NULL REFERENCES urls(url_id),
  requested_by uuid NOT NULL REFERENCES users(user_id),
  model_name varchar(120) NOT NULL,
  prompt_version varchar(40) NOT NULL,
  input_hash bytea NOT NULL,
  status varchar(16) NOT NULL DEFAULT 'queued'
    CHECK (status IN ('queued','running','done','failed')),
  output jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  CHECK (status <> 'done' OR (output IS NOT NULL AND completed_at IS NOT NULL))
);
CREATE TABLE embeddings (
  embedding_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url_id uuid NOT NULL REFERENCES urls(url_id),
  report_id uuid,
  source_kind varchar(12) NOT NULL CHECK (source_kind IN ('url','report')),
  model_version varchar(140) NOT NULL,
  content_version integer NOT NULL CHECK (content_version > 0),
  chunk_no integer NOT NULL DEFAULT 0 CHECK (chunk_no >= 0),
  content_hash bytea NOT NULL,
  embedding vector(384) NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (report_id, url_id) REFERENCES report_refs(report_id, url_id),
  CHECK ((source_kind = 'url' AND report_id IS NULL)
    OR (source_kind = 'report' AND report_id IS NOT NULL)),
  CHECK (vector_norm(embedding) > 0)
);
CREATE UNIQUE INDEX embeddings_url_version_uq
  ON embeddings(url_id, model_version, content_version, chunk_no)
  WHERE source_kind = 'url';
CREATE UNIQUE INDEX embeddings_report_version_uq
  ON embeddings(report_id, model_version, content_version, chunk_no)
  WHERE source_kind = 'report';
CREATE TABLE similarity_edges (
  url_id uuid REFERENCES urls(url_id),
  neighbor_url_id uuid REFERENCES urls(url_id),
  model_version varchar(140) NOT NULL,
  similarity numeric(6,5) NOT NULL CHECK (similarity BETWEEN -1 AND 1),
  computed_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (url_id, neighbor_url_id, model_version),
  CHECK (url_id <> neighbor_url_id)
);

CREATE INDEX urls_hostname_idx ON urls(hostname);
CREATE INDEX urls_recent_idx ON urls(first_seen_at DESC);
CREATE INDEX urls_search_gin ON urls USING gin(search_vector);
CREATE INDEX votes_url_idx ON votes(url_id);
CREATE INDEX reports_url_status_idx ON report_refs(url_id, workflow_status, created_at DESC);
CREATE INDEX reports_reporter_idx ON report_refs(reporter_id, created_at DESC);
CREATE INDEX reputation_user_idx ON reputation_events(user_id);
CREATE INDEX campaign_urls_url_idx ON campaign_urls(url_id);
CREATE INDEX moderation_url_latest_idx ON moderator_actions(url_id, created_at DESC, action_id DESC);
CREATE INDEX risk_latest_idx ON risk_scores(url_id, computed_at DESC, risk_score_id DESC);
CREATE INDEX alerts_url_idx ON alerts(url_id) WHERE enabled;
CREATE INDEX notifications_unread_idx ON notifications(user_id, created_at DESC) WHERE read_at IS NULL;
CREATE INDEX outbox_ready_idx ON outbox_events(status, available_at);
CREATE INDEX audit_actor_idx ON audit_logs(actor_id, created_at DESC);
CREATE INDEX sessions_family_idx ON refresh_sessions(family_id);
CREATE INDEX embeddings_cosine_hnsw ON embeddings USING hnsw (embedding vector_cosine_ops);
COMMIT;
