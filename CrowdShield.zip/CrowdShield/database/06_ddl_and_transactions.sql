-- Safe ALTER and DROP demonstration; leaves the real schema unchanged.
BEGIN;
CREATE TABLE ddl_demo (id integer PRIMARY KEY, label text);
ALTER TABLE ddl_demo ADD COLUMN created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE ddl_demo ADD CONSTRAINT label_not_blank CHECK(length(trim(label))>0);
CREATE INDEX ddl_demo_label_idx ON ddl_demo(label);
DROP TABLE ddl_demo;
ROLLBACK;

-- Run after seed. An authenticated backend checks ownership and verified status.
BEGIN;
INSERT INTO votes(user_id,url_id,verdict)
VALUES('00000000-0000-4000-8000-000000000001',
       '00000000-0000-4000-8000-000000000101',1)
ON CONFLICT(user_id,url_id) DO UPDATE SET verdict=EXCLUDED.verdict,updated_at=now();
-- Vote and AFTER trigger audit insertion commit or roll back together.
COMMIT;

-- A consistent score snapshot; retry SQLSTATE 40001 on concurrent changes.
BEGIN ISOLATION LEVEL REPEATABLE READ;
CALL recalculate_risk('00000000-0000-4000-8000-000000000101');
COMMIT;

-- Atomic outbox claim with a lease. Process the returned event after COMMIT.
BEGIN;
WITH chosen AS (
 SELECT event_id FROM outbox_events
 WHERE (status='pending' AND available_at<=now() AND attempts<8)
    OR (status='processing' AND locked_at<now()-interval '5 minutes' AND attempts<8)
 ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT 10
)
UPDATE outbox_events o SET status='processing',locked_at=now(),
  lease_token=gen_random_uuid(),attempts=attempts+1
FROM chosen c WHERE o.event_id=c.event_id
RETURNING o.*;
COMMIT;
-- Worker completion MUST match event_id AND lease_token. Version-conditional
-- Mongo writes prevent a late worker from overwriting a newer report version.

-- Retryable failures return to pending with future available_at and clear the
-- lease, conditional on event_id + lease_token. At attempts=8, park as failed;
-- a controlled operator retry is enhanced. Core demo recovers before this limit.
