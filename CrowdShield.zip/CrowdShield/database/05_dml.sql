-- Run after seed. Every block rolls back, so sample edits are reversible.
-- Parameters in a real API come from a driver, not string concatenation.

-- USERS: four operations on a temporary account.
BEGIN;
INSERT INTO users(user_id,email,display_name,password_hash)
VALUES('00000000-0000-4000-8000-000000009901','demo@example.test','Demo','DISABLED');
UPDATE users SET display_name='Demo Student' WHERE user_id='00000000-0000-4000-8000-000000009901';
SELECT user_id,display_name,status FROM users WHERE user_id='00000000-0000-4000-8000-000000009901';
DELETE FROM users WHERE user_id='00000000-0000-4000-8000-000000009901';
ROLLBACK;

-- ROLES and USER_ROLES: fixed role vocabulary, additive grants.
BEGIN;
INSERT INTO roles(name,description) VALUES('user','Community participant') ON CONFLICT(name) DO NOTHING;
UPDATE roles SET description='Verified community participant' WHERE name='user';
SELECT * FROM roles;
DELETE FROM roles r WHERE name='user' AND NOT EXISTS (SELECT 1 FROM user_roles ur WHERE ur.role_id=r.role_id);
INSERT INTO user_roles(user_id,role_id,granted_by)
SELECT '00000000-0000-4000-8000-000000000003',role_id,'00000000-0000-4000-8000-000000000005' FROM roles WHERE name='moderator';
UPDATE user_roles SET granted_at=now() WHERE user_id='00000000-0000-4000-8000-000000000003';
SELECT * FROM user_roles WHERE user_id='00000000-0000-4000-8000-000000000003';
DELETE FROM user_roles WHERE user_id='00000000-0000-4000-8000-000000000003' AND role_id=(SELECT role_id FROM roles WHERE name='moderator');
ROLLBACK;

-- URLS, URL_CATEGORIES and mapping. Existing real URLs are archived, not deleted.
BEGIN;
INSERT INTO urls(url_id,canonical_url,hostname,display_url,submitted_by)
VALUES('00000000-0000-4000-8000-000000009101','https://demo.example/','demo.example','hxxps://demo[.]example/','00000000-0000-4000-8000-000000000001');
UPDATE urls SET public_summary='Demonstration only' WHERE url_id='00000000-0000-4000-8000-000000009101';
SELECT url_id,display_url FROM urls WHERE url_id='00000000-0000-4000-8000-000000009101';
INSERT INTO url_categories(name,description) VALUES('Demo','Temporary demo category');
UPDATE url_categories SET description='Classroom demonstration' WHERE name='Demo';
SELECT * FROM url_categories WHERE name='Demo';
INSERT INTO url_category_map(url_id,category_id,assigned_by)
SELECT '00000000-0000-4000-8000-000000009101',category_id,'00000000-0000-4000-8000-000000000004' FROM url_categories WHERE name='Demo';
UPDATE url_category_map SET assigned_at=now() WHERE url_id='00000000-0000-4000-8000-000000009101';
SELECT * FROM url_category_map WHERE url_id='00000000-0000-4000-8000-000000009101';
DELETE FROM url_category_map WHERE url_id='00000000-0000-4000-8000-000000009101';
DELETE FROM url_categories WHERE name='Demo';
DELETE FROM urls WHERE url_id='00000000-0000-4000-8000-000000009101';
ROLLBACK;

-- VOTES: upsert changes a verdict instead of allowing duplicate votes.
BEGIN;
INSERT INTO votes(user_id,url_id,verdict)
VALUES('00000000-0000-4000-8000-000000000002','00000000-0000-4000-8000-000000000104',1);
UPDATE votes SET verdict=-1,updated_at=now() WHERE user_id='00000000-0000-4000-8000-000000000002' AND url_id='00000000-0000-4000-8000-000000000104';
SELECT * FROM votes WHERE url_id='00000000-0000-4000-8000-000000000104';
DELETE FROM votes WHERE user_id='00000000-0000-4000-8000-000000000002' AND url_id='00000000-0000-4000-8000-000000000104';
ROLLBACK;

-- REPORT_REFS and OUTBOX_EVENTS must be created in the same transaction.
BEGIN;
INSERT INTO report_refs(report_id,url_id,reporter_id,report_type,idempotency_key,request_hash)
VALUES('00000000-0000-4000-8000-000000009201','00000000-0000-4000-8000-000000000104','00000000-0000-4000-8000-000000000001','scam_message','00000000-0000-4000-8000-000000009902',digest('redacted-demo-request','sha256'));
INSERT INTO outbox_events(event_type,aggregate_id,aggregate_version,payload)
VALUES('report.create','00000000-0000-4000-8000-000000009201',1,'{"message_text":"Redacted demo message"}');
UPDATE report_refs SET sync_status='pending' WHERE report_id='00000000-0000-4000-8000-000000009201';
UPDATE outbox_events SET status='pending',last_error='Retryable demo failure',available_at=now()+interval '30 seconds' WHERE aggregate_id='00000000-0000-4000-8000-000000009201';
SELECT * FROM report_refs WHERE report_id='00000000-0000-4000-8000-000000009201';
SELECT event_type,status FROM outbox_events WHERE aggregate_id='00000000-0000-4000-8000-000000009201';
DELETE FROM outbox_events WHERE aggregate_id='00000000-0000-4000-8000-000000009201';
DELETE FROM report_refs WHERE report_id='00000000-0000-4000-8000-000000009201';
ROLLBACK;

-- CAMPAIGNS and CAMPAIGN_URLS.
BEGIN;
INSERT INTO campaigns(campaign_id,name,created_by) VALUES('00000000-0000-4000-8000-000000009301','Demo campaign','00000000-0000-4000-8000-000000000004');
UPDATE campaigns SET status='closed' WHERE campaign_id='00000000-0000-4000-8000-000000009301';
SELECT * FROM campaigns WHERE campaign_id='00000000-0000-4000-8000-000000009301';
INSERT INTO campaign_urls(campaign_id,url_id,linked_by,link_reason) VALUES('00000000-0000-4000-8000-000000009301','00000000-0000-4000-8000-000000000104','00000000-0000-4000-8000-000000000004','Invented teaching fixture');
UPDATE campaign_urls SET link_reason='Corrected teaching fixture' WHERE campaign_id='00000000-0000-4000-8000-000000009301';
SELECT * FROM campaign_urls WHERE campaign_id='00000000-0000-4000-8000-000000009301';
DELETE FROM campaign_urls WHERE campaign_id='00000000-0000-4000-8000-000000009301';
DELETE FROM campaigns WHERE campaign_id='00000000-0000-4000-8000-000000009301';
ROLLBACK;

-- ALERTS and NOTIFICATIONS.
BEGIN;
INSERT INTO alerts(alert_id,user_id,url_id,threshold) VALUES('00000000-0000-4000-8000-000000009401','00000000-0000-4000-8000-000000000002','00000000-0000-4000-8000-000000000104',70);
UPDATE alerts SET threshold=80 WHERE alert_id='00000000-0000-4000-8000-000000009401';
SELECT * FROM alerts WHERE alert_id='00000000-0000-4000-8000-000000009401';
INSERT INTO notifications(notification_id,user_id,alert_id,kind,message) VALUES('00000000-0000-4000-8000-000000009501','00000000-0000-4000-8000-000000000002','00000000-0000-4000-8000-000000009401','demo','Demonstration notification');
UPDATE notifications SET read_at=now() WHERE notification_id='00000000-0000-4000-8000-000000009501';
SELECT * FROM notifications WHERE notification_id='00000000-0000-4000-8000-000000009501';
DELETE FROM notifications WHERE notification_id='00000000-0000-4000-8000-000000009501';
DELETE FROM alerts WHERE alert_id='00000000-0000-4000-8000-000000009401';
ROLLBACK;

-- REFRESH_SESSIONS and AUTH_TOKENS: raw random tokens never enter these tables.
BEGIN;
INSERT INTO refresh_sessions(session_id,user_id,token_hash,expires_at) VALUES('00000000-0000-4000-8000-000000009601','00000000-0000-4000-8000-000000000001',digest('demo-refresh-only','sha256'),now()+interval '7 days');
UPDATE refresh_sessions SET revoked_at=now() WHERE session_id='00000000-0000-4000-8000-000000009601';
SELECT session_id,expires_at,revoked_at FROM refresh_sessions WHERE session_id='00000000-0000-4000-8000-000000009601';
DELETE FROM refresh_sessions WHERE session_id='00000000-0000-4000-8000-000000009601';
INSERT INTO auth_tokens(token_id,user_id,purpose,token_hash,expires_at) VALUES('00000000-0000-4000-8000-000000009701','00000000-0000-4000-8000-000000000001','verify_email',digest('demo-email-only','sha256'),now()+interval '1 hour');
UPDATE auth_tokens SET consumed_at=now() WHERE token_id='00000000-0000-4000-8000-000000009701';
SELECT token_id,purpose,consumed_at FROM auth_tokens WHERE token_id='00000000-0000-4000-8000-000000009701';
DELETE FROM auth_tokens WHERE token_id='00000000-0000-4000-8000-000000009701';
ROLLBACK;

-- AI_ANALYSES and SIMILARITY_EDGES: derived, replaceable data.
BEGIN;
INSERT INTO ai_analyses(analysis_id,url_id,requested_by,model_name,prompt_version,input_hash) VALUES('00000000-0000-4000-8000-000000009801','00000000-0000-4000-8000-000000000104','00000000-0000-4000-8000-000000000001','configured-provider-model','analysis-v1',digest('redacted-input','sha256'));
UPDATE ai_analyses SET status='done',output='{"summary":"Demo only","limitations":["No live scan"]}',completed_at=now() WHERE analysis_id='00000000-0000-4000-8000-000000009801';
SELECT * FROM ai_analyses WHERE analysis_id='00000000-0000-4000-8000-000000009801';
DELETE FROM ai_analyses WHERE analysis_id='00000000-0000-4000-8000-000000009801';
INSERT INTO similarity_edges(url_id,neighbor_url_id,model_version,similarity) VALUES('00000000-0000-4000-8000-000000000104','00000000-0000-4000-8000-000000000103','minilm-l6-v2:project-v1',0.8);
UPDATE similarity_edges SET similarity=0.81 WHERE url_id='00000000-0000-4000-8000-000000000104';
SELECT * FROM similarity_edges WHERE url_id='00000000-0000-4000-8000-000000000104';
DELETE FROM similarity_edges WHERE url_id='00000000-0000-4000-8000-000000000104';
ROLLBACK;

-- EMBEDDINGS: a synthetic nonzero vector ONLY demonstrates vector datatype DML.
BEGIN;
INSERT INTO embeddings(embedding_id,url_id,source_kind,model_version,content_version,content_hash,embedding)
VALUES('00000000-0000-4000-8000-000000009001','00000000-0000-4000-8000-000000000104','url','synthetic-demo',1,digest('demo','sha256'),array_fill(0.01::real,ARRAY[384])::vector);
UPDATE embeddings SET metadata='{"demo":true}' WHERE embedding_id='00000000-0000-4000-8000-000000009001';
SELECT embedding_id,vector_dims(embedding) AS dimensions FROM embeddings WHERE embedding_id='00000000-0000-4000-8000-000000009001';
DELETE FROM embeddings WHERE embedding_id='00000000-0000-4000-8000-000000009001';
ROLLBACK;

-- Append-only tables: INSERT and SELECT are legitimate operational examples.
BEGIN;
INSERT INTO reputation_events(user_id,delta,reason,dedupe_key) VALUES('00000000-0000-4000-8000-000000000001',1,'Demo reward','temporary-demo-reward');
SELECT * FROM reputation_events WHERE dedupe_key='temporary-demo-reward';
INSERT INTO audit_logs(action,entity_type,entity_id) VALUES('demo','system','temporary-demo');
SELECT * FROM audit_logs WHERE entity_id='temporary-demo';
INSERT INTO moderator_actions(moderator_id,url_id,action_kind,verdict,reason) VALUES('00000000-0000-4000-8000-000000000004','00000000-0000-4000-8000-000000000104','set_verdict','clear','Clear verdict for classroom demonstration');
SELECT * FROM moderator_actions WHERE url_id='00000000-0000-4000-8000-000000000104';
CALL recalculate_risk('00000000-0000-4000-8000-000000000104');
SELECT * FROM v_current_risk WHERE url_id='00000000-0000-4000-8000-000000000104';
ROLLBACK;
-- For audit_logs, reputation_events, moderator_actions and risk_scores,
-- do not UPDATE or DELETE through application credentials. Corrections append
-- compensating records/new versions. Destructive SQL for such tables is omitted
-- deliberately; preserving history is a project integrity requirement.
