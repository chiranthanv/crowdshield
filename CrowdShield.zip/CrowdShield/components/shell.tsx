"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  Shield,
  LayoutDashboard,
  Search,
  Flag,
  ShieldCheck,
  Settings,
  ChartNoAxesCombined,
  LogOut,
  Menu,
  X,
  ArrowUpRight,
} from "lucide-react";
import { api } from "./ui";
export default function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname(),
    router = useRouter();
  const [user, setUser] = useState<any>(null),
    [open, setOpen] = useState(false);
  useEffect(() => {
    api("/me")
      .then((d) => setUser(d.user))
      .catch(() => setUser(null));
    setOpen(false);
  }, [path]);
  const reviewer = user?.roles.some((r: string) =>
      ["admin", "moderator"].includes(r),
    ),
    admin = user?.roles.includes("admin");
  const nav = [
    ["/", "URL intelligence", Search],
    ["/dashboard", "Dashboard", LayoutDashboard],
    ["/report", "Report a scam", Flag],
    ["/analytics", "Analytics", ChartNoAxesCombined],
    ...(reviewer ? [["/moderation", "Moderation", ShieldCheck]] : []),
    ...(admin ? [["/admin", "Administration", Settings]] : []),
  ] as const;
  return (
    <div className="app-shell">
      <aside className={"sidebar " + (open ? "open" : "")}>
        <Link className="brand" href="/">
          <span className="brand-mark">
            <Shield size={24} />
          </span>
          <div>
            CrowdShield<span>COMMUNITY INTELLIGENCE</span>
          </div>
        </Link>
        <button
          className="mobile-close icon-link"
          aria-label="Close navigation"
          onClick={() => setOpen(false)}
        >
          <X />
        </button>
        <div className="nav-caption">WORKSPACE</div>
        <nav>
          {nav.map(([href, label, Icon]) => (
            <Link
              className={
                path === href || (href === "/" && path.startsWith("/urls/"))
                  ? "active"
                  : ""
              }
              href={href as string}
              key={href as string}
            >
              <Icon size={18} />
              {label as string}
              {path === href && <span className="nav-dot" />}
            </Link>
          ))}
        </nav>
        <div className="sidebar-note">
          <span className="live-dot" />
          LOCAL RESEARCH PROJECT
          <p>
            Shared evidence.
            <br />
            Better informed decisions.
          </p>
          <span className="tiny muted">
            DBMS · PostgreSQL + MongoDB + pgvector
          </span>
        </div>
        <div className="profile">
          <div className="avatar">{user?.display_name?.slice(0, 1) || "G"}</div>
          <div>
            <strong>{user?.display_name || "Guest explorer"}</strong>
            <span>
              {user ? user.roles.join(" · ") : "Public intelligence access"}
            </span>
          </div>
          {user && (
            <button
              title="Log out"
              className="icon-link"
              onClick={async () => {
                await api("/auth/logout", { method: "POST" });
                setUser(null);
                router.push("/login");
              }}
            >
              <LogOut size={17} />
            </button>
          )}
        </div>
      </aside>
      <div className="main-shell">
        <div className="topbar">
          <button
            className="mobile-menu icon-link"
            aria-label="Open navigation"
            onClick={() => setOpen(true)}
          >
            <Menu />
          </button>
          <div className="breadcrumb">
            Workspace <span>/</span>{" "}
            <strong>
              {path.startsWith("/urls/")
                ? "URL evidence"
                : (nav.find(([href]) => href === path)?.[1] as string) ||
                  "Account"}
            </strong>
          </div>
          <div className="topbar-right">
            <span className="demo-badge">COLLEGE DEMO</span>
            {!user ? (
              <Link className="button small" href="/login">
                Sign in <ArrowUpRight size={14} />
              </Link>
            ) : (
              <span className="tiny muted">
                {user.email_verified_at
                  ? "Demo account active"
                  : "Activation pending"}
              </span>
            )}
          </div>
        </div>
        <main>{children}</main>
        <footer>
          Built on community evidence.{" "}
          <span>Similarity is a lead, not a verdict.</span>
        </footer>
      </div>
    </div>
  );
}
