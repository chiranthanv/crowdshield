"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useEffect, type FormEvent } from "react";
import {
  Search,
  ArrowRight,
  ArrowUpRight,
  Plus,
  ShieldCheck,
  Database,
  Fingerprint,
  Flag,
  RefreshCw,
  Check,
  ShieldAlert,
  LockKeyhole,
} from "lucide-react";
import {
  api,
  useApi,
  PageTitle,
  Panel,
  ErrorBox,
  Empty,
  Loading,
  Status,
  Risk,
  UrlTable,
  Stat,
  Notice,
  date,
} from "./ui";

export function HomeScreen() {
  const { data, error, loading, reload } = useApi("/analytics/overview");
  const [mode, setMode] = useState("url"),
    [q, setQ] = useState(""),
    [items, setItems] = useState<any[] | null>(null),
    [busy, setBusy] = useState(false),
    [searchError, setSearchError] = useState(""),
    [notFound, setNotFound] = useState("");
  const router = useRouter();
  async function search(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setSearchError("");
    setNotFound("");
    try {
      if (mode === "url") {
        const r = await api("/urls/lookup", {
          method: "POST",
          body: JSON.stringify({ url: q }),
        });
        if (r.found) router.push("/urls/" + r.url_id);
        else {
          setNotFound(r.display_url);
          setItems(null);
        }
      } else {
        const r =
          mode === "semantic"
            ? await api("/search/semantic", {
                method: "POST",
                body: JSON.stringify({ q }),
              })
            : await api("/search/text?q=" + encodeURIComponent(q));
        setItems(r.items);
      }
    } catch (e) {
      setSearchError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageTitle
        eyebrow="COMMUNITY THREAT INTELLIGENCE"
        title="A clearer view of suspicious links."
        description="Look up a URL, explore community reports, and follow the evidence before you act."
      >
        <Link href="/report" className="button">
          <Plus size={15} /> Submit a report
        </Link>
      </PageTitle>
      <div className="stats">
        <Stat
          label="URLs in the knowledge base"
          value={data?.counts.urls ?? "—"}
          detail="Distinct normalized URLs"
          accent
        />
        <Stat
          label="Community reports"
          value={data?.counts.reports ?? "—"}
          detail="Reports recorded in PostgreSQL"
        />
        <Stat
          label="Community votes"
          value={data?.counts.votes ?? "—"}
          detail="One current vote per user / URL"
        />
        <Stat
          label="Active contributors"
          value={data?.counts.contributors ?? "—"}
          detail="Registered, active accounts"
        />
      </div>
      <div className="two-col">
        <div className="stack">
          <Panel className="search-panel">
            <div className="tabs">
              {[
                ["url", "Exact URL lookup"],
                ["text", "Text search"],
                ["semantic", "Semantic search"],
              ].map(([id, label]) => (
                <button
                  key={id}
                  className={mode === id ? "active" : ""}
                  onClick={() => {
                    setMode(id);
                    setItems(null);
                    setSearchError("");
                    setNotFound("");
                  }}
                >
                  {label}
                </button>
              ))}
            </div>
            <h2>
              {mode === "semantic"
                ? "Find evidence with similar meaning"
                : "What would you like to investigate?"}
            </h2>
            <p>
              {mode === "semantic"
                ? "Describe the message or suspected scam. Search uses real report embeddings."
                : "Submitted URLs are stored as evidence. CrowdShield never opens them."}
            </p>
            <form onSubmit={search} className="search-row">
              <input
                aria-label="Search query"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                required
                placeholder={
                  mode === "url"
                    ? "https://suspicious-link.example/verify"
                    : mode === "text"
                      ? "Search a hostname or scam description…"
                      : "A parcel text asking for a redelivery fee…"
                }
              />
              <button className="button" disabled={busy}>
                <Search size={15} />
                {busy ? "Searching…" : "Investigate"}
              </button>
            </form>
            <div className="tagline">
              <span>
                <LockKeyhole size={12} /> No URL crawling
              </span>
              <span>
                <Database size={12} /> Evidence-backed results
              </span>
              <span>
                <Fingerprint size={12} /> Versioned reports
              </span>
            </div>
          </Panel>
          <ErrorBox message={searchError} />
          {notFound && (
            <Notice>
              <b>No evidence found for {notFound}.</b>
              <br />
              An unknown URL is not automatically safe.{" "}
              <Link href={"/report?url=" + encodeURIComponent(q)}>
                Submit a report <ArrowUpRight size={12} />
              </Link>
            </Notice>
          )}
          <Panel
            title={items ? "Search results" : "Recently added URLs"}
            description={
              items
                ? "Current accessible evidence matching your search."
                : "The latest entries in the community knowledge base."
            }
          >
            {items && mode === "semantic" ? (
              items.length ? (
                items.map((r) => (
                  <div className="evidence-card" key={r.report_id}>
                    <header>
                      <Link
                        className="url-link mono"
                        href={"/urls/" + r.url_id}
                      >
                        {r.display_url}
                      </Link>
                      <span className="badge">
                        Cosine {Number(r.cosine_similarity).toFixed(3)}
                      </span>
                    </header>
                    <p>{r.message_text}</p>
                    <div className="meta">
                      Similarity does not establish maliciousness.
                    </div>
                  </div>
                ))
              ) : (
                <Empty
                  title="No eligible evidence yet"
                  text="Accepted reports appear after the embedding worker processes them."
                />
              )
            ) : loading && !items ? (
              <Loading />
            ) : (
              <UrlTable items={items || data?.recent || []} />
            )}
          </Panel>
          <ErrorBox message={error} onRetry={reload} />
        </div>
        <div className="stack">
          <Panel title="Follow the evidence">
            <div className="panel-body">
              <ol className="help-list">
                <li>
                  <div>
                    <b>Find or submit a URL</b>Exact identity keeps meaningful
                    path and query differences.
                  </div>
                </li>
                <li>
                  <div>
                    <b>Read community evidence</b>Reports are synchronized,
                    reviewed and versioned.
                  </div>
                </li>
                <li>
                  <div>
                    <b>Assess risk and coverage</b>A score is a heuristic.
                    Coverage shows the amount of evidence.
                  </div>
                </li>
              </ol>
            </div>
          </Panel>
          <Panel title="Risk distribution">
            <div className="panel-body">
              <Distribution rows={data?.distribution || []} />
            </div>
          </Panel>
          <Notice>
            Use invented evidence and reserved .example domains for your
            classroom demonstration.
          </Notice>
        </div>
      </div>
    </>
  );
}
function Distribution({ rows }: { rows: any[] }) {
  const total = rows.reduce((a, r) => a + Number(r.count), 0);
  return !rows.length ? (
    <p className="muted tiny">No records yet.</p>
  ) : (
    rows.map((r) => (
      <div className="bar-row" key={r.label}>
        <div>
          <span>{r.label.replaceAll("_", " ")}</span>
          <b>{r.count}</b>
        </div>
        <div className="bar-track">
          <span
            className={r.label}
            style={{ width: `${total ? (Number(r.count) / total) * 100 : 0}%` }}
          />
        </div>
      </div>
    ))
  );
}
export function DashboardScreen() {
  const overview = useApi("/analytics/overview", 10000),
    own = useApi("/me/contributions", 6000);
  const d = overview.data;
  return (
    <>
      <PageTitle
        eyebrow="YOUR WORKSPACE"
        title="Community overview"
        description="Track your contributions and the processing behind each piece of evidence."
      >
        <button
          className="button ghost"
          onClick={() => {
            void overview.reload();
            void own.reload();
          }}
        >
          <RefreshCw size={14} /> Refresh
        </button>
      </PageTitle>
      <ErrorBox message={overview.error} onRetry={overview.reload} />
      <div className="stats">
        <Stat
          label="Your reports"
          value={own.data?.counts.reports ?? "—"}
          detail="Submitted by this account"
          accent
        />
        <Stat
          label="Your votes"
          value={own.data?.counts.votes ?? "—"}
          detail="Current URL assessments"
        />
        <Stat
          label="Your reputation"
          value={own.data?.counts.reputation ?? "—"}
          detail="Bounded contribution ledger"
        />
        <Stat
          label="Awaiting review"
          value={d?.counts.review_queue ?? "—"}
          detail="Synchronized, pending reports"
        />
      </div>
      <div className="two-col">
        <div className="stack">
          <Panel
            title="Your reports"
            description="Processing status is separate from the moderator’s decision."
          >
            <ErrorBox message={own.error} />
            {own.loading ? (
              <Loading />
            ) : own.data?.reports.length ? (
              <ReportTable reports={own.data.reports} />
            ) : (
              <Empty
                title="Start with your first report"
                text="Submit a suspicious URL and a redacted explanation."
              />
            )}
          </Panel>
          <Panel title="Recently observed">
            <UrlTable items={d?.recent || []} />
          </Panel>
        </div>
        <div className="stack">
          <Panel title="Database processing">
            <div className="panel-body">
              <div className="service-row">
                <span>PostgreSQL</span>
                <Status value={d ? "active" : "pending"} />
              </div>
              <div className="service-row">
                <span>MongoDB</span>
                <Status
                  value={
                    d?.services.mongodb === "available" ? "active" : "failed"
                  }
                />
              </div>
              <div className="service-row">
                <span>Embedding report count</span>
                <b>{d?.services.vector_reports ?? "—"}</b>
              </div>
              <div className="service-row">
                <span>Pending / processing jobs</span>
                <b>
                  {d
                    ? `${d.processing.pending} / ${d.processing.processing}`
                    : "—"}
                </b>
              </div>
              <div className="service-row">
                <span>Parked jobs</span>
                <b>{d?.processing.failed ?? "—"}</b>
              </div>
              <p className="muted tiny" style={{ marginTop: 14 }}>
                Last completed job:{" "}
                {d?.processing.last_processed_at
                  ? date(d.processing.last_processed_at)
                  : "No worker activity yet"}
              </p>
            </div>
          </Panel>
          <Panel title="Evidence coverage">
            <div className="panel-body">
              <Distribution rows={d?.distribution || []} />
              <p className="tiny muted">
                Low coverage is shown as insufficient evidence, even when a
                numerical score exists.
              </p>
            </div>
          </Panel>
        </div>
      </div>
    </>
  );
}
function ReportTable({ reports }: { reports: any[] }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>URL / REPORT</th>
            <th>REVIEW</th>
            <th>DELIVERY</th>
            <th>VERSION</th>
          </tr>
        </thead>
        <tbody>
          {reports.map((r) => (
            <tr key={r.report_id}>
              <td>
                <Link className="url-link mono" href={"/urls/" + r.url_id}>
                  {r.display_url || r.report_type.replaceAll("_", " ")}
                </Link>
                <span className="subline">{date(r.created_at)}</span>
              </td>
              <td>
                <Status value={r.workflow_status} />
              </td>
              <td>
                <Status value={r.sync_status} />
              </td>
              <td>v{r.content_version}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export function ReportScreen() {
  const [url, setUrl] = useState(""),
    [message, setMessage] = useState(""),
    [type, setType] = useState("phishing"),
    [channel, setChannel] = useState("website"),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [result, setResult] = useState<any>(null),
    [key, setKey] = useState("");
  useEffect(() => {
    setUrl(new URLSearchParams(location.search).get("url") || "");
    setKey(crypto.randomUUID());
  }, []);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const r = await api("/reports", {
        method: "POST",
        body: JSON.stringify({
          url,
          report_type: type,
          message_text: message,
          channel,
          idempotency_key: key,
        }),
      });
      setResult(r.report);
      setKey(crypto.randomUUID());
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageTitle
        eyebrow="CONTRIBUTE INTELLIGENCE"
        title="Report a suspicious link"
        description="Share what you observed. Clear, redacted evidence helps the community make better decisions."
      />
      <div className="two-col">
        <Panel
          title="Report details"
          description="Use a complete URL and explain why it appears suspicious."
        >
          <div className="panel-body">
            <ErrorBox message={error} />
            {result ? (
              <>
                <Notice>
                  <b>Report recorded in PostgreSQL.</b>
                  <br />
                  Document delivery: {result.sync_status}. The worker will
                  synchronize the evidence with MongoDB.
                </Notice>
                <Link className="button" href={"/urls/" + result.url_id}>
                  View URL and processing status <ArrowRight size={15} />
                </Link>
                <button
                  className="button ghost"
                  style={{ marginLeft: 10 }}
                  onClick={() => {
                    setResult(null);
                    setMessage("");
                  }}
                >
                  Another report
                </button>
              </>
            ) : (
              <form onSubmit={submit}>
                <div className="form-field">
                  <label htmlFor="report-url">Suspicious URL</label>
                  <input
                    id="report-url"
                    value={url}
                    onChange={(e) => {
                      setUrl(e.target.value);
                      setKey(crypto.randomUUID());
                    }}
                    placeholder="https://parcel-check.example/verify"
                    required
                    type="url"
                    maxLength={8192}
                  />
                  <div className="form-help">
                    HTTP/HTTPS only. This application will not visit the URL.
                  </div>
                </div>
                <div className="equal-cols">
                  <div className="form-field">
                    <label htmlFor="report-type">Report type</label>
                    <select
                      id="report-type"
                      value={type}
                      onChange={(e) => {
                        setType(e.target.value);
                        setKey(crypto.randomUUID());
                      }}
                    >
                      <option value="phishing">Phishing website</option>
                      <option value="scam_message">Scam message</option>
                      <option value="other">Other suspicious activity</option>
                    </select>
                  </div>
                  <div className="form-field">
                    <label htmlFor="report-channel">
                      Where did you see it?
                    </label>
                    <select
                      id="report-channel"
                      value={channel}
                      onChange={(e) => {
                        setChannel(e.target.value);
                        setKey(crypto.randomUUID());
                      }}
                    >
                      {["website", "sms", "email", "social", "other"].map(
                        (v) => (
                          <option value={v} key={v}>
                            {v.toUpperCase()}
                          </option>
                        ),
                      )}
                    </select>
                  </div>
                </div>
                <div className="form-field">
                  <label htmlFor="report-text">Redacted explanation</label>
                  <textarea
                    id="report-text"
                    value={message}
                    onChange={(e) => {
                      setMessage(e.target.value);
                      setKey(crypto.randomUUID());
                    }}
                    minLength={15}
                    maxLength={12000}
                    required
                    placeholder="The message impersonates a delivery company and requests payment through an unfamiliar link…"
                  />
                  <div className="form-help">
                    Remove names, passwords, payment details and private tokens.
                    Basic email/number redaction also runs on the server.
                  </div>
                </div>
                <button className="button" disabled={busy || !key}>
                  <Flag size={15} />
                  {busy ? "Submitting…" : "Submit report"}
                </button>
              </form>
            )}
          </div>
        </Panel>
        <div className="stack">
          <Panel title="What happens next?">
            <div className="panel-body">
              <ol className="help-list">
                <li>
                  <div>
                    <b>Recorded atomically</b>URL, report metadata and delivery
                    event commit together.
                  </div>
                </li>
                <li>
                  <div>
                    <b>Synchronized reliably</b>The worker retries temporary
                    outages without duplicating documents.
                  </div>
                </li>
                <li>
                  <div>
                    <b>Reviewed by a moderator</b>Accepted evidence can
                    contribute to risk and similarity search.
                  </div>
                </li>
              </ol>
            </div>
          </Panel>
          <Notice>
            Submitting a report is an allegation, not proof that a website is
            malicious.
          </Notice>
        </div>
      </div>
    </>
  );
}
export function UrlScreen({ id }: { id: string }) {
  const { data: d, error, loading, reload } = useApi("/urls/" + id, 5000);
  const me = useApi("/me");
  const [actionError, setActionError] = useState(""),
    [busy, setBusy] = useState(false);
  async function vote(value: number | null) {
    setBusy(true);
    setActionError("");
    try {
      await api("/urls/" + id + "/vote", {
        method: value === null ? "DELETE" : "PUT",
        ...(value === null ? {} : { body: JSON.stringify({ verdict: value }) }),
      });
      await reload();
    } catch (e) {
      setActionError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  if (loading) return <Loading />;
  if (error || !d)
    return <ErrorBox message={error || "URL unavailable"} onRetry={reload} />;
  return (
    <>
      <PageTitle
        eyebrow="URL EVIDENCE PROFILE"
        title={d.url.hostname}
        description="Community signals, reviewed evidence and an explainable risk snapshot."
      >
        <Link className="button ghost" href="/report">
          <Plus size={14} /> Add evidence
        </Link>
      </PageTitle>
      <div className="url-heading mono">{d.url.display_url}</div>
      {d.risk_stale && (
        <Notice>
          The risk snapshot is awaiting refresh. Start the worker to process
          current evidence and time-dependent scores.
        </Notice>
      )}
      <ErrorBox message={actionError} />
      <div className="two-col">
        <div className="stack">
          <Panel
            title="Community assessment"
            description="One current vote per account. Your vote can be changed or withdrawn."
          >
            <div className="panel-body">
              <div className="metric-grid">
                <div>
                  Malicious votes<b>{d.votes.malicious}</b>
                </div>
                <div>
                  Safe votes<b>{d.votes.safe}</b>
                </div>
              </div>
              <div className="form-actions" style={{ marginTop: 18 }}>
                <button
                  disabled={busy}
                  className={"button " + (d.my_vote === 1 ? "danger" : "ghost")}
                  onClick={() => vote(1)}
                >
                  <ShieldAlert size={15} /> Looks malicious{" "}
                  {d.my_vote === 1 && <Check size={14} />}
                </button>
                <button
                  disabled={busy}
                  className={"button " + (d.my_vote === -1 ? "" : "ghost")}
                  onClick={() => vote(-1)}
                >
                  <ShieldCheck size={15} /> Looks safe{" "}
                  {d.my_vote === -1 && <Check size={14} />}
                </button>
                {d.my_vote && (
                  <button
                    className="button ghost small"
                    disabled={busy}
                    onClick={() => vote(null)}
                  >
                    Withdraw
                  </button>
                )}
              </div>
              {!me.data && (
                <p className="form-help">
                  <Link href="/login">Sign in</Link> with an activated demo
                  account to vote.
                </p>
              )}
            </div>
          </Panel>
          <Panel
            title="Report evidence"
            description="Public reports are accepted and synchronized. You can also see your own submissions."
          >
            {d.reports.length ? (
              d.reports.map((r: any) => (
                <Evidence
                  key={
                    r.report_id + ":" + r.content_version + ":" + r.sync_status
                  }
                  report={r}
                  reload={reload}
                />
              ))
            ) : (
              <Empty
                title="No visible reports"
                text="This URL has no accepted evidence yet."
              />
            )}
          </Panel>
          <Panel title="Risk history">
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>COMPUTED</th>
                    <th>SCORE</th>
                    <th>COVERAGE</th>
                    <th>ALGORITHM</th>
                  </tr>
                </thead>
                <tbody>
                  {d.history.map((r: any, i: number) => (
                    <tr key={i}>
                      <td>{date(r.computed_at)}</td>
                      <td>{r.score}</td>
                      <td>{Math.round(r.coverage * 100)}%</td>
                      <td className="mono tiny">{r.algorithm_version}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>
        <div className="stack">
          <Panel title="Current risk">
            <Risk risk={d.risk} />
            {d.risk?.moderator_verdict && (
              <div className="panel-body" style={{ paddingTop: 0 }}>
                <Status value={d.risk.moderator_verdict} />
                <p className="form-help">Latest effective moderator verdict</p>
              </div>
            )}
          </Panel>
          {me.data?.user.roles.some((r: string) =>
            ["moderator", "admin"].includes(r),
          ) && <VerdictPanel id={id} reload={reload} />}
          <Panel title="Score ingredients">
            <div className="panel-body">
              {[
                ["Community votes", "community_component"],
                ["Accepted reports", "report_component"],
                ["Reviewed similarity", "similarity_component"],
              ].map(([label, k]) => (
                <div className="service-row" key={k}>
                  <span>{label}</span>
                  <b>{d.risk ? Number(d.risk[k]).toFixed(3) : "—"}</b>
                </div>
              ))}
              <p className="form-help">
                Weights: 55% votes, 25% reports, 20% similarity. Reviewed
                verdicts take precedence.
              </p>
            </div>
          </Panel>
          <Panel
            title="Similar evidence"
            description="Semantic leads from current, eligible reports."
          >
            {d.similar.length ? (
              d.similar.map((r: any) => (
                <div className="evidence-card" key={r.url_id}>
                  <Link className="url-link mono" href={"/urls/" + r.url_id}>
                    {r.display_url}
                  </Link>
                  <div className="meta">
                    Cosine similarity: {Number(r.similarity).toFixed(3)}{" "}
                    {r.moderator_verdict && (
                      <Status value={r.moderator_verdict} />
                    )}
                  </div>
                </div>
              ))
            ) : (
              <Empty
                title="No similar evidence yet"
                text="Accepted reports need completed embedding jobs."
              />
            )}
          </Panel>
        </div>
      </div>
    </>
  );
}
function Evidence({
  report: r,
  reload,
}: {
  report: any;
  reload: () => Promise<void>;
}) {
  const { data, error } = useApi("/reports/" + r.report_id);
  const [withdrawError, setError] = useState("");
  return (
    <div className="evidence-card">
      <header>
        <div>
          <Status value={r.workflow_status} /> <Status value={r.sync_status} />
        </div>
        <span className="tiny muted">v{r.content_version}</span>
      </header>
      <ErrorBox message={error || withdrawError} />
      <p>
        {data?.report.message_text ||
          (r.sync_status === "synced"
            ? "Loading report content…"
            : "Document delivery is pending. Metadata is safely recorded in PostgreSQL.")}
      </p>
      <div className="meta">
        {r.report_type.replaceAll("_", " ")} · {date(r.created_at)}
      </div>
      {r.owned && r.workflow_status !== "withdrawn" && (
        <button
          className="button ghost small"
          style={{ marginTop: 12 }}
          onClick={async () => {
            try {
              await api("/reports/" + r.report_id, { method: "DELETE" });
              await reload();
            } catch (e) {
              setError((e as Error).message);
            }
          }}
        >
          Withdraw my report
        </button>
      )}
    </div>
  );
}
export function AuthScreen({
  kind,
}: {
  kind: "login" | "register" | "verify";
}) {
  const [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [name, setName] = useState(""),
    [token, setToken] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const router = useRouter();
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await api("/auth/" + (kind === "verify" ? "verify-email" : kind), {
        method: "POST",
        body: JSON.stringify(
          kind === "verify"
            ? { token }
            : kind === "register"
              ? { email, password, display_name: name }
              : { email, password },
        ),
      });
      router.push(kind === "register" ? "/verify" : "/dashboard");
      router.refresh();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="auth-card">
      <Panel>
        <div className="panel-body">
          <div className="eyebrow">CROWDSHIELD ACCOUNT</div>
          <h1>
            {kind === "login"
              ? "Welcome back."
              : kind === "register"
                ? "Join the community."
                : "Activate your demo account."}
          </h1>
          <p className="intro">
            {kind === "verify"
              ? "Ask the local demo operator to run the account:verify command. Paste the single-use token below."
              : kind === "login"
                ? "Sign in to contribute and follow your reports."
                : "Create an account to report suspicious URLs and vote."}
          </p>
          <ErrorBox message={error} />
          <form onSubmit={submit}>
            {kind === "register" && (
              <div className="form-field">
                <label htmlFor="name">Display name</label>
                <input
                  id="name"
                  autoComplete="nickname"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  minLength={2}
                  maxLength={80}
                  required
                />
              </div>
            )}
            {kind === "verify" ? (
              <div className="form-field">
                <label htmlFor="token">Verification token</label>
                <input
                  id="token"
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  required
                  autoComplete="off"
                />
                <div className="form-help">
                  This activates the local demo account. It does not prove email
                  ownership.
                </div>
              </div>
            ) : (
              <>
                <div className="form-field">
                  <label htmlFor="email">Email address</label>
                  <input
                    id="email"
                    type="email"
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                <div className="form-field">
                  <label htmlFor="password">Password</label>
                  <input
                    id="password"
                    type="password"
                    autoComplete={
                      kind === "login" ? "current-password" : "new-password"
                    }
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={kind === "register" ? 12 : 1}
                    maxLength={72}
                  />
                  {kind === "register" && (
                    <div className="form-help">
                      Use 12–72 characters. Do not reuse an important password.
                    </div>
                  )}
                </div>
              </>
            )}
            <button
              className="button"
              style={{ width: "100%" }}
              disabled={busy}
            >
              {busy
                ? "Please wait…"
                : kind === "login"
                  ? "Sign in"
                  : kind === "register"
                    ? "Create account"
                    : "Activate account"}
              <ArrowRight size={15} />
            </button>
          </form>
          <div className="auth-bottom">
            {kind === "login" ? (
              <>
                New to CrowdShield?{" "}
                <Link href="/register">Create an account</Link>
              </>
            ) : (
              <Link href="/login">Back to sign in</Link>
            )}
          </div>
        </div>
      </Panel>
      {kind === "verify" && (
        <p className="form-help mono" style={{ marginTop: 15 }}>
          npm run account:verify -- your-email@example.test
        </p>
      )}
    </div>
  );
}
export function AnalyticsScreen() {
  const summary = useApi("/analytics/overview"),
    trend = useApi("/analytics/trends");
  const d = trend.data;
  const maximum = Math.max(1, ...(d?.daily || []).map((r: any) => r.reports));
  return (
    <>
      <PageTitle
        eyebrow="PATTERNS IN THE EVIDENCE"
        title="Community analytics"
        description="Explore actual database aggregates. Counts describe this project’s dataset, not global scam prevalence."
      />
      <ErrorBox message={summary.error} onRetry={summary.reload} />
      <ErrorBox message={trend.error} onRetry={trend.reload} />
      <div className="stats">
        <Stat
          label="Recorded reports"
          value={summary.data?.counts.reports ?? "—"}
          detail="PostgreSQL metadata"
          accent
        />
        <Stat
          label="Tracked URLs"
          value={summary.data?.counts.urls ?? "—"}
          detail="Unique normalized identities"
        />
        <Stat
          label="Accepted embedded reports"
          value={summary.data?.services.vector_reports ?? "—"}
          detail="Current semantic evidence"
        />
        <Stat
          label="Community assessments"
          value={summary.data?.counts.votes ?? "—"}
          detail="Current votes"
        />
      </div>
      <div className="equal-cols">
        <div className="stack">
          <Panel
            title="Report activity · last 14 days"
            description="Daily submissions, including reports awaiting review. UTC dates."
          >
            <div className="panel-body">
              {trend.loading ? (
                <Loading />
              ) : (
                <div className="chart-bars" aria-label="Daily report counts">
                  {d?.daily.map((r: any) => (
                    <div className="chart-day" key={r.day}>
                      <b>{r.reports}</b>
                      <div
                        className="bar"
                        style={{ height: `${(r.reports / maximum) * 120}px` }}
                      />
                      <span>{r.day.slice(5)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Panel>
          <Panel
            title="Top reported URLs"
            description="Accepted and synchronized reports."
          >
            {d?.top.length ? (
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>URL</th>
                      <th>REPORTS</th>
                    </tr>
                  </thead>
                  <tbody>
                    {d.top.map((r: any) => (
                      <tr key={r.url_id}>
                        <td>
                          <Link
                            className="mono url-link"
                            href={"/urls/" + r.url_id}
                          >
                            {r.display_url}
                          </Link>
                        </td>
                        <td>{r.reports}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <Empty />
            )}
          </Panel>
        </div>
        <div className="stack">
          <Panel title="Risk distribution">
            <div className="panel-body">
              <Distribution rows={summary.data?.distribution || []} />
            </div>
          </Panel>
          <Panel
            title="Accepted evidence by type"
            description="MongoDB aggregation filtered against current SQL eligibility."
          >
            <div className="panel-body">
              <ErrorBox message={d?.mongo_error || ""} />
              {d?.mongo?.types.length ? (
                d.mongo.types.map((r: any) => (
                  <div className="service-row" key={r._id}>
                    <span>{r._id.replaceAll("_", " ")}</span>
                    <b>{r.count}</b>
                  </div>
                ))
              ) : (
                <p className="muted tiny">
                  No accepted documents in this dataset.
                </p>
              )}
              <h3 style={{ marginTop: 24, marginBottom: 8 }}>
                Active contributors
              </h3>
              {d?.mongo?.active.map((r: any, i: number) => (
                <div className="service-row" key={i}>
                  <span>{r.display_name}</span>
                  <b>{r.count} reports</b>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </>
  );
}
export function ModerationScreen() {
  const q = useApi("/moderation/reports", 8000);
  const me = useApi("/me");
  return (
    <>
      <PageTitle
        eyebrow="HUMAN REVIEW"
        title="Moderation queue"
        description="Review synchronized evidence, document your reasoning and keep community decisions accountable."
      />
      <Notice>
        Accepting a report makes its evidence eligible. Set a URL verdict
        separately after reviewing the evidence.
      </Notice>
      <ErrorBox message={q.error} onRetry={q.reload} />
      {q.loading ? (
        <Loading />
      ) : q.data?.items.length ? (
        <div className="stack">
          {q.data.items.map((r: any) => (
            <ReviewCard
              key={r.report_id + ":" + r.sync_status}
              item={r}
              self={me.data?.user.user_id === r.reporter_id}
              reload={q.reload}
            />
          ))}
        </div>
      ) : (
        !q.error && (
          <Panel>
            <Empty
              title="The review queue is clear"
              text="New synchronized reports will appear here."
            />
          </Panel>
        )
      )}
    </>
  );
}
function ReviewCard({
  item: r,
  self,
  reload,
}: {
  item: any;
  self: boolean;
  reload: () => Promise<void>;
}) {
  const doc = useApi("/reports/" + r.report_id);
  const [reason, setReason] = useState(""),
    [verdict, setVerdict] = useState("malicious"),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [success, setSuccess] = useState("");
  async function review(accept: boolean) {
    setBusy(true);
    setError("");
    try {
      await api("/moderation/reports/" + r.report_id + "/decision", {
        method: "POST",
        body: JSON.stringify({ accept, reason }),
      });
      await reload();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function decide() {
    setBusy(true);
    setError("");
    try {
      await api("/moderation/urls/" + r.url_id + "/verdict", {
        method: "POST",
        body: JSON.stringify({ verdict, reason, valid_days: 30 }),
      });
      setSuccess("URL verdict recorded for 30 days.");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Panel>
      <div className="panel-body">
        <div className="section-action" style={{ marginTop: 0 }}>
          <Link className="url-link mono" href={"/urls/" + r.url_id}>
            {r.display_url}
          </Link>
          <Status value={r.sync_status} />
        </div>
        <p style={{ whiteSpace: "pre-wrap", color: "#b8c9d8" }}>
          {doc.data?.report.message_text ||
            (doc.loading
              ? "Loading report content…"
              : "Content is not synchronized yet.")}
        </p>
        <ErrorBox message={error || doc.error} />
        {self && (
          <Notice>
            You submitted this report. Another reviewer must accept or reject
            it.
          </Notice>
        )}
        <div className="form-field" style={{ marginTop: 18 }}>
          <label htmlFor={"reason-" + r.report_id}>
            Review reason (at least 10 characters)
          </label>
          <input
            id={"reason-" + r.report_id}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Explain which evidence supports your decision…"
            minLength={10}
          />
        </div>
        <div className="form-actions">
          <button
            className="button"
            disabled={
              busy ||
              self ||
              !doc.data?.report.message_text ||
              r.sync_status !== "synced" ||
              reason.trim().length < 10
            }
            onClick={() => review(true)}
          >
            <Check size={14} /> Accept report
          </button>
          <button
            className="button danger"
            disabled={
              busy ||
              self ||
              !doc.data?.report.message_text ||
              r.sync_status !== "synced" ||
              reason.trim().length < 10
            }
            onClick={() => review(false)}
          >
            Reject
          </button>
          <div className="inline-controls">
            <select
              aria-label="Reviewed URL verdict"
              value={verdict}
              onChange={(e) => setVerdict(e.target.value)}
            >
              <option value="malicious">Malicious</option>
              <option value="safe">Safe</option>
              <option value="clear">Clear verdict</option>
            </select>
            <button
              className="button ghost"
              disabled={busy || reason.trim().length < 10}
              onClick={decide}
            >
              Set URL verdict
            </button>
          </div>
        </div>
        {success && <p className="success">{success}</p>}
      </div>
    </Panel>
  );
}
export function AdminScreen() {
  const users = useApi("/admin/users"),
    jobs = useApi("/admin/jobs", 8000),
    logs = useApi("/admin/audit-logs");
  const [error, setError] = useState("");
  const [tab, setTab] = useState("users");
  async function change(
    id: string,
    path: string,
    method: string,
    body?: unknown,
  ) {
    setError("");
    try {
      await api("/admin/users/" + id + path, {
        method,
        ...(body ? { body: JSON.stringify(body) } : {}),
      });
      await users.reload();
      await logs.reload();
    } catch (e) {
      setError((e as Error).message);
    }
  }
  return (
    <>
      <PageTitle
        eyebrow="ADMINISTRATION"
        title="Accounts & operations"
        description="Manage access, inspect delivery jobs and review the audit trail."
      >
        <button
          className="button ghost"
          onClick={() => {
            void users.reload();
            void jobs.reload();
            void logs.reload();
          }}
        >
          <RefreshCw size={14} /> Refresh
        </button>
      </PageTitle>
      <ErrorBox message={error || users.error || jobs.error || logs.error} />
      <div className="tabs">
        {[
          ["users", "Accounts & roles"],
          ["jobs", "Worker jobs"],
          ["audit", "Audit trail"],
        ].map(([v, t]) => (
          <button
            key={v}
            className={tab === v ? "active" : ""}
            onClick={() => setTab(v)}
          >
            {t}
          </button>
        ))}
      </div>
      {tab === "users" && (
        <Panel
          title="Account directory"
          description="Role and status changes revoke existing sessions. The last active administrator is protected."
        >
          {users.loading ? (
            <Loading />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>ACCOUNT</th>
                    <th>STATUS</th>
                    <th>ROLES</th>
                    <th>ACTIONS</th>
                  </tr>
                </thead>
                <tbody>
                  {users.data?.items.map((u: any) => (
                    <tr key={u.user_id}>
                      <td>
                        <b>{u.display_name}</b>
                        <span className="subline">{u.email}</span>
                      </td>
                      <td>
                        <Status value={u.status} />
                        <span className="subline">
                          {u.email_verified_at
                            ? "Demo active"
                            : "Not activated"}
                        </span>
                      </td>
                      <td>
                        <div className="inline-controls">
                          {u.roles.map((r: string) => (
                            <span className="badge" key={r}>
                              {r}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td>
                        <div className="inline-controls">
                          <button
                            className="button ghost small"
                            onClick={() =>
                              change(u.user_id, "/status", "PATCH", {
                                status:
                                  u.status === "active"
                                    ? "suspended"
                                    : "active",
                              })
                            }
                          >
                            {u.status === "active" ? "Suspend" : "Activate"}
                          </button>
                          {["moderator", "admin"].map((r) => (
                            <button
                              key={r}
                              className="button ghost small"
                              onClick={() =>
                                change(
                                  u.user_id,
                                  "/roles/" + r,
                                  u.roles.includes(r) ? "DELETE" : "PUT",
                                )
                              }
                            >
                              {u.roles.includes(r) ? "Remove" : "Grant"} {r}
                            </button>
                          ))}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      )}
      {tab === "jobs" && (
        <Panel
          title="Outbox delivery history"
          description="Failures retry automatically up to eight attempts. Payloads and private report content are hidden."
        >
          {jobs.loading ? (
            <Loading />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>EVENT</th>
                    <th>STATE</th>
                    <th>ATTEMPTS</th>
                    <th>LAST ERROR</th>
                    <th>CREATED</th>
                  </tr>
                </thead>
                <tbody>
                  {jobs.data?.items.map((j: any) => (
                    <tr key={j.event_id}>
                      <td className="mono">
                        {j.event_type}
                        <span className="subline">
                          {j.event_id.slice(0, 8)} · v{j.aggregate_version}
                        </span>
                      </td>
                      <td>
                        <Status value={j.status} />
                      </td>
                      <td>{j.attempts}/8</td>
                      <td>{j.last_error || "—"}</td>
                      <td>{date(j.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      )}
      {tab === "audit" && (
        <Panel title="Append-only audit records">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>ACTION</th>
                  <th>ENTITY</th>
                  <th>ACTOR</th>
                  <th>TIME</th>
                </tr>
              </thead>
              <tbody>
                {logs.data?.items.map((a: any) => (
                  <tr key={a.audit_id}>
                    <td>{a.action}</td>
                    <td className="mono tiny">
                      {a.entity_type}: {a.entity_id.slice(0, 12)}
                    </td>
                    <td className="mono tiny">
                      {a.actor_id?.slice(0, 8) || "System"}
                    </td>
                    <td>{date(a.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      )}
    </>
  );
}

function VerdictPanel({
  id,
  reload,
}: {
  id: string;
  reload: () => Promise<void>;
}) {
  const [verdict, setVerdict] = useState("malicious"),
    [reason, setReason] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [success, setSuccess] = useState("");
  return (
    <Panel
      title="Reviewed URL verdict"
      description="Moderator / administrator control"
    >
      <div className="panel-body">
        <ErrorBox message={error} />
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setError("");
            try {
              await api("/moderation/urls/" + id + "/verdict", {
                method: "POST",
                body: JSON.stringify({
                  verdict,
                  reason,
                  valid_days: verdict === "clear" ? null : 30,
                }),
              });
              setSuccess("Reviewed verdict saved.");
              await reload();
            } catch (e) {
              setError((e as Error).message);
            } finally {
              setBusy(false);
            }
          }}
        >
          <div className="form-field">
            <label htmlFor="detail-verdict">Verdict</label>
            <select
              id="detail-verdict"
              value={verdict}
              onChange={(e) => setVerdict(e.target.value)}
            >
              <option value="malicious">Malicious</option>
              <option value="safe">Safe</option>
              <option value="clear">Clear current verdict</option>
            </select>
          </div>
          <div className="form-field">
            <label htmlFor="detail-reason">Reason</label>
            <input
              id="detail-reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              minLength={10}
              maxLength={2000}
              required
            />
          </div>
          <button className="button" disabled={busy}>
            Save verdict
          </button>
          {success && <p className="success">{success}</p>}
          <p className="form-help">
            Safe/malicious decisions expire after 30 days. History is retained.
          </p>
        </form>
      </div>
    </Panel>
  );
}
