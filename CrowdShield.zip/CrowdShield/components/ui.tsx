"use client";
import Link from "next/link";
import { useEffect, useState, useCallback, type ReactNode } from "react";
import {
  AlertCircle,
  ArrowUpRight,
  RefreshCw,
  Search,
  ShieldCheck,
} from "lucide-react";
export async function api(path: string, options: RequestInit = {}) {
  const response = await fetch("/api/v1" + path, {
    ...options,
    headers: { "Content-Type": "application/json", ...options.headers },
    cache: "no-store",
  });
  const data = await response.json();
  if (!response.ok)
    throw new Error(
      data.error +
        (data.fields?.length
          ? " " +
            data.fields.map((f: any) => `${f.field}: ${f.message}`).join(" ")
          : ""),
    );
  return data;
}
export function useApi(path: string, refreshMs = 0) {
  const [data, setData] = useState<any>(null),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true);
  const reload = useCallback(async () => {
    setError("");
    try {
      setData(await api(path));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [path]);
  useEffect(() => {
    let active = true;
    setLoading(true);
    api(path)
      .then((d) => {
        if (active) {
          setData(d);
          setError("");
        }
      })
      .catch((e) => {
        if (active) setError(e.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    const timer = refreshMs
      ? setInterval(() => {
          if (active) void reload();
        }, refreshMs)
      : undefined;
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, [path, reload, refreshMs]);
  return { data, error, loading, reload };
}
export function PageTitle({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  children?: ReactNode;
}) {
  return (
    <header className="page-title">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {children}
    </header>
  );
}
export function Panel({
  title,
  description,
  children,
  className = "",
}: {
  title?: string;
  description?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={"panel " + className}>
      {title && (
        <div className="panel-heading">
          <h2>{title}</h2>
          {description && <p>{description}</p>}
        </div>
      )}
      {children}
    </section>
  );
}
export function ErrorBox({
  message,
  onRetry,
}: {
  message: string;
  onRetry?: () => void;
}) {
  if (!message) return null;
  return (
    <div className="error-box" role="alert">
      <AlertCircle size={19} />
      <span>{message}</span>
      {onRetry && (
        <button className="button ghost small" onClick={onRetry}>
          <RefreshCw size={14} /> Retry
        </button>
      )}
    </div>
  );
}
export function Empty({
  title = "Nothing here yet",
  text = "New activity will appear here.",
}: {
  title?: string;
  text?: string;
}) {
  return (
    <div className="empty">
      <Search size={25} />
      <h3>{title}</h3>
      <p>{text}</p>
    </div>
  );
}
export function Loading() {
  return (
    <div className="loading" role="status">
      <RefreshCw size={18} className="spin" /> Loading current database records…
    </div>
  );
}
export function Status({ value }: { value: string }) {
  return <span className={"badge " + value}>{value.replaceAll("_", " ")}</span>;
}
export function Risk({
  risk,
  compact = false,
}: {
  risk: any;
  compact?: boolean;
}) {
  if (!risk) return <span className="muted">Score pending</span>;
  return (
    <div className={compact ? "risk-inline" : "risk-display"}>
      <strong>
        {Number(risk.score).toFixed(1)}
        <small>/100</small>
      </strong>
      <Status value={risk.label} />
      {!compact && (
        <>
          <div className="coverage-track">
            <span style={{ width: `${Number(risk.coverage) * 100}%` }} />
          </div>
          <p>
            Evidence coverage <b>{Math.round(Number(risk.coverage) * 100)}%</b>
          </p>
          <p className="muted tiny">
            A community heuristic, not a probability or safety guarantee.
          </p>
        </>
      )}
    </div>
  );
}
export function UrlTable({ items }: { items: any[] }) {
  return !items.length ? (
    <Empty
      title="No URLs found"
      text="Try a different search or submit a suspicious URL."
    />
  ) : (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>URL / HOST</th>
            <th>RISK</th>
            <th>COVERAGE</th>
            <th>REPORTS</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {items.map((r) => (
            <tr key={r.url_id}>
              <td>
                <Link className="url-link" href={"/urls/" + r.url_id}>
                  {r.hostname || r.display_url}
                </Link>
                {r.hostname && (
                  <span className="subline mono">{r.display_url}</span>
                )}
              </td>
              <td>
                <Risk compact risk={r.score === null ? null : r} />
              </td>
              <td>
                {r.coverage === null
                  ? "—"
                  : `${Math.round(Number(r.coverage) * 100)}%`}
              </td>
              <td>{r.accepted_reports ?? r.reports ?? "—"}</td>
              <td>
                <Link
                  aria-label={"View " + (r.hostname || r.display_url)}
                  className="icon-link"
                  href={"/urls/" + r.url_id}
                >
                  <ArrowUpRight size={17} />
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
export function Stat({
  label,
  value,
  detail,
  accent = false,
}: {
  label: string;
  value: string | number;
  detail: string;
  accent?: boolean;
}) {
  return (
    <div className={"stat " + (accent ? "accent" : "")}>
      <div className="stat-label">{label}</div>
      <strong>{value}</strong>
      <span>{detail}</span>
    </div>
  );
}
export function Notice({ children }: { children: ReactNode }) {
  return (
    <div className="notice">
      <ShieldCheck size={19} />
      <div>{children}</div>
    </div>
  );
}
export const date = (s: string) => new Date(s).toLocaleString();
