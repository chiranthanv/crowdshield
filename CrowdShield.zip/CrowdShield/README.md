# CrowdShield — working DBMS application

Student: **Chiranthan V · PES2UG24CS138 · Section C**. See the [assignment requirements audit](docs/REQUIREMENTS_AUDIT.md) for requirement-by-requirement evidence and outstanding course administration items.

CrowdShield is a two-member college project for reporting suspicious URLs, community voting, moderator review, explainable risk and semantic evidence search. The application uses **Next.js App Router + TypeScript, PostgreSQL with pgvector, MongoDB, and one small Node.js worker**. It does not open submitted URLs or require paid AI APIs.

The original design report and 22-table schema are retained. This implementation includes the seven core page areas. Discussions, generated AI explanations, campaign clustering, file uploads and notifications are not enabled. Read `IMPLEMENTATION_REPORT.md` and `IMPLEMENTATION_STATUS.md` for actual verification and limitations. The original report's implementation-status paragraphs are historical; the implementation report is the current status.

## 1. Install prerequisites

Install Node.js 22.13+ (Node 24 LTS recommended), Docker Desktop with Compose, and Git if you want version control. Start Docker Desktop. On Windows, use a normal PowerShell terminal. Python 3.11+ is needed only to run the original offline Python tests.

Extract the ZIP. Open a terminal **inside the `CrowdShield` folder containing package.json**. All following commands run from that folder.

```sh
node scripts/install.mjs
npm run env:init
docker compose up -d --wait
npm run db:setup
npm run model:download
npm run db:seed
```

What these commands do:

1. Install exact dependencies from package-lock.json. The installation helper selects the bundled CPU ONNX runtime and skips CUDA downloads; no GPU is required.
2. Create a private `.env` with random database credentials and random development-account passwords. It refuses to overwrite an existing `.env`.
3. Start PostgreSQL/pgvector and MongoDB on loopback only, with persistent Docker volumes.
4. Apply the existing SQL schema/features to a fresh database, install MongoDB validators/indexes and create a limited PostgreSQL application role. Repeated setup preserves the existing schema.
5. Download the free, pinned MiniLM model export (roughly 100 MB) and verify a real 384-dimensional embedding. Internet is needed on the first run; subsequent runs use `.model-cache`.
6. Create invented `.example` data and local demo accounts; process reports through the actual worker. No random embeddings or made-up similarity edges are seeded.

The model is `Xenova/all-MiniLM-L6-v2`, an ONNX export of `sentence-transformers/all-MiniLM-L6-v2`, fixed to revision `751bff37182d3f1213fa05d7196b954e230abad9`. Stored project version remains `minilm-l6-v2:project-v1`. Both query and document embedding use the same export, mean pooling and normalization.

## 2. Start the app and worker

### Local startup without Docker

If Docker Desktop is unavailable, after installing dependencies and running `npm.cmd run env:init`, run:

```powershell
npm.cmd run model:download
npm.cmd run demo:local
```

Open **http://localhost:3000**. This command starts a persistent PostgreSQL WASM engine with pgvector, a native MongoDB process, the Next.js app, and the worker. First startup downloads MongoDB. Demo data persists in `.test-runtime/local-demo`; passwords are the private `SEED_*_PASSWORD` values in `.env`. Keep the terminal running. Stop it with Ctrl+C. This loopback-only alternative uses a trusted local SQL socket and does not demonstrate native PostgreSQL authentication or concurrent native PostgreSQL sessions; use Docker for that verification. Do not run the full test harness at the same time because it uses the same database ports.

On Windows, use `npm.cmd` if PowerShell blocks `npm.ps1`. After `npm.cmd run build`, the VS Code task **CrowdShield: local website** starts the production demo with the same launcher.

To serve the production build through this launcher, run `npm.cmd run build`, then `npm.cmd run demo:local -- --production`.

### Docker startup

In terminal 1:

```sh
npm run dev
```

In terminal 2, in the same folder:

```sh
npm run worker
```

Open **http://localhost:3000**. Use exactly this hostname because `APP_ORIGIN` is checked on all mutations. Keep both terminals open. Press Ctrl+C to stop each process. To stop only the database containers without deleting data:

```sh
docker compose stop
```

Restart the databases with `docker compose up -d --wait`. Do **not** use `docker compose down -v` unless you intentionally want to delete all local database data.

For a production-build demonstration on your local machine:

```sh
npm run build
npm start
```

Run the worker in a separate terminal as above. The supported demonstration runs on loopback; this is not a hardened public deployment.

## 3. Development accounts

Open your private `.env` in your editor and read the relevant password. Passwords are generated on your computer and are never listed in this README.

| Role | Email | Password source |
|---|---|---|
| User | alice@example.test | SEED_USER_PASSWORD |
| Moderator | mod@example.test | SEED_MODERATOR_PASSWORD |
| Administrator | admin@example.test | SEED_ADMIN_PASSWORD |
| Additional invented users | bob@example.test, carol@example.test | SEED_USER_PASSWORD |

These reserved example addresses have no real mailbox. Seeding is idempotent: it does not overwrite existing accounts or passwords. Changing `.env` later does not change an already-seeded password. Use a fresh dedicated development database when starting over intentionally.

New registrations receive a session but require local demo activation before votes/reports count. The operator runs:

```sh
npm run account:verify -- your-email@example.test
```

Paste the printed single-use token at **http://localhost:3000/verify**. The token expires after 30 minutes and is stored only as a hash in SQL. A private OS-temp file is also written for local delivery. This demonstrates account activation; it does not prove real email ownership. Production email remains enhanced. Seed accounts are already activated.

## 4. Demonstrate the core workflow

1. Open Home and look up `https://new-site.example/`: score 37.5, coverage 0%, insufficient evidence.
2. Sign in as Alice. Submit an invented parcel scam report with a `.example` URL. PostgreSQL records the URL/report/outbox atomically; the page shows pending delivery.
3. With the worker running, watch Dashboard or URL Detail change to synchronized.
4. Vote malicious, change to safe, then withdraw. The database keeps at most one current vote and the trigger records the changes.
5. Sign in as Reviewer. Read the evidence, enter a reason, set the URL verdict, and accept/reject the report. A reviewer cannot accept their own report. A verdict and report acceptance are separate decisions.
6. After the worker finishes, run semantic search for “parcel redelivery payment fee”. Results contain real cosine similarity values from accepted report text.
7. Inspect risk, coverage, components and history on URL Detail; inspect SQL and MongoDB aggregates on Analytics.
8. Sign in as Administrator. Inspect accounts, roles, jobs and audit logs. Role/status changes revoke active sessions.

## 5. Required MongoDB outage/retry demonstration

Keep the app and worker running. In terminal 3:

```sh
docker compose stop mongo
```

Submit a new invented report. It must return a committed SQL report with pending synchronization; MongoDB-dependent views show an unavailable/pending state. Check Admin → Worker jobs for a retryable delivery error. Restore MongoDB promptly, before all eight attempts are exhausted:

```sh
docker compose start mongo
```

The worker retries automatically (exponential delay, capped at five minutes). Observe `synced` in the UI and `done` in jobs. Confirm exactly one MongoDB `_id` for the report using your MongoDB client. Version checks prevent older deliveries from replacing a newer document.

For an already parked job, the local operator can deliberately requeue it by the UUID shown in Admin:

```sh
npm run job:retry -- EVENT_UUID
```

That command records an audit entry. If a report has multiple versions, retry the earlier failed event first. The worker will not process a later version until its predecessor is done.

## 6. Tests and database demonstrations

```sh
npm run typecheck
npm run lint
npm test
python -m unittest discover -s tests -p "test_*.py" -v
npm run build
npm run db:demo
```

`db:demo` needs the **owner** connection for CREATE/ALTER/DROP; it uses DATABASE_ADMIN_URL automatically. All destructive demonstration operations run in a rolled-back temporary fixture. Application history is retained. The original 35 SELECT examples remain in `database/04_queries.sql`. The original full-reference fixtures (`03_seed.sql`, `mongodb/02_seed.js`) are for isolated database exercises; use `npm run db:seed` for the working app.

For the self-contained verification harness (downloads a MongoDB test binary and browser once):

```sh
npx playwright install chromium
npm run test:full
```

This harness runs a disposable **PostgreSQL WASM engine with pgvector**, a real MongoDB 8.0.16 process and the production Next.js build. It tests real HTTP handlers and captures screenshots. It does not replace the native PostgreSQL Docker workflow, and it cannot establish native PostgreSQL concurrency or Docker compatibility. It requires free ports 3100, 5433 and 27018. It never connects to the development Docker databases. Run `npm run build` first and after application changes. Results are written to `docs/integration-results.json`, `docs/browser-results.json` and `screenshots/`.

`npm run test:integration` is intended for a separate disposable configured database and requires `ALLOW_TEST_MUTATIONS=yes`; the controlled outage check needs the full harness. Do not point mutation tests at important data. The historical 45-case acceptance plan is preserved separately from executed results: writing an expected result does not mark it passed.

If a compatible Chromium is already installed, set `PLAYWRIGHT_CHROMIUM_EXECUTABLE` to its executable path for browser tests. The supplied screenshots were captured using Chromium 153.0.8010.0 after the normal download endpoint was unavailable in the build environment. The browser binary is not included. Run `npm run test:full -- --no-browser` to execute database/API checks without browser capture, or `npm run test:full -- --browser-only` to capture the UI using a fresh disposable seed.

The current route descriptions are in `docs/IMPLEMENTED_API.md`; all 31 core contracts and a supporting health endpoint are implemented. Older design catalog descriptions of JWT issuance are superseded by the opaque-session implementation described in the implementation report.

## 7. Source map

| Folder/file | Purpose |
|---|---|
| app/, components/ | Seven page areas, supporting auth pages, UI and /api/v1 handler |
| lib/server/ | Sessions, validation, SQL/Mongo clients, API operations, risk integration, search and analytics |
| workers/ | Claims, leases, versioned Mongo delivery, embeddings, score refresh and retries |
| scripts/ | Setup, secure local env generation, seed, verification, model download and demonstrations |
| database/ | Original schema, procedures, 35 queries, DML, DDL and legacy migration |
| mongodb/ | Original collection validators, reference examples and Docker user initialization |
| vector/ | Original Python reference and SQL vector query; runtime uses lib/server/embedding.ts |
| tests/app/ | Executable unit, HTTP/database, failure/retry and browser tests |
| tests/ | Original Python audits, arithmetic checks, SQL assertions and 45-case plan |
| docs/, screenshots/ | Actual implementation test evidence and screenshots |
| IMPLEMENTATION_REPORT.md | Current completion status, design differences and validation limits |

## 8. Troubleshooting

- **Docker not running:** start Docker Desktop, then repeat `docker compose up -d --wait`.
- **Ports already in use:** stop the conflicting service. If changing mapped database ports, change both Docker ports and the matching URI in `.env`.
- **403 request origin rejected:** open http://localhost:3000, not the numeric IP, unless APP_ORIGIN was changed consistently and the app restarted.
- **Database unavailable:** run `docker compose ps`, `npm run db:setup`, and check private URI values. Do not paste credentials into public issues.
- **Model unavailable:** run `npm run model:download`. Metadata and votes still work; semantic search reports unavailable instead of generating fake vectors. Requeue parked embedding jobs after model recovery.
- **Reports remain pending:** run `npm run worker`; inspect Admin jobs and MongoDB health. Later report versions wait for earlier deliveries.
- **No semantic results:** review a synchronized report, accept it and let the worker produce embeddings. Pending/rejected/withdrawn reports are intentionally excluded.
- **Seed fails on missing passwords:** run `npm run env:init` once, or fill the three SEED_* fields with private 12+ character values. Never commit `.env`.
- **Existing older schema uses the former risk field:** review and apply `database/07_coverage_migration.sql` using the owner account before rerunning setup. Fresh installs must not run this legacy-only migration.

## 9. Git-ready workflow

```sh
git init
git add .
git status
```

Check that `.env`, `.model-cache`, `node_modules` and `.next` are excluded before committing. The ZIP does not contain private passwords or downloaded dependencies/models. Each team member should commit their own actual work. Do not describe the supplied screenshots as screenshots from your own computer; replace or supplement them with your local demonstration after setup.
